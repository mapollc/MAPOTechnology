const specificURL = window.location.origin + '/';
const mfFonts = specificURL + 'data/maps/fonts/{fontstack}/{range}.pbf';
const debugMode = window.location.search.search('version') >= 0;
const getPlatform = () => {
    const h = window.location.host;
    if (h.includes('wildfiremap.org')) return 'wildfiremap';
    if (h.includes('fireweatheravalanche.org')) return 'fireweatheravalanche';
    return 'mapofire';
};
const config = {
    host: `https://${window.location.host}/`/*'https://www.mapofire.com/'*/,
    domain: 'https://www.mapotechnology.com/',
    apiURL: 'https://api.mapotechnology.com/v1/',
    productName: 'Map of Fire',
    company: 'MAPO LLC',
    /*sub_id: 'price_1MgxhSIpCdpJm6cTaKp2dqf5',*/
    apiKey: () => {
        const keys = {
            'fireweatheravalanche': '191eab18c50c8f5653bdeba13f219bed',
            'wildfiremap': '85f58fa255efe0f779e0dfcd62d87e6d',
            'mapofire': '50e2c43f8f63ff0ed20127ee2487f15e'
        };

        return keys[getPlatform()];
    },
    disableClicks: false,
    wildfire: null,
    layersHandler: null,
    layersMenu: null,
    listOfLayers: [],
    fuelsData: null,
    specificURL: specificURL,
    donateLink: 'https://mapofire.com/donate',
    mapboxToken: 'pk.eyJ1IjoibWFwb2xsYyIsImEiOiJjbG5qb3ppd3oxbGw5MmtyaXEyenRtZG5xIn0.jBgm6b3soPoBzbKjvMUwWw',
    //defaultAttr: '&copy; <a href="https://www.mapbox.com/about/maps/">MapBox</a> ',
    defaultAttr: '',
    months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'],
    longMonths: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    curTime: new Date(),
    daysInYear: (y = null) => { const year = y ?? new Date().getFullYear(); return (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? 366 : 365; },
    runSearch: false,
    TIERS: {
        'ignite_monthly': 'PREMIUM',
        'ignite_annual': 'PREMIUM',
        'hotshot_monthly': 'PRO',
        'hotshot_annual': 'PRO'
    },
    PERMISSION_LEVELS: {
        ADMIN: 'ADMIN',
        PREMIUM: 'PREMIUM',
        PRO: 'PRO'
    },
    RANKS: {
        PREMIUM: 1,
        PRO: 2,
        ADMIN: 3
    },
    modisZoomLevel: 7,
    firemedZoomLevel: 9,
    toolsInstance: null,
    workers: {
        incident: new Worker(specificURL + (debugMode ? 'v' + version + '/incident.js' : 'src/js/incident-' + version + '.js')),
        fwf: null,
        wwas: null
    },
    fog: {
        'sky-color': '#33bbff',
        'sky-horizon-blend': +0.5,
        'horizon-color': '#b1ddec',
        'horizon-fog-blend': +0.5,
        'fog-color': '#c7c7c7',
        'fog-ground-blend': +0.1
    },
    tiles: null,
    fonts: {
        din: () => {
            const fontMap = {
                'dark': ['Noto Sans Regular'],
                'voyager': ['Noto Sans Regular'],
                'satellite': ['Noto Sans Bold'],
                'default': ['DIN Pro Medium']
            };
            return fontMap[settings.getBasemap()] || fontMap['default'];
        },
        source: () => {
            const fontMap = {
                'dark': ['Noto Sans Regular'],
                'voyager': ['Noto Sans Regular'],
                'satellite': ['Noto Sans Bold'],
                'osm': ['Source Sans Pro SemiBold'],
                'default': ['Source Sans Pro SemiBold']
            };
            return fontMap[settings.getBasemap()] || fontMap['default'];
        },
        roboto: () => {
            const fontMap = {
                'dark': ['Montserrat Medium'],
                'voyager': ['Montserrat Medium'],
                'satellite': ['Noto Sans Bold'],
                'default': ['Roboto Medium']
            };
            return fontMap[settings.getBasemap()] || fontMap['default'];
        }
    }
};

window.config = config;

const layerActions = {
    'newFires': { layers: ['new_fires_layer', 'new_fire_title'] },
    'allFires': { layers: ['all_fires_layer', 'all_fire_title', 'ca_fires', 'ca_fire_title'] },
    'smokeChecks': { layers: ['smk_fires_layer', 'smk_fire_title'] },
    'rxBurns': { layers: ['rx_fires_layer', 'rx_fire_title'] },
    'perimeters': {
        layers: ['perimeters_outline', 'perimeters_fill', 'perimeters_title', 'ca_perimeters_outline',
            'ca_perimeters_fill', 'ca_perimeters_title', 'aus_perimeters_outline', 'aus_perimeters_fill', 'aus_perimeters_title']
    },
    'modis24': { layers: ['modis24'], exe: () => { config.layersHandler.modis(1); } },
    'modis48': { layers: ['modis48'], exe: () => { config.layersHandler.modis(2); } },
    'modis72': { layers: ['modis72'], exe: () => { config.layersHandler.modis(3); } },

    'evac': { layers: ['evac', 'evac_outline', 'evac_title'] },
    'firemed': { layers: ['firemed'], exe: () => { config.layersHandler.firemed(); } },

    'lightning1': { layers: ['lightning1'] },
    'lightning24': { layers: ['lightning24'] },
    'wwas': { layers: ['wwas_fill', 'wwas_outline', 'wwas_title'], exe: async () => { new NWS().get(); } },
    'stns': { layers: ['stns', 'stns_text'], exe: () => { new Weather().raws(); } },
    'visSatellite': { layers: ['satellite1'], exe: async () => { new NWS().satellite(1); } },
    'irSatellite': { layers: ['satellite2'], exe: async () => { new NWS().satellite(2); } },
    'wvSatellite': { layers: ['satellite3'], exe: async () => { new NWS().satellite(3); } },

    'ev': { layers: ['ev'], exe: () => { config.layersHandler.pnwVulnerability(); } },
    'spcClimo': {
        run: (checked) => {
            if (checked) {
                config.layersHandler.spcClimo();
            } else {
                map.removeLayer('spc_climo_fill');
                map.removeLayer('spc_climo_outline');
                map.removeLayer('spc_climo_prob');
                map.removeSource('spc_climo');
                document.querySelector('.spcTimeline').remove();
            }
        }
    },
    'nri': { layers: ['nri_outline', 'nri_fill'], exe: () => { config.layersHandler.nri(); } },
    'rth': { layers: ['rth'], exe: () => { config.layersHandler.rth(); } },
    'bp': { layers: ['bp'], exe: () => { config.layersHandler.bp(); } },
    'whp': { layers: ['whp'], exe: () => { config.layersHandler.whp(); } },
    'wet': { layers: ['wet'], exe: () => { config.layersHandler.wet(); } },
    'drought': { layers: ['drought', 'drought_outline', 'drought_title'], exe: () => { config.layersHandler.drought(); } },
    'power': { layers: ['power'], exe: () => { config.layersHandler.power(); } },
    'fuels': { layers: ['fuels', 'fuelsAK'], exe: () => { config.layersHandler.fuels(); } },

    'nwsCWAs': { layers: ['nwsCWAs'], exe: () => { config.layersHandler.nwsCWAs(); } },
    'roads': { layers: ['roads'], exe: () => { config.layersHandler.roads(); } },
    'lands': { layers: ['lands'], exe: () => { config.layersHandler.lands(); } },
    'plss': { layers: ['plss'], exe: () => { config.layersHandler.plss(); } },
    'dispatch': { layers: ['dispatch_outline', 'dispatch_title'], exe: () => { config.layersHandler.dispatch(); } },
    'gaccBounds': { layers: ['gaccBounds', 'gaccBounds_title'], exe: () => { config.layersHandler.gaccBounds(); } },

    'hms': { layers: ['hms', 'hms_title'], exe: () => { config.layersHandler.hms(); } },
    'smokeFcst': { layers: ['smokeFcst'], exe: () => { config.layersHandler.smokeFcst(); } },
    'sfcSmoke': { layers: ['sfcSmoke'], exe: () => { config.layersHandler.sfcSmoke(); } },
    'viSmoke': { layers: ['viSmoke'], exe: () => { config.layersHandler.viSmoke(); } },

    'countyBounds': { layers: ['countyBounds'], exe: () => { config.layersHandler.countyBounds(); } },
    'odfFDR': { layers: ['odfFDR', 'odfFDR_outline', 'odfFDR_title'], exe: () => { config.layersHandler.odfFDR(); } },
    'calfireUnits': { layers: ['calfireUnits', 'calfireUnits_title'], exe: () => { config.layersHandler.calfireUnits(); } },
    'cdfFHSZ': { layers: ['cdfFHSZ', 'cdfFHSZ_title'], exe: () => { config.layersHandler.cdfFHSZ(); } },
    'calfireAircraft': { layers: ['calfireAircraft', 'calfireAircraft_title'], exe: () => { config.layersHandler.calfireAircraft(); } },

    'airq': {
        run: (checked) => {
            const i = setInterval(() => {
                if (map.getSource('airq')) {
                    clearInterval(i);
                    ['airQuality', 'airQuality_text'].forEach(n => map.setLayoutProperty(n, 'visibility', checked ? 'visible' : 'none'));
                }
            }, 500);
        }
    },
    'spc': {
        run: async (checked) => {
            if (impact.style.display == 'flex' && impact.dataset.content == 'layers') {
                document.querySelector('#otlkType').disabled = !checked;
                document.querySelector('#otlkDay').disabled = !checked;
            }

            if (map.getSource('outlook')) {
                ['outlook_fill', 'outlook_outline', 'outlook_title'].forEach(n => map.setLayoutProperty(n, 'visibility', checked ? 'visible' : 'none'));
            } else if (checked) {
                new NWS().spc();
            }
        }
    },
    'radar': {
        run: (checked) => {
            if (checked) {
                config.layersHandler.radarInit();
            } else {
                radarPlay = true;
                document.querySelector('.radar').remove();
                clearInterval(radarAnim);

                for (let i = 0; i < radarImgs.length; i++) {
                    map.removeLayer('radar-layer-' + i);
                    map.removeSource('radar-' + i);
                }
            }
        }
    },
    'ndfd': {
        run: async (checked) => {
            const visibility = checked ? 'visible' : 'none';

            if (impact.style.display == 'flex') {
                document.querySelector('#forecastModel').disabled = !checked;
                document.querySelector('#fcstTime').disabled = !checked;
            }

            if (map.getSource('ndfd')) {
                map.setLayoutProperty('ndfd', 'visibility', visibility);

                if (!checked) document.querySelector('.ndfdLegend')?.remove();
            } else if (checked) {
                new NWS().ndfd();
            }
        }
    },
    'erc': {
        run: (checked) => {
            if (impact.style.display == 'flex') document.querySelector('#erc_time').disabled = !checked;

            if (map.getSource('erc')) {
                ['erc_fill', 'erc_outline'].forEach(n => map.setLayoutProperty(n, 'visibility', checked ? 'visible' : 'none'));
            } else if (checked) {
                config.layersHandler.erc();
            }
        }
    },
    'sfp': {
        run: (checked) => {
            if (impact.style.display == 'flex') document.querySelector('#sfpDateSelect').disabled = !checked;

            if (map.getSource('sfp')) {
                map.setLayoutProperty('sfp', 'visibility', checked ? 'visible' : 'none');
            } else if (checked) {
                config.layersHandler.sfp();
            }
        }
    }
};
const osm = {
    version: 8,
    glyphs: mfFonts,
    sources: {
        'openstreetmap': {
            type: 'raster',
            tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }
    },
    layers: [{
        id: 'osm',
        type: 'raster',
        source: 'openstreetmap',
        minzoom: 0,
        maxzoom: 19
    }]
};
const topofire = {
    version: 8,
    glyphs: mfFonts,
    sources: {
        'topofire': {
            type: 'raster',
            tiles: [config.domain + 'assets/images/tiles/6/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '&copy; <a href="umt.edu">UMT</a>, USFS, NOAA, NIDIS, NASA'
        }
    },
    layers: [{
        id: 'topofire',
        type: 'raster',
        source: 'topofire',
        minzoom: 0,
        maxzoom: 13
    }]
};
const terrain = {
    version: 8,
    glyphs: mfFonts,
    sources: {
        'esri': {
            type: 'raster',
            tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'],
            tileSize: 256,
            attribution: '&copy; <a href="https://www.arcgis.com">ESRI</a>'
        }
    },
    layers: [{
        id: 'terrain',
        type: 'raster',
        source: 'esri',
        minzoom: 3,
        maxzoom: 18
    }]
};
const caltopo = {
    version: 8,
    glyphs: mfFonts,
    sources: {
        'ct': {
            type: 'raster',
            tiles: [config.domain + 'assets/images/tiles/2/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '&copy; <a href="https://caltopo.com">CalTopo</a>'
        }
    },
    layers: [{
        id: 'caltopo',
        type: 'raster',
        source: 'ct',
        minzoom: 5,
        maxzoom: 16
    }]
};
const fs16 = {
    version: 8,
    glyphs: mfFonts,
    sources: {
        'usfs2016': {
            type: 'raster',
            tiles: [config.domain + 'assets/images/tiles/3/{z}/{x}/{y}.png'],
            tileSize: 256
        }
    },
    layers: [{
        id: 'fs16',
        type: 'raster',
        source: 'usfs2016',
        minzoom: 5,
        maxzoom: 16
    }]
};
const activeIncidents = new Map();
const modal = document.querySelector('#modal');
const impact = document.querySelector('#impact');
const searchResults = document.querySelector('#search-results');
const disclaimer = 'This information is based on an automated collection of data from various state and federal interagency dispatch centers and other governmental sources. Always refer to your local sources for the latest updates on evacuations or other critical information.';
const impactHeader = `<header><h3 id="a" class="title"><div class="placeholder" style="width:225px;height:28px"></div></h3><div id="mclose" data-action="close-impact" title="Close window">
    <i class="far fa-xmark" data-action="close-impact"></i></div></header>`;
const noneTracked = '<p class="message error">You aren\'t following any wildfires yet. Click on a fire to start following an incident.</p>';
const risk = {
    'whp': [
        ['N/A', '#fff'],
        ['Very Low', '#38a800'],
        ['Low', '#d1ff73'],
        ['Moderate', '#ffff00'],
        ['High', '#ffaa00'],
        ['Very High', '#ff0000']
    ]
};/*,
    loadUtils = async () => {
        if (lu) return lu;

        try {
            lu = await import(config.specificURL + (debugMode ? 'v' + version + '/mf.utils.js' : 'src/js/mf.utils-' + version + '.js'));
            return lu;
        } catch (e) {
            console.error('Failed to load utils', e);
            lu = null;
            throw e;
        }
    }*/
const mapControls = [];

const stateLabels = {
    'AB': { name: 'Alberta', center: [-113.5, 54.5] },
    'ACT': { name: 'Australian Capital Territory', center: [149.0014, -35.4900] },
    'AL': { name: 'Alabama', center: [-86.8295337, 33.2588817] },
    'AK': { name: 'Alaska', center: [-149.680909, 64.4459613] },
    'AZ': { name: 'Arizona', center: [-111.7632755, 34.395342] },
    'AR': { name: 'Arkansas', center: [-92.4479108, 35.2048883] },
    'BC': { name: 'British Columbia', center: [-123.5, 54.5] },
    'CA': { name: 'California', center: [-118.7559974, 36.7014631] },
    'CO': { name: 'Colorado', center: [-105.6077167, 38.7251776] },
    'CT': { name: 'Connecticut', center: [-72.7342163, 41.6500201] },
    'DE': { name: 'Delaware', center: [-75.4013315, 38.6920451] },
    'DC': { name: 'District of Columbia', center: [-77.0365529, 38.8948932] },
    'FL': { name: 'Florida', center: [-81.4639835, 27.7567667] },
    'GA': { name: 'Georgia', center: [-83.1137366, 32.3293809] },
    'HI': { name: 'Hawaii', center: [-157.975203, 21.2160437] },
    'ID': { name: 'Idaho', center: [-114.74121, 45.61788] },
    'IL': { name: 'Illinois', center: [-89.4337288, 40.0796606] },
    'IN': { name: 'Indiana', center: [-86.1746933, 40.3270127] },
    'IA': { name: 'Iowa', center: [-93.3122705, 41.9216734] },
    'KS': { name: 'Kansas', center: [-98.5821872, 38.27312] },
    'KY': { name: 'Kentucky', center: [-85.1551411, 37.5726028] },
    'LA': { name: 'Louisiana', center: [-92.007126, 30.8703881] },
    'MB': { name: 'Manitoba', center: [-97.8, 55.0] },
    'ME': { name: 'Maine', center: [-68.8590201, 45.709097] },
    'MD': { name: 'Maryland', center: [-76.9382069, 39.5162234] },
    'MA': { name: 'Massachusetts', center: [-72.032366, 42.3788774] },
    'MI': { name: 'Michigan', center: [-84.6824346, 43.6211955] },
    'MN': { name: 'Minnesota', center: [-94.6113288, 45.9896587] },
    'MS': { name: 'Mississippi', center: [-89.7348497, 32.9715645] },
    'MO': { name: 'Missouri', center: [-92.5617875, 38.7604815] },
    'MT': { name: 'Montana', center: [-109.6387579, 47.3752671] },
    'NB': { name: 'New Brunswick', center: [-66.0, 46.5] },
    'NE': { name: 'Nebraska', center: [-99.5873816, 41.7370229] },
    'NL': { name: 'Newfoundland', center: [-58.0, 53.0] },
    'NS': { name: 'Nova Scotia', center: [-63.5, 45.0] },
    'NSW': { name: 'New South Wales', center: [147.0167, -32.1633] },
    'NV': { name: 'Nevada', center: [-116.8537227, 39.5158825] },
    'NH': { name: 'New Hampshire', center: [-71.6553992, 43.4849133] },
    'NJ': { name: 'New Jersey', center: [-74.4041622, 40.0757384] },
    'NM': { name: 'New Mexico', center: [-105.993007, 34.5708167] },
    'NY': { name: 'New York', center: [-74.0060152, 40.7127281] },
    'NC': { name: 'North Carolina', center: [-79.0392919, 35.6729639] },
    'ND': { name: 'North Dakota', center: [-100.540737, 47.6201461] },
    'NT': { name: 'Northwest Territories', center: [-117.0, 64.0] },
    'NTT': { name: 'Northern Territory', center: [133.3578, -19.3833] },
    'NU': { name: 'Nunavut', center: [-90.0, 71.0] },
    'OH': { name: 'Ohio', center: [-82.6881395, 40.2253569] },
    'OK': { name: 'Oklahoma', center: [-97.2684063, 34.9550817] },
    'ON': { name: 'Ontario', center: [-84.0, 50.0] },
    'OR': { name: 'Oregon', center: [-120.737257, 43.9792797] },
    'PA': { name: 'Pennsylvania', center: [-77.7278831, 40.9699889] },
    'PE': { name: 'Prince Edward Island', center: [-63.5, 46.3] },
    'QC': { name: 'Quebec', center: [-71.5, 52.0] },
    'QLD': { name: 'Queensland', center: [144.4317, -22.4870] },
    'RI': { name: 'Rhode Island', center: [-71.5992372, 41.7962409] },
    'SA': { name: 'South Australia', center: [135.7633, -30.0583] },
    'SC': { name: 'South Carolina', center: [-80.4363743, 33.6874388] },
    'SD': { name: 'South Dakota', center: [-100.348761, 44.6471761] },
    'SK': { name: 'Saskatchewan', center: [-106.0, 52.0] },
    'TAS': { name: 'Tasmania', center: [146.5933, -42.0214] },
    'TN': { name: 'Tennessee', center: [-86.2820081, 35.7730076] },
    'TX': { name: 'Texas', center: [-99.5120986, 31.8160381] },
    'UT': { name: 'Utah', center: [-111.7143584, 39.4225192] },
    'VIC': { name: 'Victoria', center: [144.2800, -36.8542] },
    'VT': { name: 'Vermont', center: [-72.5002608, 44.5990718] },
    'VA': { name: 'Virginia', center: [-78.4927721, 37.1232245] },
    'WA': { name: 'Washington', center: [-120.74014, 47.75107] },
    'WAA': { name: 'Western Australia', center: [122.2983, -25.3281] },
    'WV': { name: 'West Virginia', center: [-80.8408415, 38.4758406] },
    'WI': { name: 'Wisconsin', center: [-89.6884637, 44.4308975] },
    'WY': { name: 'Wyoming', center: [-107.5685348, 43.1700264] },
    'YT': { name: 'Yukon', center: [-135.0, 62.0] }
};

const legend = {
    'categories': [
        { 'fire': 'Wildfires' },
        { 'viirs': 'VIIRS Hotspots' },
        { 'airQ': 'Air Quality' },
        { 'smoke': 'Smoke Forecast' },
        { 'drought': 'Drought Conditions' },
        //{ 'nfdrs': 'Fire Danger' },
        { 'sfp': 'Significant Fire Potential' },
        { 'erc': 'Energy Release Component' },
        /*{ 'burnProb': 'Burn Probability' },*/
        { 'fhsz': 'CAL FIRE Hazard Severity Zones' },
        { 'lands': 'Land Ownership' },
        { 'spc': 'SPC Fire Climatology' },
        { 'rth': 'Wildfire Risk to Homes' },
        { 'wet': 'Wildfire Exposure Type' },
        { 'bp': 'Wildfire Likelihood' },
        { 'whp': 'Wildfire Hazard Potential' },
        { 'nri': 'FEMA Wildfire Risk Index' }
    ],
    'items': {
        'fire': [
            ['icon', '<div class="fire-icon new"><i class="fas fa-fire"></i></div>', '', 'New Fire'],
            ['icon', '<div class="fire-icon new fast"><i class="fas fa-fire"></i></div>', '', 'Fast Growing Fire'],
            ['icon', '<div class="fire-icon big"><i class="fas fa-fire"></i></div>', '', 'Active Fire (0-100 acres)'],
            ['icon', '<div class="fire-icon"><i class="fas fa-fire"></i></div>', '', 'Active Fire (100-1000 acres)'],
            ['icon', '<div class="fire-icon large"><i class="fas fa-fire"></i></div>', '', 'Active Fire (>1000 acres)'],
            ['icon', '<div class="fire-icon complex"><i class="fad fa-fire-flame-curved" aria-hidden="true" style="position:absolute;left:2px;top:2px;color:rgb(255 255 255 / 100%)"></i>' +
                '<i class="fad fa-fire-flame-curved" aria-hidden="true" style="position:absolute;right:1px;bottom:2px;color:rgb(255 255 255 / 100%)"></i>' +
                '<div style="position:absolute;width:25px;border-bottom:1px solid rgb(255 255 255 / 68%);top:50%;transform:rotate(-45deg)"></div></div>', '', 'Complex'],
            ['icon', '<div class="fire-icon contain"><i class="fas fa-fire"></i></div>', '', 'Contained Fire'],
            ['icon', '<div class="fire-icon controlled"><i class="fas fa-fire"></i></div>', '', 'Controlled Fire'],
            ['icon', '<div class="fire-icon rx"><i class="fas fa-prescription"></i></div>', '', 'Prescribed Burn'],
            ['icon', '<div class="fire-icon smkchk"><i class="fas fa-badge-check"></i></div>', '', 'Smoke Check']
        ],
        'airQ': [
            ['color', '', '#00e400', 'Good (0-50)'],
            ['color', '', '#ffff00', 'Moderate (51-100)'],
            ['color', '', '#ff7e00', 'Unhealthy for Sensitive Groups (101-150)'],
            ['color', '', '#ff0000', 'Unhealthy (151-200)'],
            ['color', '', '#8f3f97', 'Very Unhealthy (201-300)'],
            ['color', '', '#7e0023', 'Hazardous (301+)'],
            ['color', '', '#d9d9d9', 'No Data'],
        ],
        'viirs': [
            ['icon', '<div class="viirs t24"></div>', '', 'Heat Detection (0-24 hours old)'],
            ['icon', '<div class="viirs t48"></div>', '', 'Heat Detection (24-48 hours old)'],
            ['icon', '<div class="viirs t72"></div>', '', 'Heat Detection (48-72 hours old)']
        ],
        'smoke': [
            ['color', '', '#ffffc0', 'Very Clean (0-3 µg/m³)'],
            ['color', '', '#fcdf8b', 'Light Smoke (3-25 µg/m³)'],
            ['color', '', '#f6c26d', 'Moderate Smoke (25-63 µg/m³)'],
            ['color', '', '#c5885c', 'Heavy Smoke (63-158 µg/m³)'],
            ['color', '', '#974f4f', 'Very Heavy Smoke (158-1000 µg/m³)'],
            ['color', '', '#f8fed0', 'No Data']
        ],
        /*'nfdrs': [
            ['color', '', '#3db471', 'Low'],
            ['color', '', '#00ff00', 'Moderate'],
            ['color', '', '#ffff00', 'High'],
            ['color', '', '#ff8b00', 'Very High'],
            ['color', '', '#b31f1f', 'Extreme']
        ],*/
        'sfp': [
            ['color', '', '#85ca0a', 'Little or No Risk'],
            ['color', '', '#ffff00', 'Low Risk'],
            ['color', '', '#ad7c23', 'Moderate Risk'],
            ['color', 'D', '#ff9900', 'Dry'],
            ['color', 'W', '#ff9900', 'Hot & Dry'],
            ['color', 'H', '#ff9900', 'Hot'],
            ['color', 'U', '#ff9900', 'Unstable'],
            ['color', 'L', '#ff0000', 'Lightning'],
            ['color', 'R', '#ff0000', 'Recreation'],
            ['color', 'B', '#ff0000', 'Burn Environment']
        ],
        'spc': [
            ['color', '', '#fff', '2-5%'],
            ['color', '', '#ffdfbf', '5-10%'],
            ['color', '', '#ffab57', '10-15%'],
            ['color', '', '#ff7500', '15-20%'],
            ['color', '', '#ee3f00', '20-25%'],
            ['color', '', '#c80b00', '25-30%'],
            ['color', '', '#9f0000', '30-35%'],
            ['color', '', '#760000', '35-40%'],
            ['color', '', '#500000', '40-45%'],
            ['color', '', '#270000', '45-50%']
        ],
        'erc': [
            ['color', '', '#38a800', '<60% higher than normal'],
            ['color', '', '#d1ff73', '60-79.9% higher than normal'],
            ['color', '', '#ffffbe', '80-89.9% higher than normal'],
            ['color', '', '#ffaa00', '90-96.9% higher than normal'],
            ['color', '', '#ff0000', '97-99.9% higher than normal'],
            ['color', '', '#a80000', '>=100% higher than normal'],
            ['color', '', '#e1e1e1', 'No data'],
        ],
        /*'burnProb': [
            ['color', '', '#fff0cf', '0-0.01%'],
            ['color', '', '#fddcaf', '0.01-0.02%'],
            ['color', '', '#fdca94', '0.02-0.05%'],
            ['color', '', '#fdb27b', '0.05-0.1%'],
            ['color', '', '#fc8d59', '0.1-0.2%'],
            ['color', '', '#f26d4b', '0.2-.05%'],
            ['color', '', '#e1452f', '0.5-1%'],
            ['color', '', '#c91d13', '1-2.2%'],
            ['color', '', '#a90000', '2.2-4.5%'],
            ['color', '', '#7f0000', '4.5-12.5%']
        ],*/
        'fhsz': [
            ['color', '', '#ffff69', 'Moderate'],
            ['color', '', '#ffcd69', 'High'],
            ['color', '', '#ff6969', 'Very High']
        ],
        'nri': [
            ['color', '', '#4d6dbd', 'Very Low'],
            ['color', '', '#509bc7', 'Relatively Low'],
            ['color', '', '#f0d55d', 'Relatively Moderate'],
            ['color', '', '#e07069', 'Relatively High'],
            ['color', '', '#c7445d', 'Very High'],
            ['color', '', '#ffffff', 'No Rating'],
            ['color', '', '#9e9e9e', 'Insufficient Data']
        ],
        'lands': [
            ['color', '', '#fcb5ce', 'Department of Defense'],
            ['color', '', '#fee67a', 'Bureau of Land Management'],
            ['color', '', '#cabddd', 'National Park Service'],
            ['color', '', '#cdecc5', 'U.S. Forest Service'],
            ['color', '', '#7fcda7', 'U.S. Fish & Wildlife Service'],
            ['color', '', '#ffffb4', 'Bureau of Reclamation'],
            ['color', '', '#fdb56b', 'Bureau of Indian Affairs'],
            ['color', '', '#e4c4a0', 'Other Federal'],
            ['color', '', '#b4e3ef', 'State']
        ],
        'rth': [
            ['color', '', '#ffffff', '0 percentile'],
            ['color', '', '#f1f2a0', '0-40th percentile'],
            ['color', '', '#f2c13c', '40-70th percentile'],
            ['color', '', '#f28017', '70-90th percentile'],
            ['color', '', '#f21900', '90-95th percentile'],
            ['color', '', '#c4001a', '95-100th percentile']
        ],
        'wet': [
            ['color', '', '#d6d6d6', 'Not Exposed'],
            ['color', '', '#ff8f50', 'Indirectly Exposed'],
            ['color', '', '#ff3b54', 'Directly Exposed']
        ],
        'bp': [
            ['color', '', '#fff0cf', 'Very Low (0 to 1-in-4,643)'],
            ['color', '', '#fdca94', 'Low (1-in-4,643 to 1-in-2,154)'],
            ['color', '', '#fdb27b', 'Low (1-in-2,154 to 1-in-1,000)'],
            ['color', '', '#fc8d59', 'Moderate (1-in-1,000 to 1-in-464)'],
            ['color', '', '#f26d4b', 'Moderate (1-in-464 to 1-in-215)'],
            ['color', '', '#e1452f', 'High (1-in-215 to 1-in-100)'],
            ['color', '', '#c91d13', 'High (1-in-100 to 1-in-46)'],
            ['color', '', '#a90000', 'Very High (1-in-46 to 1-in-22)'],
            ['color', '', '#7f0000', 'Very High (1-in-22+)']
        ],
        'whp': [
            ['color', '', '#38a800', 'Very Low'],
            ['color', '', '#d1ff73', 'Low'],
            ['color', '', '#ffff00', 'Moderate'],
            ['color', '', '#ffaa00', 'High'],
            ['color', '', '#ff0000', 'Very High']
        ],
        'drought': [
            ['color', '', '#ffff00', 'Abnormally Dry'],
            ['color', '', '#ffcc99', 'Moderate Drought'],
            ['color', '', '#ff6600', 'Severe Drought'],
            ['color', '', '#ff0000', 'Extreme Drought'],
            ['color', '', '#660000', 'Exceptional Drought']
        ]
    }
};

const ODF_DISTRICT_NAMES = {
    "EL-1": "South Cascade",
    "SW-2": "Southwest Oregon",
    "MR-1": "North Cascade",
    "QC": "South Cascade",
    "UA-2": "Douglas FPA",
    "DE-1": "Central Oregon",
    "SW-1": "Southwest Oregon",
    "DG-1": "Douglas FPA",
    "SK-1": "Coos FPA",
    "RWSC": "Southwest Oregon",
    "NW-1": "Northwest",
    "CM-2": "North Cascade",
    "WR-1": "Walker Range FPA",
    "BR-1": "North Cascade",
    "NE-2": "Northeast Oregon",
    "MH-4": "Central Oregon",
    "NE-4": "Northeast Oregon",
    "SW-3": "Southwest Oregon",
    "SL-2": "Western Lane",
    "MA-1": "Central Oregon",
    "CM-1": "North Cascade",
    "KF-1": "Klamath-Lake",
    "WO-3": "West Oregon",
    "NE-3": "Northeast Oregon",
    "RR-2": "Southwest Oregon",
    "UA-3": "South Cascade",
    "WC-2": "Central Oregon",
    "WC-1": "Central Oregon",
    "WL-1": "South Cascade",
    "UA-1": "Douglas FPA",
    "NE-1": "Northeast Oregon",
    "SK-3": "Southwest Oregon",
    "MH-3": "North Cascade",
    "WO-2": "West Oregon",
    "WL-3": "South Cascade",
    "LN-1": "South Cascade",
    "KR": "Klamath-Lake",
    "CS-5": "Coos FPA",
    "NW-3": "Northwest",
    "WW-2": "Northeast Oregon",
    "MH-1": "Central Oregon",
    "DG-2": "Douglas FPA",
    "HLD": "North Cascade",
    "WN-1": "Klamath-Lake",
    "WT-1": "Western Lane",
    "WO-1": "West Oregon",
    "MA-2": "Central Oregon",
    "KF-2": "Klamath-Lake",
    "SW-4": "Southwest Oregon",
    "CS-1": "Coos FPA",
    "MH-2": "North Cascade",
    "CR-1": "Central Oregon",
    "UM-1": "Northeast Oregon",
    "RR-1": "Southwest Oregon",
    "OC-2": "Central Oregon",
    "EC-1": "Central Oregon",
    "WL-2": "South Cascade",
    "RR-3": "Southwest Oregon",
    "HC-1": "Northeast Oregon",
    "EC-2": "Central Oregon",
    "CS-2": "Coos FPA",
    "NW-2": "Northwest",
    "SK-2": "Coos FPA",
    "CS-4": "Coos FPA"
};

const wwaColors = [
    'case',
    ['==', ['get', 'Event'], '911 Telephone Outage'], '#bfbfbf',
    ['==', ['get', 'Event'], 'Administrative Message'], '#fefefe',
    ['==', ['get', 'Event'], 'Air Quality Alert'], '#7f7f7f',
    ['==', ['get', 'Event'], 'Air Stagnation Advisory'], '#7f7f7f',
    ['==', ['get', 'Event'], 'Arroyo and Small Stream Flood Advisory'], '#00fe7e',
    ['==', ['get', 'Event'], 'Ashfall Advisory'], '#686868',
    ['==', ['get', 'Event'], 'Ashfall Warning'], '#a8a8a8',
    ['==', ['get', 'Event'], 'Avalanche Advisory'], '#cc843e',
    ['==', ['get', 'Event'], 'Avalanche Warning'], '#1d8ffe',
    ['==', ['get', 'Event'], 'Avalanche Watch'], '#f3a35f',
    ['==', ['get', 'Event'], 'Beach Hazards Statement'], '#3fdfcf',
    ['==', ['get', 'Event'], 'Blizzard Warning'], '#fe4400',
    ['==', ['get', 'Event'], 'Blizzard Watch'], '#acfe2e',
    ['==', ['get', 'Event'], 'Blowing Dust Advisory'], '#bcb66a',
    ['==', ['get', 'Event'], 'Brisk Wind Advisory'], '#d7bed7',
    ['==', ['get', 'Event'], 'Child Abduction Emergency'], '#fed600',
    ['==', ['get', 'Event'], 'Civil Danger Warning'], '#feb5c0',
    ['==', ['get', 'Event'], 'Civil Emergency Message'], '#feb5c0',
    ['==', ['get', 'Event'], 'Coastal Flood Advisory'], '#7bfb00',
    ['==', ['get', 'Event'], 'Coastal Flood Statement'], '#6a8d22',
    ['==', ['get', 'Event'], 'Coastal Flood Warning'], '#218a21',
    ['==', ['get', 'Event'], 'Coastal Flood Watch'], '#65cca9',
    ['==', ['get', 'Event'], 'Dense Fog Advisory'], '#6f7f8f',
    ['==', ['get', 'Event'], 'Dense Smoke Advisory'], '#efe58b',
    ['==', ['get', 'Event'], 'Dust Storm Warning'], '#fee3c3',
    ['==', ['get', 'Event'], 'Earthquake Warning'], '#8a4412',
    ['==', ['get', 'Event'], 'Evacuation - Immediate'], '#7efe00',
    ['==', ['get', 'Event'], 'Excessive Heat Warning'], '#c61484',
    ['==', ['get', 'Event'], 'Excessive Heat Watch'], '#7f0000',
    ['==', ['get', 'Event'], 'Extreme Cold Warning'], '#0000fe',
    ['==', ['get', 'Event'], 'Extreme Cold Watch'], '#0000fe',
    ['==', ['get', 'Event'], 'Extreme Fire Danger'], '#e89579',
    ['==', ['get', 'Event'], 'Extreme Wind Warning'], '#fe8b00',
    ['==', ['get', 'Event'], 'Fire Warning'], '#9f512c',
    ['==', ['get', 'Event'], 'Fire Weather Watch'], '#feddac',
    ['==', ['get', 'Event'], 'Flash Flood Statement'], '#8a0000',
    ['==', ['get', 'Event'], 'Flash Flood Warning'], '#8a0000',
    ['==', ['get', 'Event'], 'Flash Flood Watch'], '#2d8a56',
    ['==', ['get', 'Event'], 'Flood Advisory'], '#00fe7e',
    ['==', ['get', 'Event'], 'Flood Statement'], '#00fe00',
    ['==', ['get', 'Event'], 'Flood Warning'], '#00fe00',
    ['==', ['get', 'Event'], 'Flood Watch'], '#2d8a56',
    ['==', ['get', 'Event'], 'Freeze Warning'], '#473c8a',
    ['==', ['get', 'Event'], 'Freeze Watch'], '#00fefe',
    ['==', ['get', 'Event'], 'Freezing Fog Advisory'], '#007f7f',
    ['==', ['get', 'Event'], 'Freezing Rain Advisory'], '#d96fd5',
    ['==', ['get', 'Event'], 'Freezing Spray Advisory'], '#00befe',
    ['==', ['get', 'Event'], 'Frost Advisory'], '#6394ec',
    ['==', ['get', 'Event'], 'Gale Warning'], '#dc9fdc',
    ['==', ['get', 'Event'], 'Gale Watch'], '#febfca',
    ['==', ['get', 'Event'], 'Hard Freeze Warning'], '#9300d2',
    ['==', ['get', 'Event'], 'Hard Freeze Watch'], '#4068e0',
    ['==', ['get', 'Event'], 'Hazardous Materials Warning'], '#4a0081',
    ['==', ['get', 'Event'], 'Hazardous Seas Warning'], '#d7bed7',
    ['==', ['get', 'Event'], 'Hazardous Seas Watch'], '#473c8a',
    ['==', ['get', 'Event'], 'Hazardous Weather Outlook'], '#ede7a9',
    ['==', ['get', 'Event'], 'Heat Advisory'], '#fe7e4f',
    ['==', ['get', 'Event'], 'Heavy Freezing Spray Warning'], '#00befe',
    ['==', ['get', 'Event'], 'Heavy Freezing Spray Watch'], '#bb8e8e',
    ['==', ['get', 'Event'], 'High Surf Advisory'], '#b954d2',
    ['==', ['get', 'Event'], 'High Surf Warning'], '#218a21',
    ['==', ['get', 'Event'], 'High Wind Warning'], '#d9a41f',
    ['==', ['get', 'Event'], 'High Wind Watch'], '#b7850a',
    ['==', ['get', 'Event'], 'Hurricane Force Wind Warning'], '#cc5b5b',
    ['==', ['get', 'Event'], 'Hurricane Force Wind Watch'], '#9831cb',
    ['==', ['get', 'Event'], 'Hurricane Local Statement'], '#fee3b4',
    ['==', ['get', 'Event'], 'Hurricane Warning'], '#db133b',
    ['==', ['get', 'Event'], 'Hurricane Watch'], '#fe00fe',
    ['==', ['get', 'Event'], 'Hydrologic Advisory'], '#00fe7e',
    ['==', ['get', 'Event'], 'Hydrologic Outlook'], '#8fed8f',
    ['==', ['get', 'Event'], 'Ice Storm Warning'], '#8a008a',
    ['==', ['get', 'Event'], 'Lake Effect Snow Advisory'], '#47d0cb',
    ['==', ['get', 'Event'], 'Lake Effect Snow Warning'], '#008a8a',
    ['==', ['get', 'Event'], 'Lake Effect Snow Watch'], '#86cdf9',
    ['==', ['get', 'Event'], 'Lake Wind Advisory'], '#d1b38b',
    ['==', ['get', 'Event'], 'Lakeshore Flood Advisory'], '#7bfb00',
    ['==', ['get', 'Event'], 'Lakeshore Flood Statement'], '#6a8d22',
    ['==', ['get', 'Event'], 'Lakeshore Flood Warning'], '#218a21',
    ['==', ['get', 'Event'], 'Lakeshore Flood Watch'], '#65cca9',
    ['==', ['get', 'Event'], 'Law Enforcement Warning'], '#bfbfbf',
    ['==', ['get', 'Event'], 'Local Area Emergency'], '#bfbfbf',
    ['==', ['get', 'Event'], 'Low Water Advisory'], '#a42929',
    ['==', ['get', 'Event'], 'Marine Weather Statement'], '#feeed4',
    ['==', ['get', 'Event'], 'Nuclear Power Plant Warning'], '#4a0081',
    ['==', ['get', 'Event'], 'Radiological Hazard Warning'], '#4a0081',
    ['==', ['get', 'Event'], 'Red Flag Warning'], '#fe1392',
    ['==', ['get', 'Event'], 'Rip Current Statement'], '#3fdfcf',
    ['==', ['get', 'Event'], 'Severe Thunderstorm Warning'], '#fea400',
    ['==', ['get', 'Event'], 'Severe Thunderstorm Watch'], '#da6f92',
    ['==', ['get', 'Event'], 'Severe Weather Statement'], '#00fefe',
    ['==', ['get', 'Event'], 'Shelter In Place Warning'], '#f97f71',
    ['==', ['get', 'Event'], 'Short Term Forecast'], '#97fa97',
    ['==', ['get', 'Event'], 'Small Craft Advisory'], '#d7bed7',
    ['==', ['get', 'Event'], 'Small Craft Advisory For Hazardous Seas'], '#d7bed7',
    ['==', ['get', 'Event'], 'Small Craft Advisory For Rough Bar'], '#d7bed7',
    ['==', ['get', 'Event'], 'Small Craft Advisory For Winds'], '#d7bed7',
    ['==', ['get', 'Event'], 'Small Stream Flood Advisory'], '#00fe7e',
    ['==', ['get', 'Event'], 'Special Marine Warning'], '#fea400',
    ['==', ['get', 'Event'], 'Special Weather Statement'], '#fee3b4',
    ['==', ['get', 'Event'], 'Storm Warning'], '#9300d2',
    ['==', ['get', 'Event'], 'Storm Watch'], '#fee3b4',
    ['==', ['get', 'Event'], 'Test'], '#effefe',
    ['==', ['get', 'Event'], 'Tornado Warning'], '#fe0000',
    ['==', ['get', 'Event'], 'Tornado Watch'], '#fefe00',
    ['==', ['get', 'Event'], 'Tropical Depression Local Statement'], '#fee3b4',
    ['==', ['get', 'Event'], 'Tropical Storm Local Statement'], '#fee3b4',
    ['==', ['get', 'Event'], 'Tropical Storm Warning'], '#b12121',
    ['==', ['get', 'Event'], 'Tropical Storm Watch'], '#ef7f7f',
    ['==', ['get', 'Event'], 'Tsunami Advisory'], '#d1681d',
    ['==', ['get', 'Event'], 'Tsunami Warning'], '#fc6246',
    ['==', ['get', 'Event'], 'Tsunami Watch'], '#fe00fe',
    ['==', ['get', 'Event'], 'Typhoon Local Statement'], '#fee3b4',
    ['==', ['get', 'Event'], 'Typhoon Warning'], '#db133b',
    ['==', ['get', 'Event'], 'Typhoon Watch'], '#fe00fe',
    ['==', ['get', 'Event'], 'Urban and Small Stream Flood Advisory'], '#00fe7e',
    ['==', ['get', 'Event'], 'Volcano Warning'], '#2e4e4e',
    ['==', ['get', 'Event'], 'Wind Advisory'], '#d1b38b',
    ['==', ['get', 'Event'], 'Wind Chill Advisory'], '#aeeded',
    ['==', ['get', 'Event'], 'Wind Chill Warning'], '#afc3dd',
    ['==', ['get', 'Event'], 'Wind Chill Watch'], '#5e9d9f',
    ['==', ['get', 'Event'], 'Winter Storm Warning'], '#fe68b3',
    ['==', ['get', 'Event'], 'Winter Storm Watch'], '#4581b3',
    ['==', ['get', 'Event'], 'Winter Weather Advisory'], '#7a67ed',
    '#eee'
];

let map,
    conversion,
    settings,
    lu,
    trending = false,
    newFires = [],
    CLUSTER_FIRES = true,
    highchartsLoad = false,
    chart,
    hrrrSmokeTime = {
        'init': gmtime(-3600),
        'fcst': gmtime(+3600)
    },
    dispatchCenters,
    selected = {
        caperim: null,
        ausperim: null,
        perim: null,
        evac: null,
        nri: null,
        erc: null
    },
    marker,
    touchTimer,
    topFires = [],
    clicks = [],
    radarImgs = [],
    radarAnim,
    RADAR_INT = 500,
    radarPlay = true,
    tracked = [],
    trackedDone = false,
    airQualityStns = [],
    activeEvacuations = null,
    evacsLoaded = false,
    controlsAtBottom = null,
    premFeature = '<i class="fas fa-lock" style="color:#a1d5e9" title="Subscribe to Map of Fire to gain access to this feature"></i>',
    tileConfig = [
        {
            id: 'outdoors',
            name: 'MAPO Outdoors',
            imgs: 'mapo_outdoors',
            permissions: []
        },
        {
            id: 'satellite',
            name: 'Satellite',
            imgs: 'satellite',
            permissions: []
        },
        {
            id: 'fs16',
            name: 'USFS 2016',
            imgs: 'fs_topo',
            permissions: ['PRO']
        },
        {
            id: 'dark',
            name: 'Dark',
            imgs: 'dark',
            permissions: []
        },
        {
            id: 'osm',
            name: 'OpenStreetMap',
            imgs: 'osm',
            permissions: []
        },
        {
            id: 'topofire',
            name: 'Topofire',
            imgs: 'topofire',
            permissions: ['PRO']
        },
        {
            id: 'terrain',
            name: 'Terrain',
            imgs: 'terrain',
            permissions: ['PREMIUM', 'PRO']
        },
        {
            id: 'voyager',
            name: 'Carto Voyager',
            imgs: 'voyager',
            permissions: ['PREMIUM', 'PRO']
        }
    ],
    icons = ['', 'out', 'big', 'controlled', 'contained', 'large', 'complex', 'new', 'new-big', 'rx', 'smoke'];

Object.freeze(config.PERMISSION_LEVELS);

config.tiles = {
    //outdoors: 'https://api.maptiler.com/maps/0198ce67-b3a9-7754-9811-60e2bf25e13a/style.json?key=ZeQEIVoqyieC6wk8qxJH',
    outdoors: config.host + 'data/maps/terrain.json',
    //outdoors: 'https://tiles.openfreemap.org/styles/liberty',
    satellite: config.host + 'data/maps/satellite.json',
    osm: osm,
    //fs16: fs16,
    fs16: config.host + 'data/maps/usfs.json',
    caltopo: caltopo,
    terrain: terrain,
    topofire: topofire,
    voyager: config.host + 'data/maps/voyager.json',
    dark: config.host + 'data/maps/dark.json'
    //dark: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json'
};

function debounce(fn, wait) {
    let timeout;
    return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => fn.apply(this, args), wait);
    };
}

async function api(uri, fields = null, v2 = false) {
    if (!navigator.onLine) {
        console.error('You are not connected to the internet');
        return null;
    }

    let result,
        url = v2 ? uri.replace('v1', 'v2') : uri;

    const isExternal = url.includes('weather.gov') || url.includes('unl.edu'),
        isInternal = url.includes(config.apiURL) || url.includes(config.apiURL.replace('v1', 'v2')) || url.includes(config.host),
        ops = {
            method: isExternal ? 'GET' : 'POST'
        },
        fd = new FormData();

    if (isInternal) fd.append('key', config.apiKey());

    if (fields && Array.isArray(fields)) {
        for (const [k, v] of fields) {
            fd.append(k, v);
        }
    }

    if (!isExternal) ops['body'] = fd;

    try {
        const resp = await fetch(url, ops);

        if (!resp.ok) {
            const errorText = await resp.text();
            console.error(`HTTP error! Status: ${resp.status}, URL: ${url}, Response: ${errorText}`);

            return null;
        }

        // Attempt to parse JSON
        result = await resp.json();
    } catch (e) {
        console.error(`Fetch or JSON parsing error for URL: ${url}`, e.message);
        result = null
    }

    return result;
}

function gmtime(s) {
    const d = new Date(Date.now() + s * 1000),
        pad = (n) => n.toString().padStart(2, '0'),
        year = d.getUTCFullYear(),
        month = pad(d.getUTCMonth() + 1),
        day = pad(d.getUTCDate()),
        hours = pad(d.getUTCHours());

    return `${year}-${month}-${day}T${hours}:00:00`;
}

function getbbox() {
    var b = map.getBounds(),
        sw = b.getSouthWest(),
        ne = b.getNorthEast();

    return (b ? JSON.stringify({
        xmin: ne.lng,
        ymin: sw.lat,
        xmax: sw.lng,
        ymax: ne.lat,
        spatialReference: {
            wkid: 4326
        }
    }) : false);
}

class ClickListener {
    constructor(target, sr) {
        this.target = target;
        this.sr = sr;
    }

    android() {
        sessionStorage.setItem('recommend_google_play', 1);
        document.querySelector('.android-banner').remove();
    }

    tools() {
        config.toolsInstance.clickListener(this.target);
    }

    myContent() {
        config.toolsInstance.myContent();
    }

    async mcta() {
        marketing(true, this.target.dataset.utm);
    }

    async copy(text = null, msg = null) {
        await navigator.clipboard.writeText(text != null ? text : this.target.innerText);
        notify('info', msg ? msg : 'Coordinates copied to clipboard');
    }

    closeDataForm() {
        const r = document.querySelector('li#report'),
            fw = document.querySelector('li#fwf');

        document.querySelector('#data-form')?.remove();
        document.querySelector('.shadow')?.remove();

        if (r?.dataset.active === '1') r.removeAttribute('data-active');
        if (fw.dataset.active === '1') fw.removeAttribute('data-active');
    }

    closeArchive() {
        window.location.href = window.location.href.replace(/archive\/([0-9]+)/g, '');
    }

    async clearSearch() {
        const q = document.querySelector('#q');
        if (!q) return;

        q.value = '';
        document.querySelector('#clearSearch')?.style.setProperty('display', 'none');
        new Search('').do();
        q.focus();
    }

    clearLayerSearch() {
        document.querySelectorAll('.layers-list li.layer').forEach(layer => layer.style.display = 'flex');
        impact.querySelector('#layerSearch').setProperty('value', '');
    }

    closeImpact() {
        if (map.getSource('user-features')) {
            map.removeSource('user-features');
            map.removeLayer('user-features-markers');
        }

        impact.removeAttribute('data-display');
        impact.style.display = 'none';
        impact.innerHTML = '';
    }

    openModal(aClass) {
        if (modal.hasAttribute('open')) return;

        modal.className = aClass || '';
        modal.querySelector('.content').innerHTML = '<div class="loading"><div class="s"></div></div>';

        const onTransitionEnd = (e) => {
            if (e.propertyName === 'top') {
                modal.removeEventListener('transitionend', onTransitionEnd);

                const event = new CustomEvent('modalOpened', { detail: { top: openPosition } });
                modal.dispatchEvent(event);
            }
        };

        const handle = modal.querySelector('.close'),
            viewportHeight = window.innerHeight,
            openPosition = viewportHeight * 0.3,    // 30 vh from top
            minTop = viewportHeight * 0.1,       // 10vh
            closedPosition = viewportHeight,     // 100%
            snapVelocity = 0.25,                 // px/ms
            throwStartThreshold = viewportHeight * 0.9; // only throw if near bottom

        let isDragging = false, startY = 0, startTop = 0, lastY = 0, lastTime = 0;

        modal.onModalChanged = function (callback, { once = true } = {}) {
            if (!this) return;

            const observer = new MutationObserver((mutations, obs) => {
                if (once) obs.disconnect();

                requestAnimationFrame(() => {
                    try {
                        callback();
                    } catch (err) {
                        console.error('onModalChanged error', err);
                    }
                });
            });

            observer.observe(this, {
                childList: true,
                subtree: true,
                characterData: true
            });

            return observer;
        };

        modal.onModalChanged(() => {
            const content = modal.querySelector('.content');

            requestAnimationFrame(() => {
                if (content.scrollHeight > content.clientHeight) {
                    content.scrollTo({ top: 0, behavior: 'smooth' });
                }
            });
        });
        modal.setAttribute('open', '');
        modal.style.top = `${closedPosition}px`;
        modal.style.transition = 'top 0.85s ease';

        // add event listener for when modal has finished opening
        modal.addEventListener('transitionend', onTransitionEnd);

        requestAnimationFrame(() => {
            modal.style.top = `${openPosition}px`;
        });

        if (handle) {
            handle.addEventListener('dblclick', () => {
                this.closeModal();
            });

            handle.addEventListener('pointerdown', (e) => {
                isDragging = true;
                startY = e.clientY;
                startTop = parseFloat(modal.style.top) || openPosition;
                lastY = startY;
                lastTime = performance.now();
                modal.style.transition = '';
                handle.setPointerCapture(e.pointerId);
            });

            handle.addEventListener('pointermove', (e) => {
                if (!isDragging) return;
                let deltaY = e.clientY - startY;
                let newTop = startTop + deltaY;

                newTop = Math.max(minTop, Math.min(closedPosition, newTop));
                modal.style.top = `${newTop}px`;

                lastY = e.clientY;
                lastTime = performance.now();
            });

            handle.addEventListener('pointerup', (e) => {
                if (!isDragging) return;
                isDragging = false;
                handle.releasePointerCapture(e.pointerId);

                const currentTop = parseFloat(modal.style.top);
                const deltaY = e.clientY - startY;
                const deltaTime = performance.now() - lastTime;
                const velocity = deltaTime > 0 ? deltaY / deltaTime : 0;

                modal.style.transition = 'top 0.2s ease';

                // 1. Fast downward flick AND dragged past threshold → close
                if (velocity > snapVelocity && currentTop > throwStartThreshold) {
                    modal.style.top = `${closedPosition}px`;
                    setTimeout(() => { this.closeModal(); }, 200);
                    return;
                }

                if (velocity < -snapVelocity) {
                    modal.style.top = `${minTop}px`;
                    return;
                }

                if (currentTop > viewportHeight * 0.7) {
                    modal.style.top = `${closedPosition}px`;
                    setTimeout(() => { this.closeModal(); }, 200);
                } else if (currentTop < viewportHeight * 0.3) {
                    modal.style.top = `${minTop}px`;
                } else {
                    modal.style.top = `${openPosition}px`;
                }

                setTimeout(() => (modal.style.transition = ''), 200);
            });
        }
    }

    closeModal() {
        modal.style.top = '100%';
        setTimeout(() => {
            modal.removeAttribute('open');
            modal.className = '';
            modal.innerHTML = '<div class="close" data-action="close-modal"><div class="handle"></div></div><div class="content"></div>';
        }, 200);

        unsetHeaders();
    }

    closePopup() {
        if (marker) marker.remove();
        if (!settings.isEnabled('stns') && map.getSource('stns')) {
            map.removeLayer('stns');
            map.removeLayer('stns_text');
            map.removeSource('stns');
        }

        document.querySelector('.popup')?.remove();

        unsetHeaders();

        ['caperim', 'ausperim', 'perim', 'evac', 'nri', 'erc'].forEach(key => {
            const source = key === 'caperim' ? 'ca_perimeters' : (key === 'ausperim' ? 'aus_perimeters' : key);
            if (selected[key] && map.getSource(source)) {
                map.removeFeatureState({ source, id: selected[key] });
            }
        });
    }

    closeNavbar() {
        if (!this.target) return;
        const nav = document.querySelector('nav'),
            isOpen = this.target.dataset.open === 'true',
            left = 'fa-chevron-left',
            right = 'fa-chevron-right';

        this.target.dataset.open = (!isOpen).toString();
        this.target.classList.replace(isOpen ? left : right, isOpen ? right : left);

        document.documentElement.style.setProperty('--nav-width', isOpen ? '40px' : '89px');
        nav?.classList.toggle('hide', isOpen);
    }

    newFire() {
        const dataset = this.target?.closest('li')?.dataset;
        if (!dataset) return;

        this.closeDataForm();

        map.easeTo({
            center: [dataset.lon, dataset.lat],
            zoom: 12,
            duration: 0
        });
    }

    sharer() {
        if (!navigator.share) return;

        navigator.share({
            title: (this.target.getAttribute('title') ? this.target.getAttribute('title') : document.title),
            text: "",
            url: (this.target.dataset.href ? this.target.dataset.href.split('#')[0] : window.location.href.split('#')[0])
        }).catch(console.error);
    }

    createLayers() {
        const zoom = map.getZoom();
        let content = '<div class="content"><div class="dark-input"><input type="text" id="layerSearch" placeholder="Filter through layers..."><i data-action="clear-layer-search" class="fat fa-xmark clearSearch"></i></div>';

        // Loop through layer categories
        Object.entries(layers.categories).forEach(([categoryId, categoryTitle]) => {
            content += `<div class="group"><h3 class="group-title">${categoryTitle}</h3><ul class="layers-list">`;

            // Loop through layers in each category
            layers.layers[categoryId].filter(lay => !lay.testing || (lay.testing && debugMode)).forEach(layer => {
                content += `<li class="layer${layer.minZoom && layer.minZoom > zoom ? ' more-zoom' : ''}"${layer.minZoom ? ' data-min-zoom="' + layer.minZoom + '"' : ''} data-p="${layer.perms}" data-id="${layer.id}" title="${layer.minZoom && layer.minZoom > zoom ? 'You must be zoomed in more' : layer.name}">
                    <div class="checkbox">
                        <input type="checkbox" id="${layer.id}" class="layChkBx" data-action="toggle-layer">
                    </div>
                    <div class="desc">
                        <label for="${layer.id}">${layer.name}</label>
                        <span>${layer.desc}</span>
                        ${this.layerExtras(layer)}
                    </div>
                </li>`;
            });

            content += '</ul></div>';
        });

        content += '</div>';
        config.layersMenu = content;
    }

    // show/open layers menu
    showLayers() {
        const scrollPosition = localStorage.getItem('mapofire.impactScroll');

        if (config.layersMenu == null) this.createLayers();

        impact.innerHTML = impactHeader + config.layersMenu;
        impact.querySelector('#a').innerHTML = 'Layers';

        config.listOfLayers.filter(lay => !lay.testing || (lay.testing && debugMode)).forEach(layer => {
            const hasPermissions = settings.hasPermissions(layer.perms),
                isChecked = (layer.default && !settings.checkboxes()) || (settings.checkboxes() && settings.isEnabled(layer.id)),
                item = impact.querySelector('li.layer[data-id="' + layer.id + '"]'),
                filter = item.querySelector('.data-filter'),
                box = item.querySelector('.checkbox');

            if (box) box.querySelector('input[type=checkbox]').checked = isChecked;

            if (layer.minZoom) {
                if (map.getZoom() >= item.dataset.minZoom) {
                    item.classList.remove('more-zoom');
                    item.setAttribute('title', String(item.querySelector('label').innerHTML));
                } else {
                    item.classList.add('more-zoom');
                    item.setAttribute('title', 'You must be zoomed in more');
                }
            }

            if (!hasPermissions) {
                item.classList.add('locked');

                if (filter) filter.style.display = 'none';

                box.innerHTML = premFeature;
                item.addEventListener('click', () => {
                    notify('info', `This is a ${layer.perms.includes('PREMIUM') ? 'premium' : 'pro'} layer. <a href="#" onclick="return false" data-action="marketing-cta" data-utm="layers_snackbar">Get access</a>`, 4);
                });
            } else {
                if (filter) {
                    const adjust = {
                        spc: [{
                            q: 'otlkType',
                            v: settings.special().otlkType()
                        }, {
                            q: 'otlkDay',
                            v: settings.special().otlkDay()
                        }],
                        erc: [{
                            q: 'erc_time',
                            v: settings.special().erc()
                        }],
                        sfp: [{
                            q: 'sfpDateSelect',
                            v: settings.special().sfpDate()
                        }],
                        ndfd: [{
                            q: 'forecastModel',
                            v: settings.special().forecastModel()
                        }/*, {
                            q: 'fcstTime',
                            v: settings.special().fcstTime()
                        }*/]
                    };

                    if (isChecked) filter.querySelectorAll('select').forEach(select => select.disabled = false);

                    const filterLayer = adjust[layer.id];

                    if (filterLayer) {
                        for (let i = 0; i < filterLayer.length; i++) {
                            const s = filter.querySelector(`#${filterLayer[i].q}`);
                            s.value = filterLayer[i].v;

                            if (!s.value) s.selectedIndex = 1;
                        }
                    }
                }
            }
        });

        impact.setAttribute('data-display', 'layers');
        impact.style.display = 'flex';

        if (scrollPosition !== null && scrollPosition !== '0') impact.scrollTop = scrollPosition;
    }

    // creates dropdowns for some layers
    layerExtras(l) {
        const spec = settings.special?.() || {},
            icon = (cls) => `<i class="${cls}" style="color:#9caab3"></i>`,
            wrap = (id, content) => `<div class="data-filter" id="${id}">${icon('far fa-filter-list')}<div>${content}</div></div>`,
            sel = (val, target) => val === target ? 'selected' : '',
            smokeOptions = () => Array.from({ length: 15 }, (_, i) => {
                const timeVal = gmtime(++i * 3600),
                    date = new Date(timeVal + '+00:00'),
                    hrs = date.getHours(),
                    isMid = hrs === 0,
                    day = date.getDate() === config.curTime.getDate() + 1 ? 'Tomorrow' : 'Today',
                    label = isMid ? 'Midnight' : `${day} at ${hrs % 12 || 12} ${hrs >= 12 ? 'PM' : 'AM'}`;

                return `<option value="${timeVal}">${label}</option>`;
            }).join('');

        const filters = {
            perimeters: () => {
                const size = settings.perimeters().minSize();

                return `<div class="data-filter" id="perimeterSize" data-action="change-perim-size">
                    ${icon('fad fa-filters')}
                    <input type="range" class="slider" min="0" max="1000" step="25" value="${size}">
                    <div id="pSize" style="width:69.11px">${size} acres</div>
                </div>`;
            },

            ndfd: () => {
                const model = spec.forecastModel || 'air_temperature',
                    opts = [
                        ['air_temperature', 'Temperature'],
                        ['relative_humidity', 'Humidity'],
                        ['wind_speed', 'Wind Speed'],
                        ['total_sky_cover', 'Cloud Cover'],
                        ['12hr_precipitation_probability', '12-hr POPs']
                    ].map(([v, n]) => `<option ${sel(v, model)} value="${v}">${n}</option>`).join('');

                return wrap('models', `<select id="forecastModel" data-action="ndfd" style="min-width:170px" disabled>${opts}</select>
                <select id="fcstTime" data-action="ndfd" data-type="reg" style="min-width:100px;max-width:35%" disabled>${initNDFDTimes().join('')}</select>`);
            },

            sfp: () => wrap('sfpDate', `<select id="sfpDateSelect" data-action="sfp-date" disabled>
                ${sfpTimes().map(i => `<option value="${i.key}">${i.value}</option>`).join('')}</select>`
            ),

            spc: () => {
                const type = spec.otlkType?.() || 'fire', day = spec.otlkDay?.() || 1;

                return wrap('otlks', `<select id="otlkType" data-action="spc-outlook" style="min-width:170px" disabled>
                    <option ${sel('fire', type)} value="fire">Fire Weather</option>
                    <option ${sel('severe', type)} value="severe">Severe/Convective</option></select>
                    <select id="otlkDay" data-action="spc-outlook" style="min-width:100px" disabled>
                    <option ${sel(1, day)} value="1">Day 1</option><option ${sel(2, day)} value="2">Day 2</option>
                    ${type !== 'fire' ? `<option ${sel(3, day)} value="3">Day 3</option>` : ''}</select>`
                );
            },

            erc: () => wrap('ercs', `<select id="erc_time" data-action="erc_time" style="min-width:197px" disabled>
                <option ${sel('obs', spec.erc?.())} value="obs">Observed (Today)</option>
                <option ${sel('fcst', spec.erc?.())} value="fcst">Forecasted (Tomorrow)</option></select>`
            ),

            viSmoke: () => wrap('viSmokes', `<select id="vi_smoke_time" data-action="vi_smoke_time" style="min-width:160px" disabled>${smokeOptions()}</select>`),

            sfcSmoke: () => wrap('sfcSmokes', `<select id="sfc_smoke_time" data-action="sfc_smoke_time" style="min-width:160px" disabled>${smokeOptions()}</select>`)
        };

        return filters[l.id]?.() || '';
    }

    basemaps() {
        const contentDiv = document.createElement('div');
        contentDiv.className = 'content';

        const basemapListUl = document.createElement('ul');
        basemapListUl.className = 'layers-list bm';

        tileConfig.forEach(tile => {
            const hasPerms = settings.hasPermissions(tile.permissions),
                isChecked = tile.id === settings.getBasemap(),
                listItem = document.createElement('li'),
                radioDiv = document.createElement('div'),
                descDiv = document.createElement('div');

            // Create the list item for the basemap
            listItem.dataset.tile = tile.id;

            // Create the radio and description containers
            radioDiv.className = 'radio';
            descDiv.className = 'desc';

            // Add the radio button or premium feature
            if (hasPerms) {
                const radioInput = document.createElement('input');
                Object.assign(radioInput, {
                    type: 'radio',
                    className: 'basemap-option',
                    name: 'bsmo',
                    checked: isChecked
                });
                radioInput.setAttribute('data-action', 'change-basemap');
                radioInput.setAttribute('data-tile', tile.id);
                radioDiv.appendChild(radioInput);
            } else {
                radioDiv.innerHTML = premFeature;

                radioDiv.addEventListener('click', () => {
                    const tier = tile.permissions.includes('PREMIUM') ? 'premium' : 'pro';
                    notify('info', `This is a ${tier} basemap. <a href="#" onclick="return false" data-action="marketing-cta" data-utm="basemaps_snackbar">Get access</a>`, 4);
                });
            }

            // Add the icon and label
            const img = document.createElement('img');
            img.src = `${config.domain}assets/images/icons/fire/basemaps/${tile.imgs}.png`;
            if (!hasPerms) img.style.opacity = '0.5';

            const label = document.createElement('label');
            label.innerHTML = tile.name + (tile.permissions.length ? '<p>' + tile.permissions[0] + '</p>' : '');

            // Assemble the list item
            descDiv.appendChild(img);
            descDiv.appendChild(label);
            listItem.appendChild(radioDiv);
            listItem.appendChild(descDiv);
            basemapListUl.appendChild(listItem);
        });

        // Update the DOM in a single, efficient operation
        impact.innerHTML = impactHeader;
        contentDiv.appendChild(basemapListUl);
        impact.appendChild(contentDiv);
        impact.style.display = 'flex';
        impact.querySelector('#a').innerHTML = 'Basemaps';

        // Use event delegation on the parent element
        basemapListUl.addEventListener('click', e => {
            const listItem = e.target.closest('li');
            if (!listItem) return;

            const radio = listItem.querySelector('input.basemap-option');
            if (radio) {
                radio.checked = true;
                radio.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });
    }

    acctSettings() {
        let content = '';
        const settings = [
            {
                t: 'Save Frequency',
                i: 'saveFreq',
                o: { 60000: '1 min', 300000: '5 mins', 600000: '10 mins', 900000: '15 mins', 1800000: '30 mins' }
            },
            {
                t: 'Perimeter Color',
                i: 'perimColor',
                o: { 'default': 'Default', 'red': 'Red', 'blue': 'Blue', 'orange': 'Orange', 'green': 'Green', 'purple': 'Purple', 'brown': 'Brown', 'black': 'Black' }
            },
            {
                t: 'Perimeter Tooltip',
                i: 'perimTtip',
                o: { 1: 'Yes', 0: 'No' }
            },
            {
                t: 'Perimeter Zoom',
                i: 'perimZoom',
                o: { 1: 'Yes', 0: 'No' }
            },
            {
                t: 'Coordinates',
                i: 'coordsDisplay',
                o: { 'dec': 'Decimal', 'dms': 'Degs, Mins, Secs', 'utm': 'UTM' }
            },
            {
                t: 'Temperature Unit',
                i: 'tempUnit',
                o: { 'f': '&deg;F', 'c': '&deg;C' }
            },
            {
                t: 'Wind Speed Unit',
                i: 'windUnit',
                o: { 'mph': 'mph', 'm/s': 'm/s', 'kts': 'kts', 'km/h': 'km/h' }
            },
            {
                t: 'Fire Size Unit',
                i: 'acresUnit',
                o: { 'acres': 'acres', 'hectares': 'hectares', 'sqmi': 'sq. mi.', 'sqkm': 'sq. km.' }
            },
            {
                t: 'Cache Fire Data',
                i: 'locallySave',
                o: { 'y': 'Yes', 'n': 'No' }
            }
        ];

        settings.forEach(setting => {
            const options = Object.entries(setting.o)
                .map(([val, label]) => `<option value="${val}">${label}</option>`)
                .join('');
            content += `<div class="r"><div class="var">${setting.t}</div><div class="input"><select id="${setting.i}" data-action="user-setting">${options}</select></div></div>`;
        });

        return content;
    }

    async account() {
        if (!settings.user) {
            const guid = document.cookie.split('; ').find(row => row.startsWith('guid='))?.split('=')[1] || null,
                url = config.domain.replace('www', 'auth') + 'login?service=' + getPlatform() + '&next=' + encodeURIComponent(window.location.href) + (guid ? '&guid=' + guid : '');
            ////console.log(url);
            window.location.href = url;
            return;
        }

        let ms = '';
        const userProfile = `<div class="content">
            <div id="sync">
                <i class="fa-regular fa-arrow-down-to-line" aria-hidden="true"></i>
                <span title="${dateTime(settings.getUser().synced(), true, true, true).toString()}">Account last synced ${timeAgo(settings.user.settings.synced)}</span>
            </div>
            <div id="settings">
                <div class="my-subs">
                    <h2>My Subscriptions</h2>
                    <div id="subs"></div>
                </div>
                <h2>Map Settings</h2>
                ${this.acctSettings()}
                <div class="btn-group centered" style="margin:var(--spacing) 0 0">
                    <a target="blank" class="btn btn-black" style="width:100%" href="${config.domain}account/settings">Manage account</a>
                </div>
                <div style="margin-top:5em;font-size:12px;text-align:center;color:var(--blue-gray);line-height:1.3">
                    &copy; ${new Date().getFullYear()} ${config.company}<br>Version ${version}<br>
                    <a class="footer-link" href="${config.specificURL}logout?service=${getPlatform()}&next=${encodeURIComponent(window.location.href)}">Logout</a>&nbsp;&middot;&nbsp;
                    <a class="footer-link" href="${config.host}release-notes" target="blank">Change Log</a>&nbsp;&middot;&nbsp;
                    <a class="footer-link" href="${config.domain}about/legal/terms" target="blank">Terms</a>&nbsp;&middot;&nbsp;
                    <a class="footer-link" href="${config.domain}about/legal/privacy" target="blank">Privacy</a>
                </div>
            </div>
        </div>`;

        impact.innerHTML = impactHeader + userProfile;
        impact.style.display = 'flex';
        impact.querySelector('#a').innerHTML = 'Hello, ' + settings.getUser().getName().first();

        const prefs = {
            'saveFreq': settings.get().saveFreq(),
            'perimColor': settings.perimeters().color() ?? 'default',
            'perimTtip': settings.perimeters().ttip() ?? 1,
            'perimZoom': settings.perimeters().zoom() ? 1 : 0,
            'coordsDisplay': settings.get().coordsDisplay() ?? 'dec',
            'tempUnit': settings.weather().temp() ?? 'f',
            'windSpeedUnit': settings.weather().wind() ?? 'mph',
            'acresUnit': settings.get().acres() ?? 'acres',
            'locallySave': settings.get().locallySave() ?? 'n'
        };

        Object.entries(prefs).forEach(([id, val]) => {
            const el = document.querySelector(`select#${id}`);
            if (el) el.value = val;
        });

        if (!settings.subscriptions().valid()) {
            const buy = purchaseLink('account', encodeURIComponent(window.location.href));
            ms = `<p style="color:var(--box-text-color)">
                You don\'t have a subscription to Map of Fire.
                <a class="btn btn-yellow" style="width:100%;margin:1em 0 0 0" href="${buy}">Try it for free!</a>
            </p>`;
        } else {
            let theEnd = 'Your subscription will automatically renew';

            if (settings.subscriptions().isTrial()) {
                theEnd = 'Your free trial ends ';
            }

            ms = `<div style="display:inline-flex;width:100%;justify-content:space-between;gap:1em">
                <div style="display:inline-flex;flex-direction:column;gap:0.45em">
                    <span>${settings.subscriptions().name()}</span>
                    <small style="line-height:1.1;color:#999">${theEnd} on ${settings.subscriptions().expires()}.</small>
                </div>
                <a class="btn btn-sm btn-black" style="margin:0;height:fit-content" target="blank" href="${config.domain}account/billing#cid=${settings.subscriptions().customerID()}">Manage</a>
            </div>`;
        }

        document.querySelector('#subs').innerHTML = ms;
    }

    radarPausePlay() {
        const c = document.querySelector('.radarControl');

        if (radarPlay) {
            clearInterval(radarAnim);
            c.classList.remove('fa-pause');
            c.classList.add('fa-play');
            c.title = 'Start radar';
            radarPlay = false;
        } else {
            let counter = document.querySelector('.radar input[type=range]').value,
                ra = () => {
                    radarImgs.forEach((e, n) => {
                        map.setLayoutProperty('radar-layer-' + n, 'visibility', (n == counter ? 'visible' : 'none'));
                        document.querySelector('.radar input[type=range]').value = counter;
                    });

                    if (counter == radarImgs.length - 1) {
                        counter = 0;
                        clearInterval(radarAnim);

                        setTimeout(() => {
                            radarAnim = setInterval(ra, RADAR_INT);
                        }, RADAR_INT);
                    } else {
                        counter++;
                    }
                };

            radarAnim = setInterval(ra, RADAR_INT);

            c.classList.add('fa-pause');
            c.classList.remove('fa-play');
            c.title = 'Pause radar';
            radarPlay = true;
        }
    }

    spcClimo() {
        if (this.target.classList.contains('disabled')) return;

        const select = document.querySelector('.spcTimeline #spcDates');
        let newIndex = select.selectedIndex;

        if (this.target.dataset.dir === 'back') newIndex -= 1;
        if (this.target.dataset.dir === 'next') newIndex += 1;

        newIndex = Math.max(0, Math.min(364, newIndex));

        config.layersHandler.spcClimo(newIndex, true, true);
    }

    async follow() {
        let id = parseInt(this.target.dataset.id),
            fire = config.wildfire.findFire(id),
            name = fire.properties.name.replace(' Fire', '') + (fire.properties.type != 'Smoke Check' ? ' Fire' : '');

        if (fire != null) {
            const isRemove = this.target.dataset.mode == 'unfollow' && tracked.includes(id),
                tf = document.querySelector('#trackFire');

            // remove, otherwise add
            const m = isRemove ? 'remove' : 'add';
            if (isRemove) tracked.splice(tracked.indexOf(id), 1); else tracked.push(id);

            if (m == 'add') {
                tf.setAttribute('data-mode', 'unfollow');
                tf.setAttribute('title', 'You\'re following this incident');
                tf.classList.add('btn-black');
                tf.classList.remove('btn-yellow');
                tf.innerHTML = '<i class="far fa-check"></i>Following this incident';
            } else {
                tf.setAttribute('data-mode', 'follow');
                tf.setAttribute('title', 'Start following this incident');
                tf.classList.remove('btn-black');
                tf.classList.add('btn-yellow');
                tf.innerHTML = '<i class="far fa-plus"></i>Follow this incident';
            }

            /* if user is logged in, save to account, otherwise store in local storage */
            if (settings.user) {
                await api(config.host + 'api/v1/trackFires/' + m, [['wfid', id]]);
            } else {
                localStorage.setItem('mapofire.tracked', JSON.stringify(tracked));
            }

            notify('success', (m == 'add' ? 'You\'re now following the ' : 'You\'re no longer following the ') + name + '.');
        }
    }

    async unfollow() {
        const id = this.target.dataset.wfid,
            name = this.target.dataset.name,
            myf = document.querySelector('ul.my-fires');

        this.target.parentElement.parentElement.remove();

        if (settings.user) {
            await api(config.host + 'api/v1/trackFires/remove', [['wfid', id]]);
        } else {
            const t = JSON.parse(localStorage.getItem('mapofire.tracked')),
                n = t.splice(t.indexOf(id), 1);

            localStorage.setItem('mapofire.tracked', JSON.stringify(n));
        }

        tracked.splice(tracked.indexOf(id), 1);

        if (myf.querySelectorAll('li').length == 0) myf.parentElement.innerHTML = noneTracked;

        notify('success', 'You\'re no longer following the ' + name + '.');
    }

    archive() {
        if (settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM)) {
            const yrs = Array.from({ length: config.curTime.getFullYear() - 2014 }, (_, idx) => {
                const year = config.curTime.getFullYear() - idx;
                return `<option ${year === config.curTime.getFullYear() ? 'disabled ' : ''}value="${year}">${year}</option>`;
            }).join('');

            new Popup('Historical Wildfires').create('<p style="font-size:14px;line-height:1.2">See historical wildfires by selecting a year in our archive.</p>' +
                '<select id="archive_years" data-action="archive_years" style="border:1px solid #cfcfcf;margin-top:1em"><option>- Choose a year -</option>' + yrs + '</select>' +
                '<div class="btn-group centered"><input type="button" class="btn btn-sm btn-gray" value="Cancel" onclick="this.parentElement.parentElement.parentElement.remove()"></div>');
        }
    }

    async legend() {
        //const { legend } = await loadUtils();

        if (!legend || !legend.categories || !legend.items) return;

        let legCont = '';

        legend.categories.forEach(cat => {
            const key = Object.keys(cat)[0];
            legCont += `<div class="group"><h3 class="group-title">${cat[key]}</h3>`;

            const items = legend.items[key];
            if (items && items.length) {
                items.forEach(item => {
                    const icon = item[0] === 'icon' ? item[1] : `<div class="color" style="background-color:${item[2]}">${item[1] ?? ''}</div>`;

                    legCont += `<div class="row"><div class="ic">${icon}</div><div class="desc">${item[3] ?? ''}</div></div>`;
                });
            }

            legCont += '</div>';
        });

        impact.innerHTML = impactHeader + `<div class="content"><div class="legend">${legCont}</div></div>`;
        impact.setAttribute('data-display', 'legend');
        impact.style.display = 'flex';
        const aEl = impact.querySelector('#a');
        if (aEl) aEl.innerHTML = 'Legend';
    }

    async myfires() {
        impact.innerHTML = impactHeader + '<div class="content"><div id="spinner" class="centered"></div></div>';
        impact.style.display = 'flex';
        impact.querySelector('#a').innerHTML = 'My Fires';

        await new Promise(resolve => {
            const check = setInterval(() => {
                if (trackedDone) {
                    clearInterval(check);
                    resolve();
                }
            }, 100);
        });

        const content = impact.querySelector('.content'),
            myFires = tracked.map(id => config.wildfire.findFire(id)).filter(fire => fire != null);

        if (myFires.length === 0) {
            content.innerHTML = tracked.length > 0 ? '<div class="message error">The wildfires you were following are no longer available.</div>' : noneTracked;
            return;
        }

        // build the list of "my fires"
        const ul = document.createElement('ul');
        ul.className = 'my-fires';

        myFires.forEach(fire => {
            const { properties: p, geometry } = fire,
                name = p.name,
                size = conversion.sizeFormat(p.acres),
                fstat = p.status,
                st = p.time.year < config.curTime.getFullYear() ? 'out' : config.wildfire.getStatus(fstat, p.notes) || 'active',
                state = p.near/*,
                up = timeAgo(p.time.updated)*/;

            const li = document.createElement('li');
            li.id = 'my-fire-incident';
            li.dataset.coords = JSON.stringify(geometry.coordinates);

            li.innerHTML = `<div class="header">
                <h3>${name}</h3>
                <i class="fas fa-circle-check" data-action="my-fire-unfollow" title="Unfollow this incident" data-name="${name}" data-wfid="${p.wfid}"></i>
            </div>
            <span class="state">${state}</span>
            <div class="inf">
                <p style="color:#fff;font-size:18px">${size}</p>
                <span class="status ${st}">${st.toUpperCase()}</span>
            </div>`;

            ul.appendChild(li);
        });

        // Use event delegation for clicks
        ul.addEventListener('click', event => {
            const li = event.target.closest('li#my-fire-incident');
            if (!li) return;

            const coords = JSON.parse(li.dataset.coords);
            if (coords) map.flyTo({ center: coords, zoom: 11.5 });
        });

        // Replace spinner with list
        content.innerHTML = '';
        content.appendChild(ul);
    }

    searchResultClick() {
        const p = this.target.closest('li'),
            type = p.dataset.type;

        if (marker) marker.remove();

        if (!p.classList.contains('standby')) {
            const lat = p.dataset.lat,
                lon = p.dataset.lon;

            // zoom to a marker of a city location
            if (type == 'city') {
                const name = p.dataset.name.split(', ');

                marker = new maplibregl.Marker()
                    .setLngLat([lon, lat])
                    .addTo(map);

                new Popup('City').create(`<p style="margin-bottom:6px;color:#fff">${name[0]}, ${p.dataset.county} County, ${name[1]}</p>
                    <span style="display:block;font-size:14px">${lat}, ${lon}</span>`);

                map.easeTo({
                    center: new maplibregl.LngLat(lon, lat),
                    zoom: 10
                });
            }
            // zoom to marker of a GIS feature (POI)
            else if (type == 'gis') {
                const name = p.dataset.name.split(', '),
                    county = p.dataset.county,
                    geoType = p.dataset.geotype;

                marker = new maplibregl.Marker()
                    .setLngLat([lon, lat])
                    .addTo(map);

                new Popup(geoType).create(name[0] + ', ' + county + ' County, ' + name[1]);

                map.easeTo({
                    center: new maplibregl.LngLat(lon, lat),
                    zoom: 11.25
                });
            }
            // zoom to boundaries of a state or a county
            else if (type == 'state' || type == 'county') {
                const bbox = JSON.parse(p.dataset.bbox);

                map.fitBounds([
                    [bbox.x.min, bbox.y.min],
                    [bbox.x.max, bbox.y.max]
                ], {
                    padding: 50
                });
            }
            // zoom in on coordinates
            else if (type == 'coordinates') {
                marker = new maplibregl.Marker()
                    .setLngLat([lon, lat])
                    .addTo(map);

                new Popup('Coordinates').create(`<p style="padding-bottom:8px;color:#fff">${lat},&nbsp;${lon}</p>
                    <span style="display:block;padding-bottom:4px;font-size:14px">${String(conversion.convertToDms(lat, false) + '&nbsp;' + conversion.convertToDms(lon, true)).replace(/\s/g, '')}</span>
                    <span style="display:block;font-size:14px">${conversion.utm(lat, lon)}</span>`);

                map.easeTo({
                    center: [lon, lat],
                    zoom: 10
                });
            }
            // zoom to a wildfire
            else {
                const wfid = parseInt(p.dataset.wfid);
                if (config.wildfire.findFire(wfid)) config.wildfire.incident(wfid, true);
            }
        }

        this.sr.innerHTML = '<li class="standby" style="gap:.5em"><i class="fa-duotone fa-spinner-third" aria-hidden="true"></i><span>Searching...</span></li>';
        this.sr.style.display = 'none';

        return this;
    }
}

function toggleLayer(e) {
    const { id: layerId, checked } = e,
        action = layerActions[layerId],
        getLayer = config.listOfLayers.find(layer => layer.id === layerId),
        layerPerms = getLayer ? getLayer.perms : false,
        executeToggle = (sourceId, action, checked) => {
            const visibility = checked ? 'visible' : 'none';

            if (sourceId == 'visSatellite') sourceId = 'satellite1';
            else if (sourceId == 'irSatellite') sourceId = 'satellite2';
            else if (sourceId == 'wvSatellite') sourceId = 'satellite3';

            if (map.getSource(sourceId)) {
                action.layers.forEach(id => map.setLayoutProperty(id, 'visibility', visibility));
            } else if (checked) {
                action.exe();
            }
        };

    if (!action || !settings.hasPermissions(layerPerms)) return;

    if (action.run) {
        action.run(checked);
    } else if (action.exe) {
        executeToggle(layerId, action, checked);
    } else {
        action.layers.forEach(id => map.setLayoutProperty(id, 'visibility', checked ? 'visible' : 'none'));
    }
}

async function getCounties() {
    const ArcGISFeatureSource = window[""]["arcgis-featureserver"];

    if (!map.getSource('us_counties')) {
        new ArcGISFeatureSource('us_counties', map, {
            url: 'https://services.arcgis.com/P3ePLMYs2RVChkJx/ArcGIS/rest/services/USA_Counties_Generalized_Boundaries/FeatureServer/0',
            precision: 6,
            where: '1=1',
            outFields: 'NAME,STATE_ABBR AS STATE,FIPS,POPULATION,SQMI'
        });
    }

    if (!map.getLayer('us_counties')) {
        map.addLayer({
            id: 'us_counties',
            source: 'us_counties',
            type: 'fill',
            paint: {
                'fill-opacity': 0,
                'fill-color': '#fff'
            },
            layout: {
                visibility: 'visible'
            }
        });
    }

    if (!map.getLayer('county-boundaries')) {
        map.addLayer({
            id: 'county-boundaries',
            source: 'us_counties',
            type: 'line',
            minzoom: 6,
            paint: {
                'line-dasharray': [
                    'step',
                    ['zoom'],
                    ['literal', [2, 0]],
                    7,
                    ['literal', [3, 4]],
                    12,
                    ['literal', [2, 3, 3, 4]]
                ],
                'line-opacity': [
                    'step',
                    ['zoom'],
                    0,
                    6.5,
                    0.15,
                    7,
                    0.3,
                    9.5,
                    0.5,
                    16,
                    0.8
                ],
                'line-color': [
                    'step',
                    ['zoom'],
                    '#484932',
                    13,
                    '#22221b',
                    15,
                    '#6e3066'
                ],
                'line-width': [
                    'step',
                    ['zoom'],
                    1,
                    12,
                    2,
                    16,
                    1.5
                ]
            }
        });
    }

    /*map.addSource('property_lines', {
        type: 'raster',
        minzoom: 15,
        tiles: ['https://tiles.arcgis.com/tiles/KzeiCaQsMoeCfoCq/arcgis/rest/services/Regrid_Nationwide_Parcel_Boundaries_v1/MapServer/tile/{z}/{y}/{x}'],
        attribution: '&copy; Regrid'
    });

    map.addLayer({
        id: 'property_lines',
        type: 'raster',
        source: 'property_lines',
        paint: {
            'raster-opacity': 1
        }
    });*/
}

function addDynamicControls() {
    const useBottom = window.innerWidth <= 500;

    if (useBottom === controlsAtBottom) return;
    controlsAtBottom = useBottom;

    const list = useBottom ? [...mapControls].reverse() : mapControls;
    mapControls.filter(c => map.hasControl(c)).forEach(c => map.removeControl(c));
    list.forEach(c => map.addControl(c, useBottom ? 'bottom-right' : 'top-right'));

    const c = ['fullscreen', 'zoom-in', 'zoom-out', 'compass', 'geolocate'],
        t = ['Enter fullscreen', 'Zoom in', 'Zoom out', 'Reset bearing to north', 'Find my location'];

    for (let i = 0; i < c.length; i++) {
        const it = document.querySelector('.maplibregl-ctrl-' + c[i]);
        if (!it) return;

        it.classList.add('ttip');
        it.dataset.tooltip = t[i];
    }
}

async function init() {
    let ctr_lat = settings.map().lat,
        ctr_lon = settings.map().lon;

    map = new maplibregl.Map({
        container: 'map',
        zoom: settings.map().zoom,
        center: [ctr_lon, ctr_lat],
        style: config.tiles[settings.getBasemap()],
        projection: 'mercator',
        hash: true,
        maxPitch: 85,
        pitch: (settings.map().pitch ? settings.map().pitch : 0),
        bearing: (settings.map().bearing ? settings.map().bearing : 0),
        attributionControl: false
    });

    /* add map controls */
    map.once('load', async () => {
        map.getCanvas().setAttribute('role', 'region');
        map.getCanvas().ariaLabel = document.querySelector('meta[name=description]').content;
        mapControls.push(new maplibregl.FullscreenControl({
            container: document.body
        }));
        mapControls.push(new maplibregl.NavigationControl({
            showCompass: true,
            showZoom: true,
            visualizePitch: true
        }));
        mapControls.push(new maplibregl.GeolocateControl({
            positionOptions: {
                enableHighAccuracy: true
            },
            fitBoundsOptions: {
                maxZoom: 10.16
            },
            trackUserLocation: true,
            showUserHeading: true
        }));

        map.addControl(
            new MFAttribControl({
                compact: true,
                collapseBelow: 920
            }),
            'bottom-right'
        );

        map.addControl(
            new maplibregl.ScaleControl({
                unit: 'imperial'
            }),
            'bottom-left'
        );

        addDynamicControls();
    });

    map.once('styledata', () => {
        const loading = document.querySelector('.loading');

        /* preload sample images of the basemaps */
        tileConfig.forEach((item, index) => {
            const img = new Image();
            img.src = config.domain + 'assets/images/icons/fire/basemaps/' + item.imgs + '.png';
            tileConfig[index].cache = img;
        });

        /* hide loading div once map is rendered */
        if (loading) {
            loading.remove();
            document.querySelector('.filter-controls .search').style.display = 'inline-flex';
        }
    });

    /* handle on map style loaded event */
    map.on('style.load', async () => {
        /* add banner for archived maps to let the user know */
        if (settings.archive) {
            const b = document.createElement('div');
            b.classList.add('message', 'banner');
            b.innerHTML = '<a href="#" title="Return to current fires" data-action="close-historical"><i class="fas fa-xmark"></i></a><span>You are viewing a historical wildfire map for <b><u>' + settings.archive + '</u></b></span>';
            document.body.appendChild(b);
        }

        getCounties();

        map.setSky(config.fog);

        /* add fire icons */
        const loadMapIcons = () => {
            const queue = [
                ...icons.map(i => ({ id: `fire-icon${i ? '-' + i : ''}`, path: `fire/fire-icon${i ? '-' + i : ''}.png` })),
                ...['helicopter', 'plane_tactical', 'plane_large', 'plane_small'].map(i => ({ id: i, path: `fire/${i}.png` })),
                ...[1, 2, 3].map(i => ({ id: `modis${i}`, path: `fire/modis${i}.png` }))
            ];

            queue.forEach(async ({ id, path }) => {
                if (!map.hasImage(id)) {
                    const img = await map.loadImage(`${config.domain}assets/images/icons/${path}`);
                    map.addImage(id, img.data);
                }
            });
        };

        loadMapIcons();

        // add terrain on contour lines
        new Layers().addTerrain();

        /* if user has settings saved, go to their saved location...not the mapbox hash location */
        if (window.location.hash) {
            const h = window.location.hash.replace('#', '').split('/');

            if (settings.map().lat == h[1] && settings.map().lon == h[2] && settings.map().zoom == h[0]) {
                map.easeTo({
                    center: [settings.map().lon, settings.map().lat],
                    zoom: settings.map().zoom,
                    duration: 1000
                });
            }
        }

        /* function to provide a popup soliciting donations, subscriptions, etc. */
        if (!settings.subscriptions().valid()) {
            setTimeout(async () => { marketing(); }, 3000);
        }

        /* zoom to that country if URL contains country/{theCountry} */
        if (country) {
            const bounds = {
                'austrailia': { c: [133.7751, -25.2744], z: 3.5 },
                'canada': { c: [-106.3468, 56.1304], z: 4.2 }
            }[country.toLowerCase()];

            map.easeTo({ center: bounds.c, zoom: bounds.z, duration: 1000 });
        }

        /* zoom to that state if URL contains state/{theState} */
        if (state) {
            Object.keys(stateLabels).forEach(async (e) => {
                if (stateLabels[e].name == state) {
                    map.easeTo({ center: stateLabels[e].center, zoom: 5.8, duration: 1000 });
                }
            });
        }

        // attach the layers handler
        config.layersHandler = new Layers();

        /* processing layers on startup */
        config.layersHandler.init();
        config.wildfire.getWildfires();
        config.wildfire.perimeters();

        const excludeTheseLayers = ['newFires', 'allFires', 'smokeChecks', 'rxBurns', 'perimeters'];

        if (settings.checkboxes()) {
            settings.checkboxes()
                .filter(c => !excludeTheseLayers.includes(c))
                .forEach(c => toggleLayer({ id: c, checked: true }));
        }
    });

    /* handle on map error event */
    map.on('error', (e) => {
        if (e && e.error.status != 500) { }
    });

    /* handle on map zoom end event */
    map.on('zoomend', () => {
        // if a layer requires a minimum zoom, and the layers menu is open, toggle opacity
        if (impact.style.display != 'none') {
            impact.querySelectorAll('.content li').forEach(li => {
                const isLow = map.getZoom() < li.dataset.minZoom;

                li.classList.toggle('more-zoom', isLow);
                li.title = isLow ? 'You must be zoomed in more' : li.querySelector('label').innerText;
            });
        }

        /* control whether FS roads show on the map based on the zoom level */
        if (settings.isEnabled('roads')) {
            if (!map.getLayer('roads')) config.layersHandler.roads();

            if (map.getLayer('roads')) map.setLayoutProperty('roads', 'visibility', map.getZoom() <= 11 ? 'none' : 'visible');
        }

        /* control whether modis hotspots show on the map based on the zoom level */
        [{ n: '24', w: 1 }, { n: '48', w: 2 }, { n: '72', w: 3 }].forEach(item => {
            const name = 'modis' + item.n,
                vis = map.getLayer(name) ? 'visible' : 'visible';

            if (settings.isEnabled(name)) {
                if (!map.getLayer(name)) config.layersHandler.modis(item.w);

                map.setLayoutProperty(name, 'visibility', map.getZoom() < config.modisZoomLevel ? 'none' : vis);
            }
        });
    });

    /* handle on map click events */
    map.on('click', async (e) => {
        mapClick(e);
    });

    map.on('contextmenu', async (e) => {
        e.preventDefault();
        contextMenu(e);
    });

    map.getContainer().addEventListener('touchstart', async (e) => {
        touchTimer = setTimeout(async () => {
            e.preventDefault();
            e.stopPropagation();

            contextMenu(e, true);
        }, 500);
    });

    map.getContainer().addEventListener('touchend', () => clearTimeout(touchTimer));
    map.getContainer().addEventListener('touchmove', () => clearTimeout(touchTimer));

    /* handle on start map move event */
    map.on('movestart', () => {
        map.getCanvas().style.cursor = 'grabbing';
        startLat = map.getCenter().lat;
        startLon = map.getCenter().lng;
    });

    /* handle on end map move event */
    map.on('moveend', async () => {
        map.getCanvas().style.cursor = 'auto';
        moveEnd();
    });
}

function upgrade() {
    const items = ['dispatch', 'dispatch_time', 'impactScroll', 'marketing', 'version', 'clicks', 'tracked'];

    items.forEach(item => {
        const v = localStorage.getItem(item);

        if (v != null) {
            localStorage.setItem(`mapofire.${item}`, v);
            localStorage.removeItem(item);
        }
    });
}

async function popstate() {
    // if user is trying to view historical fires without a subscription
    if (!settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM) && window.location.href.match(/archive=([0-9]+)/g) != null) {
        notify('info', 'You must upgrade to view historical fires. <a href="#" onclick="return false" data-action="marketing-cta" data-utm="archive_snackbar">Get access</a>', 6);
    }

    if (/loggedOut=1/.test(window.location.href)) {
        notify('success', 'You were successfully logged out.');
    }

    /* if URL is supposed to open an incident */
    if (window.location.pathname.search('/fires') >= 0) {
        let id = window.location.pathname.split('/')[2];
        config.wildfire.incident(id, false);
    }

    /* if URL is supposed to open a weather alert */
    if (window.location.pathname.search('/weather/alert') >= 0) {
        const id = window.location.pathname.split('/')[3];
        new NWS().readWWA(id, false);
    }

    /* if URL is supposed to open current weather conditions at a wx stn */
    if (window.location.pathname.search('/weather/current') >= 0) {
        const stnid = window.location.pathname.split('/')[3];
        new Weather().findWXStn(stnid);
    }

    /* if URL is supposed to open a SPC outlook */
    if (window.location.pathname.search('/weather/outlook') >= 0) {
        const p = window.location.pathname.split('/'),
            type = p[3],
            day = p[4];

        new NWS().getOutlookText(type, day, false);
    }

    /* if URL is supposed to open a fire weather forecast */
    if (window.location.pathname.search('/weather/forecast') >= 0) {
        const loc = window.location.pathname.split('/')[3].split(','),
            lat = parseFloat(loc[0]),
            lon = parseFloat(loc[1]),
            isValid = (lat >= -90 && lat <= 90) && (lon >= -180 && lon <= 180);

        if (isValid && settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM)) {
            new Weather(lat, lon).fireWxFcst();
        } else {
            unsetHeaders();
        }
    }

    if (window.location.search && window.location.search.search('loggedOut') >= 0) {
        window.history.pushState({
            "pageTitle": document.title
        }, '', window.location.href.replace(window.location.search, ''));
    }
}

document.onreadystatechange = async () => {
    const preload = async () => {
        conversion = new Convert();

        let usr = null,
            set,
            token = (/\btoken=(.*?)(?=;|$)/gm).exec(document.cookie),
            versioning = () => {
                const sv = localStorage.getItem('mapofire.version'),
                    lv = localStorage.getItem('mapofire.version');

                if (sv == null || sv != version) localStorage.setItem('mapofire.version', version);
                if (lv == null || lv != layers.build) localStorage.setItem('mapofire.layers_version', layers.build);
            };

        versioning();

        // create a list of layers
        Object.entries(layers.categories).forEach(([id, _]) => {
            layers.layers[id].forEach(each => config.listOfLayers.push(each));
        });

        // get the user's IP address and UUID from the server (DONT BLOCK UI THREAD)
        if (sessionStorage.getItem('mapofire.user_session') == null) {
            api(config.host + 'api/v1/session/get').then(sess => {
                delete sess.metadata;
                sessionStorage.setItem('mapofire.user_session', JSON.stringify(sess));
            });
        }

        if (token != null) {
            const acct = document.querySelector('#account'),
                get = await api(config.apiURL + 'user/get/mapofire', [['token', token[1]]]);

            usr = get.user;

            /* change menu button */
            if (usr != null) acct.querySelector('span').innerHTML = 'Account';
        } else {
            document.querySelector('#save').remove();
        }

        // show the nav menu
        document.querySelector('nav ul').style.display = 'flex';

        // show the "close navbar" menu when screen width > 600px
        if (window.innerWidth > 600) document.querySelector('#close-navbar').classList.add('show');

        // create settings class based on user profile and settings
        settings = new Settings(usr);

        /* * * * 
        // if user is admin, load the tools functions
        if (settings.hasPermissions(config.PERMISSION_LEVELS.ADMIN)) {
            setTimeout(() => {
                loadScript(config.specificURL + (debugMode ? 'v' + version + '/mf.tools.js' : 'src/js/mf.tools-' + version + '.js')).then(() => {
                    config.toolsInstance = new Tools();
                    config.toolsInstance.use();
                });
            }, 1500);
        }
        * * * */

        if (settings.getUser().role() != 'ADMIN') {
            document.querySelector('.filter-controls').addEventListener('contextmenu', (e) => e.preventDefault());
        }

        // add fire weather and historical menu options (disabled them if user doesn't have correct perms)
        const makeItem = (opts) => {
            const el = document.createElement('li');
            el.id = opts.id;
            el.className = 'ttip light';
            //if (!settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM)) el.classList.add('disabled');
            el.dataset.action = opts.id;
            el.dataset.tooltip = opts.ttip;
            el.innerHTML = '<i class="far fa-' + opts.icon + '"></i><span>' + opts.span + '</span>';
            document.querySelector('#' + opts.insert)?.insertAdjacentElement('afterend', el);
        };

        makeItem({ id: 'fwf', icon: 'cloud-bolt', span: 'Fire WX', insert: 'my-fire', ttip: 'Fire Weather Forecast' });
        makeItem({ id: 'archive', icon: 'calendars', span: 'Historical', insert: 'layers', ttip: 'Historical Fires' });

        // 1) start a wildfire class 2) get user's currently tracked wildfires 3) get austrailian bush fires
        config.wildfire = new Wildfires();
        config.wildfire.getTrackedFires();
        config.wildfire.getBushfireNames();

        // initialize map
        const idle = window.requestIdleCallback ? window.requestIdleCallback : (cb) => setTimeout(cb, 1);

        idle(async () => {
            if (typeof maplibregl === 'undefined') return;

            loadDispatchCenters();
            init();
            popstate();
        }, { timeout: 3250 });
    };

    const complete = async () => {
        const q = document.querySelector('#q');

        /* if the user is on an Android device, show the download app banner */
        if (/android/.test(navigator.userAgent.toLowerCase()) && !sessionStorage.getItem('recommend_google_play')) {
            document.querySelector('.android-banner').style.display = 'flex';
        }

        impact.addEventListener('scroll', () => {
            localStorage.setItem('mapofire.impactScroll', impact.scrollTop);
        });

        q.addEventListener('blur', () => {
            trending = false;
        });

        q.addEventListener('focus', async () => {
            if (q.value == '' && !trending && searchResults.querySelectorAll('li.trending').length == 0) {
                addTrending();
            }
        });

        // attach tooltip binders to class
        const tooltip = new Tooltips({ followMouse: false });
        tooltip.attach('.ttip', (el) => el.dataset.tooltip);
    };

    if (document.readyState != 'complete') {
        preload();
    } else {
        complete();
    }
};

window.onload = async () => {
    /* get top clicked fires */
    const getTopFires = await api(config.apiURL + 'events?test=1', [['limit', 6]]);
    if (top) topFires = getTopFires.top;

    /* save settings automatically after the first 10 seconds, then every 5 minutes, whether to the session or user account */
    setTimeout(function () {
        saveSession(true, false);

        setInterval(() => {
            if (document.visibilityState === 'visible') {
                saveSession(true, false);
            }
        }, settings.get().saveFreq());
    }, 90000);

    /* send fire click data to server for processing every 20 secs */
    setInterval(() => {
        config.wildfire.commitLog();
    }, 20000);

    upgrade();
    //localStorage.setItem('mapofire.refresh', new Date().getTime());

    /* reload the map automatically every 5 minutes */
    setInterval(() => {
        window.location.href = window.location.href;
    }, 60 * 5 * 1000);

    /* add service worker to handle additional js execution */
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register(config.specificURL + (debugMode ? 'v' + version + '/service-worker.js' : 'src/js/service-worker-' + version + '.js'))
            .then(registration => {
                if (registration.active) {
                    registration.active.postMessage({
                        'version': version,
                        'mbVersion': mbVersion,
                        'host': config.specificURL
                    });
                }
            })
            .catch(error => console.error('Service worker registration failed:', error));
    }
};

/* click event listener */
window.addEventListener('click', async (e) => {
    const target = e.target,
        contextMenu = document.querySelector('.context-menu'),
        actionsThatOpenImpact = ['account', 'basemap', 'layers', 'legend', 'myfires', 'tools', 'back-my-content'],
        actionElement = target.closest('[data-action]'),
        action = actionElement ? actionElement.dataset.action : null,
        clickListener = new ClickListener(target, searchResults),
        actionHandlers = {
            //'close-modal': () => clickListener.closeModal(),
            'copy': () => clickListener.copy(),
            'tools': () => clickListener.tools(),
            'blazeboard': () => window.open(config.host + 'blazeboard?utm_campaign=blazeboard&utm_medium=mapofire.com&utm_source=menu'),
            'close-android': () => clickListener.android(),
            'back-my-content': () => clickListener.myContent(),
            'close-historical': () => clickListener.closeArchive(),
            'close-popup': () => clickListener.closePopup(),
            'clear-search': () => clickListener.clearSearch(),
            'close-data-form': () => clickListener.closeDataForm(),
            'close-impact': () => clickListener.closeImpact(),
            'sr-onclick': () => clickListener.searchResultClick(),
            'close-navbar': () => clickListener.closeNavbar(),
            'clear-layer-search': () => clickListener.clearLayerSearch(),
            'dropdown-nav': () => document.querySelector('nav').classList.toggle('open'),
            'new-fires': () => clickListener.newFire(),
            'readSPC': async () => {
                const ds = target.dataset;
                new NWS().getOutlookText(ds.type, ds.day);
            },
            'marketing-cta': () => clickListener.mcta(),
            /*'upgrade-subscription': async () => {
                gtag('event', 'subscription_cta_click', {
                    'event_category': 'Subscription',
                    'event_label': e.target.dataset.medium,
                    'source': e.target.dataset.medium
                });

                window.location.href = purchaseLink(e.target.dataset.medium);
            },*/
            'incident_wx-fwf': () => {
                new Weather(e.target.dataset.lat, e.target.dataset.lon).fireWxFcst();
            },
            'sharer': () => clickListener.sharer(),
            'radar-control': () => clickListener.radarPausePlay(),
            'trackFire': () => clickListener.follow(),
            'readWWA': async () => new NWS().readWWA(target.dataset.id),
            'my-fire-unfollow': () => clickListener.unfollow(),
            'account': () => clickListener.account(),
            'new_fires': () => newFiresReport(),
            'basemap': () => clickListener.basemaps(),
            'layers': () => clickListener.showLayers(),
            'legend': () => clickListener.legend(),
            'spc-climo': () => clickListener.spcClimo(),
            'changeSPCDate': () => clickListener.changeSPCDate(),
            'fwf': async () => {
                if (!settings.subscriptions().valid()) {
                    marketing(true, 'nav_fwf');
                } else {
                    document.querySelector('li#fwf').setAttribute('data-active', '1');
                    map.getCanvas().style.cursor = 'crosshair';
                    notify('info', 'Click anywhere on get the fire weather forecast.');
                }
            },
            'myfires': () => clickListener.myfires(),
            'refresh': () => location.reload(),
            'archive': async () => {
                if (!settings.subscriptions().valid()) {
                    marketing(true, 'nav_archive');
                } else {
                    clickListener.archive();
                }
            },
            'report': async () => {
                document.querySelector('li#report').setAttribute('data-active', '1');
                map.getCanvas().style.cursor = 'crosshair';
                notify('info', 'Click anywhere on the map to report a <b>NEW</b> fire incident.');
            },
            'measure': () => new Tools().startMeasure(),
            'save': () => saveSession(false, true)
        };

    if (action != null && actionHandlers[action]) {
        actionHandlers[action]();
    }

    if (document.querySelector('body nav .nav-wrapper ul').contains(target)) {
        if (target.closest('li')) {
            document.querySelector('nav').classList.toggle('open');
        }
    }

    if (contextMenu && !target.contains(contextMenu) && e.target !== contextMenu) {
        contextMenu.remove();
    }

    /* hide search results if outside search result container */
    if (!target.contains(searchResults) && (target.parentElement && !target.parentElement.contains(searchResults)) && !target.contains(document.querySelector('#q'))) {
        searchResults.style.display = 'none';
        document.querySelector('#q').value = '';

        searchResults.querySelectorAll('li:not(.standby)').forEach(li => li.remove());
    }

    /* hide impact panel if outside of container */
    if (impact != null && impact.style.display == 'flex' && !impact.contains(e.target) && e.target !== impact && impact.dataset.display !== 'my-content') {
        if (!actionsThatOpenImpact.includes(action) && !document.querySelector('nav').contains(e.target)) {
            clickListener.closeImpact();
        }
    }
});

window.addEventListener('resize', async () => {
    const nav = document.querySelector('nav'),
        nb = document.querySelector('#close-navbar');

    if (window.innerWidth < 600) {
        if (nav.classList.contains('hide')) {
            document.documentElement.style.setProperty('--nav-width', '100px');
            nav.classList.remove('hide');
        }

        nb.classList.remove('show');
    } else {
        nb.classList.add('show');
    }

    debounce(addDynamicControls(), 150);
});

window.addEventListener('keydown', (e) => {
    const isPasteAction = (e.ctrlKey || e.metaKey) && (e.key === 'v' || e.key === 'V'),
        isSystemKey = e.altKey || e.key === 'Enter' || e.key === 'Shift' || e.key === 'Escape',
        isFindShortcut = (e.ctrlKey || e.metaKey) && (e.key === 'f' || e.key === 'F'),
        isTypingKey = !e.ctrlKey && !e.metaKey && !e.altKey && !isSystemKey,
        searchBox = document.querySelector('#q');

    config.runSearch = false;

    // if the user presses the esc key
    if (e.code == 'Escape') {
        if (isVisible('#modal')) new ClickListener().closeModal();

        if (isVisible('.popup')) {
            marker?.remove();
            document.querySelector('.popup')?.remove();
        }

        // clear/close search features
        if (e.target === searchBox) {
            searchBox.value = '';
            searchBox.blur();
            searchResults.style.display = 'none';

            searchResults.querySelectorAll('li:not(.standby)').forEach(li => li.remove());
        }
    }

    // if the user pressed ctrl + f, focus the search box
    if (isFindShortcut) {
        e.preventDefault();
        searchBox.focus();
        return;
    }

    // onkeydown in the search box
    if (e.target?.id == 'q') {
        if (/^(Arrow|Shift|Control|Alt|Tab|CapsLock|Escape)/.test(e.key)) return;

        const searchVisible = searchResults.style.display !== 'none' && searchResults.style.display !== '',
            standby = searchResults.querySelector('.standby');

        if (isTypingKey || isPasteAction) {
            config.runSearch = true;
            if (!searchVisible) searchResults.style.display = 'flex';

            standby.innerHTML = '<i class="fa-duotone fa-spinner-third"></i><span>Searching...</span>';
            if (standby.style.display != 'inline-flex') {
                searchResults.querySelectorAll('li:not(.standby)').forEach(li => li.remove());
                standby.style.display = 'inline-flex';
            }

            standby.querySelector('i').style.display = 'block';
            standby.querySelector('span').textContent = 'Searching...';
        }
    }
});

// user search fires cities etc
window.addEventListener('keyup', debounce((e) => {
    (async () => {
        if (/^(Arrow|Shift|Control|Alt|Tab|CapsLock|Escape)/.test(e.key)) return;

        if (e.target.id == 'q' && config.runSearch) {
            document.querySelector('#clearSearch').style.display = e.target.value == '' ? 'none' : 'block';
            new Search(e.target.value).do();

            config.runSearch = false;
        }

        if (e.target.id == 'layerSearch') {
            const query = e.target.value.toLowerCase();

            impact.querySelectorAll('.layers-list li.layer').forEach(layer => {
                const matches = layer.dataset.id.toLowerCase().includes(query) ||
                    layer.title.toLowerCase().includes(query);

                layer.style.display = matches || query == '' ? 'flex' : 'none';
            });
        }
    })();
}, 500));

window.addEventListener('popstate', () => popstate());

window.addEventListener('focus', e => { if (e.target?.id == 'q') searchResults.style.display = 'flex'; });

(function (global) {
    function Extent() {
        this._bbox = [Infinity, Infinity, -Infinity, -Infinity];
        this._valid = false;
    }
    Extent.prototype.include = function ([lng, lat]) {
        this._valid = true;
        this._bbox[0] = Math.min(this._bbox[0], lng);
        this._bbox[1] = Math.min(this._bbox[1], lat);
        this._bbox[2] = Math.max(this._bbox[2], lng);
        this._bbox[3] = Math.max(this._bbox[3], lat);
        return this;
    };
    Extent.prototype.bbox = function () { return this._valid ? this._bbox : null; };
    Extent.prototype.polygon = function () {
        if (!this._valid) return null;
        const [minX, minY, maxX, maxY] = this._bbox;
        return { type: "Polygon", coordinates: [[[minX, minY], [maxX, minY], [maxX, maxY], [minX, maxY], [minX, minY]]] };
    };

    function geojsonCoords(gj) {
        const coords = [];
        function flatten(obj) {
            if (!obj) return;
            switch (obj.type) {
                case "FeatureCollection": obj.features.forEach(flatten); break;
                case "Feature": flatten(obj.geometry); break;
                case "GeometryCollection": obj.geometries.forEach(flatten); break;
                default:
                    if (Array.isArray(obj.coordinates)) {
                        const stack = [obj.coordinates];
                        while (stack.length) {
                            const item = stack.pop();
                            typeof item[0] === "number" ? coords.push(item) : stack.push(...item);
                        }
                    }
            }
        }
        flatten(gj);
        return coords;
    }

    function traverse(obj, fn) {
        if (!obj || typeof obj !== "object") return;
        fn(obj);
        Object.values(obj).forEach(v => traverse(v, fn));
    }

    function geojsonExtent(gj) {
        const ext = new Extent();
        geojsonCoords(gj).forEach(c => ext.include(c));
        return ext.bbox();
    }

    geojsonExtent.polygon = function (gj) {
        const ext = new Extent();
        geojsonCoords(gj).forEach(c => ext.include(c));
        return ext.polygon();
    };

    geojsonExtent.bboxify = function (obj) {
        const geojsonTypes = ["FeatureCollection", "Feature", "GeometryCollection", "Point", "MultiPoint", "LineString", "MultiLineString", "Polygon", "MultiPolygon"];
        traverse(obj, function (v) {
            if (v && v.type && geojsonTypes.includes(v.type)) {
                v.bbox = geojsonExtent(v);
            }
        });
    };

    global.geojsonExtent = geojsonExtent;
})(window);

class NearbyEvacuations {
    constructor(y, x) {
        this.bufferMiles = 25;
        this.x = x;
        this.y = y;
        this.point = [x, y];
    }

    distanceToSegmentMiles(v, w) {
        const distToV = conversion.distance(this.y, this.x, v[1], v[0]); // distance from p to v
        const distToW = conversion.distance(this.y, this.x, w[1], w[0]); // distance from p to w
        const lineLength = conversion.distance(v[1], v[0], w[1], w[0]);

        if (lineLength === 0) return distToV;

        // Treat points as cartesian (approximate) for projection
        const px = this.x, py = this.y,
            vx = v[0], vy = v[1],
            wx = w[0], wy = w[1],
            t = ((px - vx) * (wx - vx) + (py - vy) * (wy - vy)) /
                ((wx - vx) ** 2 + (wy - vy) ** 2);

        if (t < 0) return distToV;
        if (t > 1) return distToW;

        const projX = vx + t * (wx - vx),
            projY = vy + t * (wy - vy);

        return conversion.distance(this.y, this.x, projY, projX);
    }

    isPointInPolygon(polygon) {
        let inside = false;
        const [x, y] = this.point;
        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            const [xi, yi] = polygon[i],
                [xj, yj] = polygon[j],
                intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
            if (intersect) inside = !inside;
        }
        return inside;
    }

    isPointNearPolygon(polygon) {
        if (this.isPointInPolygon(polygon)) return true;
        for (let i = 0; i < polygon.length; i++) {
            const v = polygon[i],
                w = polygon[(i + 1) % polygon.length];
            if (this.distanceToSegmentMiles(v, w) <= this.bufferMiles) return true;
        }
        return false;
    }

    get() {
        return new Promise((resolve, reject) => {
            if (evacsLoaded) {
                resolve(this.process());
            } else {
                const wait = setInterval(() => {
                    if (evacsLoaded) {
                        clearInterval(wait);
                        resolve(this.process());
                    }
                }, 500);
            }
        });
    }

    process() {
        let active = null,
            grouped = {};

        activeEvacuations.forEach(feature => {
            const geom = feature.geometry;
            let fnotes = '',
                polygons = geom.type === 'Polygon' ? [geom.coordinates[0]] : geom.coordinates.flat();

            const isNear = polygons.some(ring =>
                this.isPointNearPolygon(ring)
            );

            if (isNear) {
                const level = feature.properties.level,
                    notes = feature.properties.notes || '',
                    county = feature.properties.county || '';

                if (!grouped[level]) grouped[level] = { level: level, notes: new Set(), counties: new Set() };

                if (notes.search('Evac Zone Name') >= 0) fnotes = RegExp(/Evac Zone Name: (.*?)\s\//gm).exec(notes)[1];

                grouped[level].notes.add(fnotes);
                grouped[level].counties.add(county);
            }
        });

        active = Object.values(grouped).map(group => ({
            level: group.level,
            notes: Array.from(group.notes),
            counties: Array.from(group.counties),
        }));

        return active;
    }
}

class Popup {
    constructor(title, tall = false) {
        this.header = '<div class="header"' + (!title ? ' style="margin-bottom:0"' : '') + '><h1>' + title + '</h1><span id="close-popup" data-action="close-popup" title="Close popup" class="far fa-xmark-large"></span></div>';
        this.tall = tall;
        this.dialog = null;

        if (isVisible('#modal')) new ClickListener().closeModal();
    }

    create(content) {
        this.close();

        const pop = document.createElement('div');
        pop.classList.add('popup');
        if (this.tall) pop.classList.add('tall');
        pop.innerHTML = `<div class="content">${this.header}<div class="data">${content}</div></div>`;

        this.dialog = pop;
        this.open();

        return this;
    }

    update(content, title = null) {
        if (title) {
            const h = this.dialog.querySelector('.header h1');
            h.innerHTML = title;
            h.parentElement.removeAttribute('style');
        }

        this.dialog.querySelector('.content .data').innerHTML = content;
    }

    open() {
        document.body.appendChild(this.dialog);
    }

    close() {
        if (document.querySelector('.popup') != null) document.querySelector('.popup').remove();
    }
}

class Weather {
    constructor(lat = null, lon = null) {
        this.lat = lat != null ? parseFloat(lat) : null;
        this.lon = lon != null ? parseFloat(lon) : null;
        this.scale = [
            [-50, -40, 'rgb(91, 18, 160)', '#fff'],
            [-40, -30, 'rgb(203, 72, 207)', '#222'],
            [-30, -20, 'rgb(111, 91, 226)', '#222'],
            [-20, -10, 'rgb(117,107,177)', '#222'],
            [-10, 0, 'rgb(13,0,125)', '#fff'],
            [0, 10, 'rgb(0,102,194)', '#fff'],
            [10, 20, 'rgb(74,199,255)', '#222'],
            [20, 30, 'rgb(173,255,255)', '#222'],
            [30, 40, 'rgb(0,153,150)', '#fff'],
            [40, 50, 'rgb(6,109,44)', '#fff'],
            [50, 60, 'rgb(116,196,118)', '#222'],
            [60, 70, 'rgb(211,255,190)', '#222'],
            [70, 80, 'rgb(255,237,160)', '#222'],
            [80, 90, 'rgb(254,174,42)', '#222'],
            [90, 100, 'rgb(252,78,42)', '#222'],
            [100, 110, 'rgb(177,0,38)', '#222'],
            [110, 120, 'rgb(89,0,66)', '#222']
        ];
        this.buildExpression = (steps, isColor = true) => {
            const isF = settings.weather()?.temp() == 'f',
                expr = ['case'];

            steps.forEach(([fMin, fMax, val]) => {
                const min = isF ? fMin : +conversion.FtoC(fMin).toFixed(1),
                    max = isF ? fMax : +conversion.FtoC(fMax).toFixed(1);

                expr.push(['all', ['>=', ['get', 'temp'], min], ['<', ['get', 'temp'], max]], val);
            });

            expr.push(isColor ? 'rgb(40,0,40)' : '#222');
            return expr;
        };
        this.stnColors = {
            bg: this.buildExpression(this.scale.map(s => [s[0], s[1], s[2]])),
            text: this.buildExpression(this.scale.map(s => [s[0], s[1], s[3]]), false),
        };
    }

    async findWXStn(stn) {
        const resp = await api(`https://api.synopticdata.com/v2/stations/metadata?token=350409c14c544ec9957effb1c15bcb99&stid=${stn}`);

        if (resp) {
            const lat = resp.STATION[0].LATITUDE,
                lon = resp.STATION[0].LONGITUDE;

            map.easeTo({
                center: [lon, lat],
                zoom: 9.2,
                duration: 1000
            });

            map.once('moveend', () => {
                // get weather stations without checking the layer
                if (!settings.isEnabled('stns')) layerActions['stns'].exe();

                const wait = setInterval(() => {
                    if (map.getSource('stns')) {
                        clearInterval(wait);
                        const data = map.getSource('stns')._data.geojson.features.filter(feat => feat.properties.STID == stn);

                        if (data.length == 0) return;

                        this.currentConds(data[0].properties);
                    }
                }, 200);
            });
        }
    }

    currentConds(p) {
        if (!p) return;
        setHeaders('Current Weather Conditions at ' + p.NAME, 'weather/current/' + p.STID, 'See current fire weather conditions at ' + p.NAME + '.');

        const hasPermissions = settings.hasPermissions('PRO'),
            popup = new Popup('').create('<div id="spinner" class="sm" style="display:block;text-align:center;margin:0 auto"></div>');

        let obs = typeof p.OBSERVATIONS === 'string' ? JSON.parse(p.OBSERVATIONS) : p.OBSERVATIONS,
            t = obs.air_temp_value_1.value,
            rh = obs.relative_humidity_value_1.value,
            wetBulb = conversion.wetBulb(t, rh),
            wd = obs.wind_direction_value_1.value ? conversion.getCompassDirection(obs.wind_direction_value_1.value) : 'Variable',
            ws = obs.wind_speed_value_1.value,
            feelsLike = (t < 60 && ws ? conversion.windChill(t, ws) : (t && rh ? conversion.heatIndex(t, rh) : null)),
            tunit = 'F',
            wunit = 'mph';

        /* format temperature */
        if (settings.weather()?.temp() == 'c' && t != null) {
            tunit = 'C';
            t = conversion.FtoC(t);
            feelsLike = feelsLike != null ? conversion.FtoC(feelsLike).toFixed(1) : null;
        } else {
            feelsLike = feelsLike != null ? Math.round(conversion.FtoC(feelsLike)) : null;
            t = Math.round(t);
        }

        /* format wind speed */
        if (settings.weather()?.wind() != 'mph' && ws != null) {
            ws = ws != null ? conversion.speed(ws, settings.weather().wind()) : null;
            wunit = settings.weather().wind();
        }

        const stnData = `<div class="item"><div class="t">Station Name</div><div class="v">${p.NAME}</div></div>
            <div class="item"><div class="t">Temperature</div><div class="v">${Math.round(t)}&deg;${tunit}</div></div>
            <div class="item"><div class="t">Feels Like</div><div class="v">${feelsLike != null ? `${feelsLike}&deg;${tunit}` : 'N/A'}</div></div>
            <div class="item"><div class="t">Wet-Bulb Temp.</div><div class="v">${wetBulb != null ? `${wetBulb.toFixed(1)}&deg;${tunit}` : 'N/A'}</div></div>
            <div class="item"><div class="t">Humidity</div><div class="v">${Math.round(rh)}%</div></div>
            <div class="item"><div class="t">Wind</div><div class="v">${(ws != null ? (ws == 0 ? 'Calm' : `${wd} at ${Math.round(ws)} ${wunit}`) : 'N/A')}</div></div>
            <div class="item"><div class="t">Last report</div><div class="v">${timeAgo(new Date(obs.air_temp_value_1.date_time).getTime())}</div></div>
            ${(!hasPermissions ? `<a href="#" data-action="marketing-cta" data-utm="wx_stn" onclick="return false" class="btn btn-sm btn-yellow" style="display:block;margin:0 auto">Upgrade to see more data</a>` : '')}`;

        popup.update(stnData, 'Current Conditions');
    }

    /*windIndicator(d) {
        return '<svg xmlns="http://www.w3.org/2000/svg" style="transform:rotate(' + d + 'deg)" width="24" height="24" viewBox="0 0 24 24"><path fill="var(--orange)" d="M12,2L4.5,20.29l0.71,0.71L12,18l6.79,3 0.71,-0.71z"></path></svg>';
    }*/

    fireWxFcst() {
        new ClickListener().openModal('wwa');

        setHeaders('Daily Fire Weather Forecast for ' + this.lat + ', ' + this.lon, 'weather/forecast/' + this.lat + ',' + this.lon,
            'Daily fire weather forecast from the National Weather Service for ' + this.lat + ', ' + this.lon + '.');

        if (config.workers.fwf == null) {
            config.workers.fwf = new Worker(config.specificURL + (debugMode ? 'v' + version + '/fwf.js' : 'src/js/fwf-' + version + '.js'));
        }

        config.workers.fwf.postMessage({
            lat: this.lat,
            lon: this.lon,
            units: {
                temp: settings.weather().temp() || 'f',
                wind: settings.weather().wind() || 'mph'
            }
        });

        config.workers.fwf.onmessage = (event) => {
            if (event.data != null) {
                config.disableClicks = false;
                modal.querySelector('.content').innerHTML = event.data;
            }
        };
    }

    async incidentWX() {
        const holder = document.querySelector('#curwx');
        if (!holder) return;

        const onError = (error) => {
            if (error) console.error(error);
            holder.innerHTML = '<h2>Nearby Weather Conditions</h2><div class="message error">No current weather conditions are available near this incident.</div>';
        };

        try {
            const wx = await api(config.apiURL + 'weather/nearby', [['radius', this.lat + ',' + this.lon + ',30'], ['latest', 1]]);

            if (!wx?.weather?.obs) return showError();

            const { obs: o, name, updated } = wx.weather;

            if (o.temp?.current == null && !o.rh && !o.wind_speed) return showError();

            const pref = settings.weather?.() || {},
                isMetric = pref.temp?.() === 'c',
                windUnit = pref.wind?.() || 'mph',
                formatTemp = (val) => {
                    if (val == null) return '--';
                    const t = Math.round(val);
                    return isMetric ? `${conversion.FtoC(t).toFixed(1)}&deg;C` : `${t}&deg;F`;
                },
                formatWind = (val) => {
                    if (!val) return '--';
                    const speed = Math.round(val),
                        converted = windUnit !== 'mph' ? conversion.speed(speed, windUnit) : speed;
                    return `${converted} ${windUnit}`;
                },
                domTemp = holder.querySelector('#a h4'),
                domRH = holder.querySelector('#b h4'),
                domWD = holder.querySelector('#c h4'),
                icon = holder.querySelector('#c i'),
                domWS = holder.querySelector('#d h4'),
                u = holder.querySelector('.updated');

            domTemp.innerHTML = formatTemp(o.temp?.current);
            domRH.innerHTML = o.rh ? `${Math.round(o.rh)}%` : '--';

            if (o.raw_wind_dir != null) {
                domWD.innerHTML = o.wind_dir || '--';
                if (icon) icon.style.transform = `rotate(${Number(o.raw_wind_dir - 45)}deg)`;
            } else {
                domWD.innerHTML = '--';
            }

            domWS.innerHTML = formatWind(o.wind_speed);
            u.innerHTML = `Last report ${timeAgo(updated)}${settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM) ? ` @ ${name}` : ''}`;
        } catch (err) {
            onError(err);
        }
    }

    async incidentForecast() {
        const holder = document.querySelector('#fcstwx');
        if (!holder) return;

        const onError = (error) => {
            if (error) console.error(error);
            holder.innerHTML = '<h2>24-Hour Fire Weather Analysis</h2><div class="message error">The 24-hour fire forecast is unavailable at this time.</div>';
        };

        const now = Date.now(),
            pref = settings.weather() || {},
            isMetric = pref.temp?.() === 'c',
            wUnit = pref.wind?.() || 'mph',
            formatWind = (val) => {
                if (!isFinite(val)) return '--';
                const converted = wUnit !== 'mph' ? conversion.speed(Math.round(val), wUnit) : Math.round(val);
                return `${converted} ${wUnit}`;
            };

        try {
            // get pri
            const ap = await api(`https://api.weather.gov/points/${this.lat.toFixed(4)},${this.lon.toFixed(4)}`);

            // if points API is unavailable or returns an error
            if (ap.status) return showError();

            // get hourly forecast grid data from ndfd
            const { properties: prop } = await api(ap.properties.forecastGridData);

            // if no temp data, cancel this process
            if (!prop?.temperature?.values?.length) return showError();

            // map temperatures to time frames
            const valid = prop.temperature.values.map((v, i) => ({
                t: new Date(v.validTime.split('/')[0]).getTime(),
                i
            })).filter(x => x.t >= now && x.t - now < 86400000).map(x => x.i);

            if (!valid.length) return showError();

            const temps = valid.map(i => prop.temperature.values[i].value),
                rhs = valid.map(i => prop.relativeHumidity.values[i]?.value),
                winds = valid.map(i => prop.windSpeed.values[i]?.value).filter(Boolean),
                maxT = Math.max(...temps) * 1.8 + 32,
                minRH = Math.min(...rhs),
                avgW = winds.length ? (winds.reduce((a, b) => a + b, 0) / winds.length) / 1.609 : NaN,
                maxW = winds.length ? Math.max(...winds) / 1.609 : NaN,
                displayT = isMetric ? `${conversion.FtoC(maxT).toFixed(1)}&deg;C` : `${Math.round(maxT)}&deg;F`;

            let btnHtml;
            const isPremium = settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM),
                domTemp = holder.querySelector('#a h4'),
                domRH = holder.querySelector('#b h4'),
                domAvgW = holder.querySelector('#c h4'),
                domMaxW = holder.querySelector('#d h4'),
                u = holder.querySelector('.updated');

            if (isPremium) {
                btnHtml = `<a href="#" class="btn btn-orange btn-sm" style="margin:0" data-lat="${this.lat}" data-lon="${this.lon}" data-action="incident_wx-fwf" onclick="return false">View the full fire forecast</a>`
            } else {
                btnHtml = `<a href="#" class="btn btn-sm btn-orange" style="margin:0" data-action="marketing-cta" data-utm="acres_history" onclick="return false"><i class="fas fa-lock"></i> Upgrade to view forecast</a>`;
            };

            domTemp.innerHTML = displayT;
            domRH.innerHTML = `${minRH}%`;
            domAvgW.innerHTML = formatWind(avgW);
            domMaxW.innerHTML = formatWind(maxW);
            u.innerHTML = `Latest data from ${timeAgo(new Date(prop.updateTime).getTime())}`;
            u.insertAdjacentHTML('afterend', `<div class="btn-group centered" style="margin:0">${btnHtml}</div>`);
        } catch (error) {
            showError(error);
        }
        return this;
    }

    updateRAWSUnits() {
        const isF = settings.weather()?.temp() === 'f',
            newBg = this.buildExpression(this.scale.map(s => [s[0], s[1], s[2]])),
            newText = this.buildExpression(this.scale.map(s => [s[0], s[1], s[3]]), false);

        // 2. Apply directly to map layers
        if (map.getLayer('stns')) {
            map.setPaintProperty('stns', 'circle-color', newBg);
            map.setPaintProperty('stns', 'circle-radius', [
                'case', ['>', ['get', 'temp'], isF ? 99 : 37.2], 15, 13
            ]);
        }

        if (map.getLayer('stns_text')) map.setPaintProperty('stns_text', 'text-color', newText);

        this.raws(true);
    }

    async raws(update = false) {
        const feat = [],
            b = JSON.parse(getbbox()),
            bx = b.xmax + ',' + b.ymin + ',' + b.xmin + ',' + b.ymax,
            vars = 'token=350409c14c544ec9957effb1c15bcb99' +
                '&bbox=' + bx +
                '&vars=air_temp,relative_humidity,wind_speed,wind_direction' +
                '&units=temp|f,speed|mph' +
                '&obtimezone=local' +
                '&status=active' +
                '&network=2,1' +
                '&networkimportance=2,1';

        const data = await api('https://api.synopticlabs.org/v2/stations/latest?' + vars);

        if (data.STATION) {
            data.STATION.forEach((s) => {
                if (s.OBSERVATIONS.air_temp_value_1) {
                    let t = s.OBSERVATIONS.air_temp_value_1.value;

                    if (settings.weather()?.temp() == 'c' && t != '--') {
                        t = conversion.FtoC(s.OBSERVATIONS.air_temp_value_1.value);
                    }

                    s.temp = Math.round(t);
                }

                feat.push({
                    type: 'Feature',
                    geometry: {
                        type: 'Point',
                        coordinates: [parseFloat(s.LONGITUDE), parseFloat(s.LATITUDE)]
                    },
                    properties: s
                });
            });

            if (update) {
                //if (feat.length > 0 && map.getSource('stns') != null) {
                map.getSource('stns').setData({
                    type: 'FeatureCollection',
                    features: feat
                });
                //}
            } else {
                if (!map.getSource('stns')) {
                    map.addSource('stns', {
                        type: 'geojson',
                        data: {
                            type: 'FeatureCollection',
                            features: feat
                        },
                        cluster: true,
                        clusterMaxZoom: 7,
                        clusterMinPoints: 5,
                        clusterRadius: 100
                    });
                }

                if (!map.getLayer('stns')) {
                    map.addLayer({
                        id: 'stns',
                        source: 'stns',
                        type: 'circle',
                        filter: [
                            'all',
                            ['!=', ['get', 'temp'], ''],
                            ['!', ['has', 'point_count']]
                        ],
                        paint: {
                            'circle-color': this.stnColors.bg,
                            'circle-radius': [
                                'case',
                                ['>', ['get', 'temp'], settings.weather()?.temp == 'f' ? 99 : 37.2], 15,
                                13
                            ]
                        }
                    });

                    map.on('mouseenter', 'stns', () => {
                        map.getCanvas().style.cursor = 'pointer';
                    });

                    map.on('mouseleave', 'stns', () => {
                        map.getCanvas().style.cursor = 'auto';
                    });
                }

                if (!map.getLayer('stns_text')) {
                    map.addLayer({
                        id: 'stns_text',
                        type: 'symbol',
                        source: 'stns',
                        filter: [
                            'all',
                            ['!=', ['get', 'temp'], ''],
                            ['!', ['has', 'point_count']]
                        ],
                        paint: {
                            'text-color': this.stnColors.text
                        },
                        layout: {
                            'symbol-placement': 'point',
                            'symbol-spacing': 150,
                            'text-font': config.fonts.roboto(),
                            'text-field': ['concat', ['get', 'temp'], '°'],
                            'text-justify': 'center',
                            'text-size': 12,
                            'text-offset': [0, 0]
                        }
                    });

                    map.on('mouseenter', 'stns_text', () => {
                        map.getCanvas().style.cursor = 'pointer';
                    });

                    map.on('mouseleave', 'stns_text', () => {
                        map.getCanvas().style.cursor = 'auto';
                    });
                }
            }
        }

        return this;
    }

    airQColor(v) {
        const ranges = [
            { max: 50, color: '00e400' },
            { max: 100, color: 'ffff00' },
            { max: 150, color: 'ff7e00' },
            { max: 200, color: 'ff0000' },
            { max: 300, color: '8f3f97' },
            { max: 500, color: '7e0023' }
        ];

        const range = ranges.find(r => v <= r.max);
        return '#' + (range ? range.color : 'd9d9d9');
    }

    airQDesc(aq) {
        const ranges = [
            { max: 50, label: 'Good', desc: 'Air quality is satisfactory, and air pollution poses little or no risk.' },
            { max: 100, label: 'Moderate', desc: 'Air quality is acceptable. However, there may be a risk for some people, particularly those who are unusually sensitive to air pollution.' },
            { max: 150, label: 'Unhealthy for Sensitive Groups', desc: 'Members of sensitive groups may experience health effects. The general public is less likely to be affected.' },
            { max: 200, label: 'Unhealthy', desc: 'Some members of the general public may experience health effects; members of sensitive groups may experience more serious health effects.' },
            { max: 300, label: 'Very Unhealthy', desc: 'Health alert: The risk of health effects is increased for everyone.' },
            { max: Infinity, label: 'Hazardous', desc: 'Health warning of emergency conditions: everyone is more likely to be affected.' }
        ];

        const range = ranges.find(r => aq <= r.max);
        return { quality: range.label, desc: range.desc };
    }

    nearbyAQ() {
        if (!this.lat || !this.lon) {
            const c = map.getCenter();
            this.lat = c.lat;
            this.lon = c.lng;
        }

        return new Promise(resolve => {
            const check = setInterval(() => {
                if (airQualityStns.features) {
                    clearInterval(check);

                    const distances = [],
                        stns = [];

                    airQualityStns.features.forEach(f => {
                        const dist = conversion.distance(this.lat, this.lon, f.geometry.coordinates[1], f.geometry.coordinates[0]);
                        distances.push(dist);
                        stns.push(f.properties);
                    });

                    const stn = stns[distances.indexOf(Math.min(...distances))];

                    resolve({
                        ...stn,
                        color: this.airQColor(stn.PM25_AQI),
                        details: this.airQDesc(stn.PM25_AQI)
                    });
                }
            }, 200);
        });
    }
}

class ChangeListener {
    constructor(target) {
        this.target = target;
    }

    changeBasemap(tile = null) {
        if (tile == null) tile = this.target.dataset.tile;

        settings.settings.tile = tile;

        map.setStyle(config.tiles[tile]);

        map.once('styledata', () => {
            config.layersHandler.addTerrain();
            config.layersHandler.init();
            config.wildfire.getWildfires();
            config.wildfire.perimeters();

            const dont = ['newFires', 'allFires', 'smokeChecks', 'rxBurns', 'perimeters'];

            if (settings.checkboxes()) {
                settings.checkboxes().filter(c => !dont.includes(c)).forEach(c => toggleLayer({ id: c, checked: true }));
            }
        });
    }

    minPerimSize() {
        const v = this.target.value;

        settings.updatePSize(v);
        document.querySelector('#pSize').innerHTML = v + ' acres';

        ['perimeters_outline', 'perimeters_fill', 'perimeters_title'].forEach(lay => map.removeLayer(lay));
        map.removeSource('perimeters');

        config.wildfire.perimeters();
    }

    toggle() {
        const layers = [];

        document.querySelectorAll('.layChkBx').forEach(e => { if (e.checked) layers.push(e.id); });

        // update settings to reflect anytime a checkbox is selected or not
        settings.updateLayers(layers);

        // toggle the layer on or off
        const id = this.target.id,
            checked = this.target.checked;

        toggleLayer({ id, checked });
    }

    smoke(sfc) {
        const handler = sfc ? config.layersHandler.sfcSmoke : config.layersHandler.viSmoke;
        handler(this.target.options[this.target.selectedIndex].value);
    }

    async spc() {
        const type = document.querySelector('#otlkType'),
            days = document.querySelector('#otlkDay'),
            day3 = days.querySelector('option[value="3"]');

        /* add or remove day 3 depending on if the user is looking at severe or fire wx outlooks */
        if (type.value == 'severe') {
            if (!day3) {
                const opt = document.createElement('option');
                opt.value = 3;
                opt.text = 'Day 3';
                days.appendChild(opt);
            }
        } else {
            if (day3) day3.remove();
        }

        settings.updateSpecial();
        new NWS().spc(true);
    }

    personalize() {
        if (document.querySelector('#impact #settings') != null) {
            document.querySelectorAll('#impact #settings select').forEach(s => settings.updatePersonal(s));

            saveSession(true);
        }
    }

    archive() {
        const ay = document.querySelector('#archive_years'),
            s = ay.options[ay.selectedIndex].value,
            win = window.location;

        if (s != '- Choose a year -') win.href = config.host + 'archive/' + s + (win.search ? win.search : '') + (win.hash ? win.hash : '');
    }

    spcClimo() {
        const offset = parseInt(this.target.value, 10);
        config.layersHandler.spcClimo(offset, true, true);
    }
}

function isVisible(div) {
    const element = document.querySelector(div);

    if (element != null) {
        const rect = element.getBoundingClientRect(),
            windowHeight = window.innerHeight;

        return rect.top >= 0 && rect.bottom <= windowHeight;
    }
}

function timeAgo(t, w, c) {
    const plural = (v) => { return v > 1 ? 's' : ''; },
        subUnit = (d, s, r) => { return Math.floor(((d / s) - Math.floor(d / s)) * r); },
        now = c ?? Date.now(),
        timestamp = t.toString().length === 10 ? t * 1000 : t,
        d = Math.round((now - timestamp) / 1000);

    if (d < 10) return 'Just now';

    const ranges = [
        { limit: 60, unit: 'sec', div: 1, sub: null },
        { limit: 3600, unit: 'min', div: 60, sub: { div: 60, unit: 'sec' } },
        { limit: 86400, unit: 'hour', div: 3600, sub: { div: 60, unit: 'min' } },
        { limit: 172800, unit: 'day', div: 86400, sub: { div: 24, unit: 'hour' } },
        { limit: 604800, unit: 'day', div: 86400 },
        { limit: 2419200, unit: 'week', div: 604800 },
        { limit: 31536000, unit: 'month', div: 2419200 },
        { limit: Infinity, unit: 'year', div: 31536000 }
    ];

    const range = ranges.find(r => d < r.limit);
    let val = Math.floor(d / range.div) + ' ' + range.unit + plural(Math.floor(d / range.div));

    if (range.sub) {
        const subVal = subUnit(d, range.div, range.sub.div);
        if (subVal !== 0) {
            val += `,&nbsp;${subVal} ${range.sub.unit}${plural(subVal)}`;
        }
    }

    if (w === 1) val = val.split(',')[0];

    return val + ' ago';
}

function ucfirst(s) {
    return s.charAt(0).toUpperCase() + s.slice(1);
}

function ucwords(s) {
    const smallWords = new Set(['a', 'an', 'the', 'is', 'of', 'and', 'or', 'for', 'to', 'in', 'on', 'at', 'by', 'with']);
    return s.split(' ').map((word, i) => i === 0 || !smallWords.has(word.toLowerCase()) ? word.charAt(0).toUpperCase() + word.slice(1) : word.toLowerCase()).join(' ');
}

function numberFormat(n, d = 2) {
    return Intl.NumberFormat('en-US', {
        maximumFractionDigits: d
    }).format(n);
}

function dateTime(it, time = false, timezone = false, longMonth = false) {
    if (it == null || it === '') return '';

    let t = new Date(it.toString().length == 10 ? it * 1000 : it),
        h = (t.getHours() == 0 ? 12 : (t.getHours() > 12 ? t.getHours() - 12 : t.getHours())),
        m = (t.getMinutes() < 10 ? '0' : '') + t.getMinutes(),
        a = h + ':' + m + ' ' + (t.getHours() >= 12 ? 'P' : 'A') + 'M',
        s = (/\((.*?)\)/g).exec(new Date().toString())[1].split(' '),
        tz = s[0].substring(0, 1) + s[1].substring(0, 1) + s[2].substring(0, 1),
        month = longMonth ? config.longMonths[t.getMonth()] : config.months[t.getMonth()];

    return month + ' ' + t.getDate() + ',&nbsp;' + t.getFullYear() + (time ? ' at ' + a : '') + (timezone ? ' ' + tz : '');
}

/* social media shares */
function socialShare(se) {
    const p = window.location.pathname,
        s = p.split('/'),
        clean = v => ucwords(String(v).replaceAll('-', ' ')).replaceAll(' ', '');

    if (se == 'tt') {
        window.open('https://tiktok.com/search?q=' + s[4].replaceAll('-', '%20').toLowerCase());
    } else {
        const ref = config.host.substring(0, config.host.length - 1).replace('www.', '') + p;

        if (se == 'fb') {
            url = 'https://www.facebook.com/sharer/sharer.php?u=' + ref + '&src=sdkpreparse';
        } else {
            const hashtags = `${clean(s[3])},${clean(s[4])}`;
            url = 'https://x.com/intent/post?hashtags=' + hashtags + '&original_referer=' + ref + '&url=' + ref + '&ref_src=twsrc%5Etfw&tw_p=tweetbutton';
        }

        const h = 425, w = 700,
            t = (window.innerHeight - h) / 2,
            l = (window.innerWidth - w) / 2;

        window.open(url, 'social', `location=no,menubar=no,status=no,resizable=no,top=${t},left=${l},width=${w},height=${h}`);
    }
}

function sfpTimes() {
    return Array.from({ length: 7 }, (_, z) => {
        const t = new Date();
        t.setDate(t.getDate() + z);

        const y = t.getFullYear(),
            m = String(t.getMonth() + 1).padStart(2, '0'),
            d = String(t.getDate()).padStart(2, '0'),
            dayLabel = z === 0 ? ' (Today)' : (z === 1 ? ' (Tomorrow)' : '');

        return {
            key: `${y}-${m}-${d}T00:00:00.0Z`,
            value: `${config.days[t.getDay()]}, ${config.months[t.getMonth()]} ${t.getDate()}${dayLabel}`
        };
    });
}

function ndfdTime(add = 0) {
    const now = new Date(),
        dateStr = `${now.getMonth() + 1}/${now.getDate()}/${now.getFullYear()}`,
        [hours, minutes] = now.toTimeString().split(':');

    let h = parseInt(hours, 10);
    if (parseInt(minutes, 10) > 0) h += 1;

    const t = `${dateStr} ${h}:00:00`;
    return new Date(t).getTime() + add * 3600 * 1000;
}

function initNDFDTimes() {
    const options = [];
    const fcstTime = settings.special().fcstTime();
    let selectedApplied = false;

    for (let i = 0; i < 24; i++) {
        const t = new Date(ndfdTime(i)),
            ts = t.toISOString().replace(/:\d{2}\.\d{3}Z$/, ':00.000Z');

        const selected = !selectedApplied && (fcstTime >= ts || (i === 0 && fcstTime < ts)) ? (selectedApplied = true, 'selected ') : '',
            hours = t.getHours(),
            lh = hours % 12 || 12,
            period = hours >= 12 ? 'PM' : 'AM';

        options.push(`<option ${selected}value="${ts}">${lh}:00 ${period}</option>`);
    }

    return options;
}

function setHeaders(title, urlPath, description) {
    const fullUrl = `${config.specificURL}${urlPath.replace(/incident\/|wildfire\//g, 'fires/')}${window.location.search}${window.location.hash}`,
        pageTitle = `${title} | ${config.productName}`;

    // Use a single line to decide which history method to use
    (modal.classList.contains('open') ? window.history.replaceState : window.history.pushState).call(window.history, {
        "pageTitle": pageTitle
    }, '', fullUrl);

    // Update document metadata
    document.title = pageTitle;
    const metaTags = [
        {
            property: 'og:title',
            name: 'twitter:title',
            content: pageTitle
        }, {
            name: 'description',
            property: 'og:description',
            name: 'twitter:description',
            content: description
        }
    ];

    metaTags.forEach(tag => {
        if (tag.property) document.querySelector(`meta[property="${tag.property}"]`).setAttribute('content', tag.content);
        if (tag.name) document.querySelector(`meta[name="${tag.name}"]`).setAttribute('content', tag.content);
    });
}

function unsetHeaders() {
    const h = window.location.href;

    if (h.search('fires') >= 0 || h.search('weather/') >= 0 || h.search('risk') >= 0) {
        window.history.pushState({
            "pageTitle": document.title
        }, '', h.replace(window.location.pathname, (settings.archive == null ? '' : '/archive/' + settings.archive)));

        document.title = defaultTitle;
        document.querySelector('meta[property="og:title"]').setAttribute('content', defaultTitle);
        document.querySelector('meta[name="twitter:title"]').setAttribute('content', defaultTitle);
        document.querySelector('meta[name="description"]').setAttribute('content', defaultDesc);
        document.querySelector('meta[property="og:description"]').setAttribute('content', defaultDesc);
        document.querySelector('meta[name="twitter:description"]').setAttribute('content', defaultDesc);
    }
}

async function saveSession(method = true) {
    if (!navigator.onLine) return notify('error', 'Unable to sync due to no internet.');

    const sy = document.querySelector('li#save span'),
        syncStatus = impact.querySelector('#sync span'),
        set = {
            ...settings.settings,
            center: [map.getCenter().lat, map.getCenter().lng],
            zoom: map.getZoom(),
            pitch: map.getPitch(),
            bearing: map.getBearing(),
            tile: settings.getBasemap(),
            weather: settings.settings.weather || { temp: 'f', wind: 'mph' }
        };

    if (sy) sy.innerHTML = 'Syncing...';
    if (syncStatus) syncStatus.innerHTML = 'Syncing...';

    const send = [['method', method], ['settings', JSON.stringify(set)]];
    if (settings.user) send.push(['token', settings.getUser().token()]);

    const data = await api(config.host + 'api/v1/session', send);

    if (data?.success === 1) {
        if (settings.user) settings.user.settings.synced = Date.now();
        if (sy) sy.innerHTML = 'Sync';
        if (syncStatus) syncStatus.innerHTML = 'Account synced just now';

        notify('success', 'Your settings were successfully synced.');
    } else {
        if (sy) sy.innerHTML = 'Sync Error';

        notify('error', 'Sync failed. Server might be down.');
    }
}

function newFiresReport() {
    let content = document.createElement('ul');
    content.classList.add('new_fires');

    newFires.forEach(fire => {
        const li = document.createElement('li'),
            name = fire.properties.name.replace(' Fire', '') + (fire.properties.type == 'Wildfire' ? ' Fire' : ''),
            near = fire.properties.near,
            acres = fire.properties.acres,
            size = conversion.sizeFormat(acres);

        li.setAttribute('data-action', 'new-fires');
        li.setAttribute('data-lat', fire.geometry.coordinates[1]);
        li.setAttribute('data-lon', fire.geometry.coordinates[0]);
        li.innerHTML = '<div class="pert"><h3>' + name + '</h3><span class="near">' + near + '</div></div><span class="disc">' + size + '</span>';
        content.appendChild(li);
    });

    createDataForm('New, Fast Growing Fires', content.outerHTML);
}

function createDataForm(title, content, center = false) {
    const df = document.querySelector('#data-form');

    df?.classList.remove('bg');
    df?.remove();

    const el = document.createElement('dialog');
    el.id = 'data-form';
    el.innerHTML = `<span id="exit" data-action="close-data-form" class="far fa-xmark"></span>
        <div class="wrapper${(center ? ' center' : '')}">
            <h1>${title}</h1>${content}
        </div>`;
    document.body.append(el);
}

/* allow user to submit report to MAPO of a new wildfire incident */
async function createCSReport(data, lat, lon) {
    const form = document.querySelector('#newReport'),
        theState = stateLabels[data.geocode.state];

    if (settings.user != null) {
        form.querySelector('input[name=authUser]').value = 1;
        form.insertAdjacentHTML('afterbegin', '<input type="hidden" name="uid" value="' + settings.user.uid + '">');
    }

    form.querySelector('input[name=lat]').value = lat;
    form.querySelector('input[name=lon]').value = lon;
    form.querySelector('input[id=gc]').value = data.geocode.county.county ? data.geocode.county.county : 'Undetermined';
    form.querySelector('input[id=gl]').value = data.geocode.near;
    form.querySelector('input[id=gs]').value = data.geocode.state ? theState?.name : 'Undetermined';
    form.querySelector('input[name=geolocation]').value = data.geocode.near;
    form.querySelector('input[name=state]').value = data.geocode.state + ' / ' + theState?.name;

    form.querySelector('input[name=size]').addEventListener('keyup', (e) => {
        form.querySelector('#alab').innerHTML = 'acre' + (e.target.value != 1 ? 's' : '');
    });

    config.disableClicks = false;
}

async function onRasterLayerClick(e) {
    const coords = e.lngLat,
        getLayer = (name) => map.getStyle().layers.find(l => l.id === name),
        fuels = getLayer('fuels'),
        bp = getLayer('bp'),
        rth = getLayer('rth'),
        whp = getLayer('whp'),
        wet = getLayer('wet'),
        wildfireRiskLayer = [
            { ref: rth, id: 'rth', key: 'rps', title: 'Wildfire Risk', label: 'Risk to Homes' },
            { ref: bp, id: 'bp', key: 'bp', title: 'Wildfire Likelihood', label: 'Wildfire Likelihood' }
        ].find(l => l.ref?.layout?.visibility === 'visible')/*,
        { legend } = await loadUtils()*/;

    if (fuels && fuels.layout.visibility.toString() == 'visible') {
        const popup = new Popup('', true).create('<div id="spinner" class="sm" style="display:block;text-align:center;margin:0 auto"></div>'),
            year = 25,
            getFuelType = async (year, where) => {
                const url = 'https://lfps.usgs.gov/arcgis/rest/services/Landfire_LF' + year + '0/' + where + '_' + year + '0EVT/ImageServer/identify?geometry=' + encodeURIComponent('{"spatialReference":{"latestWkid":4326,"wkid":102100},"x":' + coords.lng + ',"y":' + coords.lat + '}') + '&geometryType=esriGeometryPoint&mosaicRule=' + encodeURIComponent('{"ascending":true,"mosaicMethod":"esriMosaicNorthwest","mosaicOperation":"MT_FIRST"}') + '&renderingRule=&renderingRules=' + encodeURIComponent('[{"rasterFunction":"' + where + '_' + year + '0EVT"}]') + '&pixelSize=' + encodeURIComponent('{"spatialReference":{"latestWkid":3857,"wkid":102100},"x":152.87405657041106,"y":152.87405657041106}') + '&sliceId=&time=&returnGeometry=false&returnCatalogItems=false&returnPixelValues=true&processAsMultidimensional=false&maxItemCount=1&f=json';

                try {
                    const data = await fetch(url);

                    if (!data.ok) return null;

                    const json = await data.json();
                    return json.processedValues && json.processedValues[0] === 'NoData' ? null : json;
                } catch (e) {
                    console.error('Error trying to retreive fuels:', e);
                    return null;
                }
            };

        let where = "US",
            fuelType = 'Unknown',
            fuels = await getFuelType(year, where);

        if (fuels === null) {
            where = "AK";
            fuels = await getFuelType(year, where);
        }

        if (fuels.processedValues && fuels.processedValues[0]) {
            const found = config.fuelsData.find(fuel => fuel.attributes.Value == fuels.processedValues[0]);

            if (found) fuelType = found.attributes.EVT_NAME;

            popup.update(`<div class="item"><div class="t">Existing Vegetation Type</div><div class="v">${fuelType}</div></div>
                <div class="item"><div class="t">Model</div><div class="v">${where == 'US' ? 'United States' : 'Alaska'}</div></div>
                <div class="item"><div class="t">Data Year</div><div class="v">20${year}</div></div>`, 'Fuels Type');
        } else {
            popup.close();
            notify('error', 'Unable to get fuels information. Try again.');
        }
    }

    if (wildfireRiskLayer && map.getZoom() >= 6) {
        const { id, key, title, label } = wildfireRiskLayer;
        const popup = new Popup(title, true).create('<div id="spinner" class="sm" style="display:block;margin:0 auto"></div>');

        const [respRes, pcRes] = await Promise.allSettled([
            api(`${config.apiURL}risk`, [['lat', coords.lat], ['lon', coords.lng]]),
            new Convert().getRasterColor(e.lngLat, id)
        ]);

        const resp = respRes.status === 'fulfilled' ? respRes.value : null,
            pc = pcRes.status === 'fulfilled' ? pcRes.value : null;

        if (resp?.risk) {
            const data = resp.risk, d = data.data[key];
            const localVal = legend.items[id].find(i => i[2] === pc)?.[3] || 'Unknown';

            // Short function to generate the comparison text
            const getComp = (val, region) => {
                const pct = Math.round(val * 100);
                return `On average, ${data.name} has a ${pct < 5 ? 'lower' : 'greater'} risk than ${pct < 5 ? 'nearly all' : pct + '% of'} other counties in ${region}`;
            };

            const content = `<div class="item"><div class="t">Location</div><div class="v">${data.name}, ${data.state}</div></div>
                ${pc ? `<div class="item"><div class="t">${title === 'Wildfire Risk' ? 'Risk' : 'Likelihood'} at this Location</div><div class="v">${localVal}</div></div>` : ''}
                <div class="item"><div class="t">${label} in this County</div><div class="v">${d.rank}</div></div>
                <div class="item"><div class="t">State Comparison</div><div class="v">${getComp(d.state, stateLabels[data.state].name)}</div></div>
                <div class="item"><div class="t">US Comparison</div><div class="v">${getComp(d.us, 'the US')}</div></div>
                <a target="_blank" href="https://apps.wildfirerisk.org/explore/${title.toLowerCase().replace(/ /g, '-')}/${String(data.fips).slice(0, 2)}/${data.fips}/">Learn More</a>`;

            popup.update(content);
        } else {
            popup.update(`<p>Unable to retrieve ${title.toLowerCase()} risk report.</p>`);
        }
    }

    if (whp && whp.layout.visibility == 'visible' && map.getZoom() >= 6) {
        const popup = new Popup('Wildfire Hazard Potential', true).create('<div id="spinner" class="sm" style="display:block;margin:0 auto"></div>');

        const pc = await new Convert().getRasterColor(e.lngLat, 'whp'),
            val = legend.items.whp.find(i => i[2] === pc);

        if (val) {
            const desc = `There is a ${val[3].toLowerCase()} potential for a wildfire that may be difficult to manage.`;

            popup.update(`<div class="item"><div class="t">Difficulty</div><div class="v">${val[3]}</div></div>
                <div class="item"><div class="t">Description</div><div class="v">${desc}</div></div>`);
        } else {
            popup.update('<p>Unable to retrieve wildfire hazard potential data.</p>');
        }
    }

    if (wet && wet.layout.visibility == 'visible') {
        const popup = new Popup('Wildfire Exposure Type', true).create('<div id="spinner" class="sm" style="display:block;margin:0 auto"></div>');

        const pc = await new Convert().getRasterColor(e.lngLat, 'wet'),
            val = legend.items.wet.find(i => i[2] === pc),
            desc = `A home at this location is ${val[3].toLowerCase()} to wildfire from adjacent vegetation or indirect sources (such as embers).`;

        popup.update(val ? `<div class="item"><div class="t">Exposure</div><div class="v">${desc}</div></div>` : '<p>Unable to retrieve wildfire hazard potential data.</p>');
    }
}

async function onMapClick(e) {
    const features = map.queryRenderedFeatures([
        [e.point.x - 5, e.point.y - 5],
        [e.point.x + 5, e.point.y + 5]
    ]);

    onRasterLayerClick(e);

    if (features.length > 0) {
        const wfClass = new Wildfires();
        let clickedCounty = null,
            sources = [],
            fire_layers = ['all_fires', 'new_fires', 'smk_fires', 'rx_fires'];

        features.forEach((feature) => {
            sources.push(feature.source);
        });

        /* highlight specific features on the map when clicked on */
        Object.entries({
            ca_perimeters: 'caperim',
            aus_perimeters: 'ausperim',
            perimeters: 'perim',
            evac: 'evac',
            nri: 'nri',
            erc: 'erc'
        }).forEach(([src, selKey]) => {
            if ((!sources.includes(src) && map.getSource(src)) || selected[selKey] != null) {
                map.removeFeatureState({
                    source: src,
                    id: selected[selKey]
                });
                selected[selKey] = null;
            }
        });

        /* loop through all features to see if county data is available */
        for (let i = 0; i < features.length; i++) {
            if (features[i].layer.id == 'us_counties') {
                clickedCounty = features[i].properties.NAME;
                break;
            }
        }

        /* loop through all features */
        for (let i = 0; i < features.length; i++) {
            const feature = features[i];

            /* display wildfire incident */
            if (fire_layers.includes(feature.source)) {
                if (feature.properties.cluster) {
                    map.zoomIn();
                } else {
                    const time = JSON.parse(feature.properties.time),
                        data = {
                            wfid: feature.properties.wfid,
                            name: feature.properties.name,
                            state: feature.properties.state,
                            type: feature.properties.type,
                            incidentID: feature.properties.incidentId,
                            acres: feature.properties.acres,
                            discovered: parseFloat(time.discovered),
                            updated: parseFloat(time.updated)
                        };

                    wfClass.logFire(data.wfid, data);
                    wfClass.incident(data.wfid, true);
                }

                break;
            }

            // if user has ADMIN permissions and clicked on a user-created marker, polygon, etc
            if (settings.hasPermissions(config.PERMISSION_LEVELS.ADMIN)) {
                if (config.toolsInstance != null && (feature.source == 'user-features' || feature.source == 'marker-geojson' || feature.source == 'polygon-geojson')) {
                    // TODO: if user clicks on a marker or polygon they created
                    map.easeTo({
                        center: feature.geometry.coordinates,
                        zoom: 12,
                        duration: 1000
                    });

                    break;
                }
            }

            if (feature.source == 'ca_fires') {
                const name = feature.properties.name,
                    state = stateLabels?.[feature.properties.province]?.name,
                    time = JSON.parse(feature.properties.time),
                    acres = feature.properties.acres,
                    status = feature.properties.status,
                    near = feature.properties.near;

                map.flyTo({
                    center: feature.geometry.coordinates,
                    zoom: 10
                });

                new Popup('Canadian Wildfire').create('<div class="item"><div class="t">Incident Name</div><div class="v">' + name + '</div></div>' +
                    '<div class="item"><div class="t">Start Date</div><div class="v">' + timeAgo(time.discovered) + '</div></div>' +
                    '<div class="item"><div class="t">Province</div><div class="v">' + state + '</div></div>' +
                    '<div class="item"><div class="t">Size</div><div class="v">' + numberFormat(acres / 2.471, 2) + ' ha (' + acres + ' acres)</div></div>' +
                    '<div class="item"><div class="t">Status</div><div class="v">' + status + '</div></div>' +
                    (near != null ? '<div class="item"><div class="t">Near</div><div class="v">' + near + '</div></div>' : '') +
                    '<span style="margin-top:1em;font-size:12px;color:#8d8d8d">Last update received ' + timeAgo(time.updated) + '</span>'
                );
            }

            /* on canada perimeter click */
            if (feature.source == 'ca_perimeters') {
                selected.caperim = feature.id;

                map.setFeatureState({
                    source: 'ca_perimeters',
                    id: selected.caperim
                }, {
                    click: true
                });

                if (settings.perimeters().zoom()) {
                    map.fitBounds(geojsonExtent(feature.geometry), {
                        padding: 60
                    });
                }

                break;
            }

            /* on austrailia perimeter click */
            if (feature.source == 'aus_perimeters') {
                const p = feature.properties,
                    name = p.fire_name,
                    size = conversion.sizeFormat(p.area_ha * 2.471),
                    discovered = p.ignition_date ? dateTime(p.ignition_date, true, true) : 'Unknown',
                    updated = timeAgo(p.capt_date),
                    istate = p.state == 'WA' ? 'WAA' : (p.state == 'NT' ? 'NTT' : p.state),
                    state = stateLabels?.[istate]?.name ?? istate;

                selected.ausperim = feature.id;

                map.setFeatureState({
                    source: 'aus_perimeters',
                    id: selected.ausperim
                }, {
                    click: true
                });

                new Popup('Austrailia Bushfire', true).create('<div class="item"><div class="t">Incident Name</div><div class="v">' + name + '</div></div>' +
                    '<div class="item"><div class="t">State</div><div class="v">' + state + '</div></div>' +
                    '<div class="item"><div class="t">Discovered</div><div class="v">' + discovered + '</div></div>' +
                    '<div class="item"><div class="t">Perimeter Size</div><div class="v">' + size + '</div></div>' +
                    '<div class="item"><div class="t">Last Mapped</div><div class="v">' + updated + '</div></div>');

                if (settings.perimeters().zoom()) {
                    map.fitBounds(geojsonExtent(feature.geometry), {
                        padding: 60
                    });
                }

                break;
            }

            if (feature.source == 'perimeters') {
                const name = ucwords(feature.properties.attr_IncidentName.replace(' Fire', '').toLowerCase()) + ' Fire',
                    ago = timeAgo(feature.properties.poly_DateCurrent),
                    acres = feature.properties.poly_Acres_AutoCalc > feature.properties.poly_GISAcres ? feature.properties.poly_Acres_AutoCalc : feature.properties.poly_GISAcres,
                    size = conversion.sizeFormat(acres);

                selected.perim = feature.id;

                map.setFeatureState({
                    source: 'perimeters',
                    id: selected.perim
                }, {
                    click: true
                });

                new Popup('Wildfire Perimeter').create('<div class="item"><div class="t">Incident Name</div><div class="v">' + name + '</div></div>' +
                    '<div class="item"><div class="t">Last Mapped</div><div class="v">' + ago + '</div></div>' +
                    '<div class="item"><div class="t">Perimeter Size</div><div class="v">' + size + '</div></div>');

                if (settings.perimeters().zoom()) {
                    map.fitBounds(geojsonExtent(feature.geometry), {
                        padding: 60
                    });
                }

                break;
            }

            if (feature.source == 'firemed') {
                const cityState = `${feature.properties.CITY}, ${feature.properties.STATE} ${feature.properties.ZIPCODE}`,
                    type = feature.properties.type == 'hosp' ? 'Hospital' : (feature.properties.type == 'ems' ? 'Emergency Medical Services' : 'Fire Department');

                new Popup('Emergency Response').create('<div class="item"><div class="t">Type</div><div class="v">' + type + '</div></div>' +
                    '<div class="item"><div class="t">Name</div><div class="v">' + feature.properties.NAME + '</div></div>' +
                    '<div class="item"><div class="t">Address</div><div class="v">' + feature.properties.ADDRESS + '</div></div>' +
                    '<div class="item"><div class="t">City/State</div><div class="v">' + cityState + '</div></div>'
                );

                break;
            }

            /* on air quality click */
            if (feature.source == 'airq') {
                const w = new Weather(),
                    aqi = feature.properties.PM25_AQI,
                    d = w.airQDesc(aqi),
                    ago = timeAgo(new Date(feature.properties.LocalTimeString).getTime());

                new Popup('Air Quality', true).create(`<div class="item"><div class="t">Station Name</div><div class="v">${feature.properties.SiteName}</div></div>
                    <div class="item"><div class="t">Air Quality</div><div class="v">
                    <span class="air_quality" style="display:inline-block;color:#${aqi <= 100 ? '000' : 'fff'};background-color:${w.airQColor(feature.properties.PM25_AQI)}">
                    ${d.quality}</span></div></div>
                    <div class="item"><div class="t">Details</div><div class="v">${d.desc}</div></div>
                    <div class="item"><div class="t">Last Reported</div><div class="v">${ago}</div></div>`);

                break;
            }

            /* on wwas click */
            if (feature.source == 'wwas') {
                new NWS().find(e.lngLat.lat, e.lngLat.lng);
                break;
            }

            /* on SPC outlook click */
            if (feature.source == 'outlook') {
                const color = (feature.properties.fill == '#66A366' || feature.properties.fill == '#ff3333' ? '#fff' : '#242424'),
                    content = `<div class="item">
                        <div class="t">Risk</div><div class="v"><span class="spc" style="background-color:${feature.properties.fill};color:${color}">${feature.properties.name}</span></div>
                    </div><div class="item">
                        <div class="t">Issued</div><div class="v">${dateTime(feature.properties.issue, true, true)}</div>
                    </div><div class="item">
                        <div class="t">Forecast Valid</div><div class="v">${dateTime(feature.properties.valid, true, true)}</div>
                    </div><div class="item">
                        <div class="t">Valid Until</div><div class="v">${dateTime(feature.properties.expires, true, true)}</div>
                    </div>
                    <a href="#" data-action="readSPC" data-type="${settings.special().otlkType()}" data-day="${settings.special().otlkDay()}" onclick="return false" style="display:block;text-align:center">Read the forecast</a>`;

                new Popup((settings.special().otlkType() == 'severe' ? 'Severe' : 'Fire') + ' Weather Outlook - Day ' + settings.special().otlkDay()).create(content);
                break;
            }

            /* modis heat spot click */
            /*if (modis_layers.includes(feature.source)) {
                const p = feature.properties,
                    when = timeAgo(p.acq_time),
                    dn = p.daynight == 'D' ? 'Day' : 'Night',
                    con = ucfirst(p.confidence),
                    content = `<div class="item"><div class="t">Detected</div><div class="v">${when}</div></div>
                <div class="item"><div class="t">Day or Night</div><div class="v">${dn}</div></div>
                <div class="item"><div class="t">Satellite</div><div class="v">modis/${p.satellite}</div></div>
                <div class="item"><div class="t">Confidence</div><div class="v">${con}</div></div>
                <div class="item"><div class="t">Fire Radiative Power</div><div class="v">${p.frp} megawatts</div></div>`;

                new Popup('Satellite-Detected Hotspot').create(content);
                break;
            }*/

            /* ERC PSA click */
            if (feature.source == 'erc') {
                let p = feature.properties,
                    psa = p.PSANAME,
                    code = p.PSANationalCode,
                    obs_pct = p.avg_erc_percentile,
                    obs_trend = p.avg_erc_trend.replace('ase', 'asing'),
                    fcst_pct = p.avg_erc_fcast_percentile,
                    fcst_trend = p.avg_erc_fcast_trend.replace('ase', 'asing'),
                    chart = p.ERC_Chart_URL,
                    time = p.update_time.substring(0, 2) + ':' + p.update_time.substring(2, 4),
                    dt = dateTime(new Date(`${p.update_date} ${time} UTC`).getTime(), true),
                    erc = '',
                    date = '',
                    popup = new Popup('').create('<div id="spinner" class="sm" style="display:block;text-align:center;margin:0 auto"></div>' +
                        '<p style="text-align:center;margin-top:0.5em;font-size:14px">Getting ERC data...</p>');;

                if (settings.special().erc() == null || settings.special().erc() == 'obs') {
                    date = 'Today (' + dateTime(new Date().getTime()) + ')';
                    erc = '<div class="item"><div class="t">ERC Percentile</div><div class="v">' + obs_pct + '%</div></div>' +
                        '<div class="item"><div class="t">ERC Trend</div><div class="v">' + obs_trend + '</div></div>';
                } else {
                    date = 'Tomorrow (' + dateTime((new Date().getTime()) + 86400000) + ')';
                    erc = '<div class="item"><div class="t">ERC Percentile</div><div class="v">' + fcst_pct + '%</div></div>' +
                        '<div class="item"><div class="t">ERC Trend</div><div class="v">' + fcst_trend + '</div></div>';
                }

                const ercContent = `<div class="item"><div class="t">ERC Date</div><div class="v">${date}</div></div>
                        <div class="item"><div class="t">Area (PSA)</div><div class="v">${psa}</div></div>
                        ${settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM) ? `<div class="item"><div class="t">PSA Code</div><div class="v">${code}</div></div>` : ``}
                        <div class="item"><div class="t">Current ERC Value</div><div class="v">${p.avg_erc}</div></div>
                        ${erc}
                        <div class="item"><div class="t">NFDRS Obs Date</div><div class="v">${dt}</div></div>
                        ${chart != null && chart != '' ? `<a target="blank" href="${chart}" style="display:block;text-align:center">View ERC Chart</a>` : ``}`;

                popup.update(ercContent, 'Energy Release Component');

                selected.erc = feature.id;

                map.setFeatureState({
                    source: 'erc',
                    id: selected.erc
                }, {
                    click: true
                });

                break;
            }

            /* PNW EVACUATION VULNERABILITY */
            if (feature.source == 'ev') {
                const p = feature.properties,
                    rank = (v) => {
                        if (v <= 174) return 'Severe';
                        if (v > 174 && v <= 348) return 'High';
                        if (v > 348 && v <= 522) return 'Moderate';
                        return 'Minimal';
                    },
                    content = '<div class="item"><div class="t">City</div><div class="v">' + p.City + '</div></div>' +
                        '<div class="item"><div class="t">State</div><div class="v">' + stateLabels[p.State].name + '</div></div>' +
                        '<div class="item"><div class="t">Rank</div><div class="v">' + p.Overall_Vu + ' of 696</div></div>' +
                        '<div class="item"><div class="t">Vulnerability</div><div class="v">' + (p.Overall_Vu / 6.96).toFixed(1) + '/100 (<b>' + rank(p.Overall_Vu) + '</b>)</div></div>';

                new Popup('Evacuation Vulnerability').create(content);
            }

            /* FEMA NRI click */
            if (feature.source == 'nri') {
                const p = feature.properties,
                    name = p.COUNTY + ' County, ' + p.STATEABBRV,
                    value = {
                        build: numberFormat(p.BUILDVALUE, 0),
                        ag: numberFormat(p.AGRIVALUE, 0)
                    },
                    pop = numberFormat(p.POPULATION, 0),
                    psm = numberFormat(p.POPULATION / p.AREA, 1),
                    risk = p.WFIR_RISKR,
                    score = parseFloat(p.WFIR_RISKS).toFixed(1),
                    content = `<div class="item"><div class="t">Location</div><div class="v">${name}</div></div>
                    <div class="item"><div class="t">Wildfire Risk</div><div class="v">${risk}</div></div>
                    <div class="item"><div class="t">Wildfire Risk Score</div><div class="v">${score}/100</div></div>
                    <div class="item"><div class="t">Population</div><div class="v">${pop}</div></div>
                    <div class="item"><div class="t">People/Square Mile</div><div class="v">${psm}</div></div>
                    <div class="item"><div class="t">Agricultural Value</div><div class="v">$${value.ag}</div></div>
                    <div class="item"><div class="t">Building Values</div><div class="v">$${value.build}</div></div>
                    <a target="blank" href="https://www.fema.gov/flood-maps/products-tools/national-risk-index" style="display:block;text-align:center">Learn about NRI</a>`;

                selected.nri = feature.id;

                map.setFeatureState({
                    source: 'nri',
                    id: selected.nri
                }, {
                    click: true
                });

                new Popup('FEMA Risk Index').create(content);

                break;
            }

            /* on ODF fire danger areas click */
            if (feature.source == 'odfFDR') {
                let danger = '',
                    ifpl = feature.properties.ifplrestrictionlevel ? feature.properties.ifplrestrictionlevel : 'N/A';

                switch (feature.properties.firedanger) {
                    case 1: danger = 'Low'; break;
                    case 2: danger = 'Moderate'; break;
                    case 3: danger = 'High'; break;
                    case 4: danger = 'Extreme'; break;
                    default: danger = 'N/A'; break;
                }

                new Popup('ODF Fire Danger').create(`
                    <div class="item"><div class="t">District</div><div class="v">${ODF_DISTRICT_NAMES[feature.properties.regusearea]}</div></div>
                    <div class="item"><div class="t">Reg. Use Area</div><div class="v">${feature.properties.regusearea}</div></div>
                    <div class="item"><div class="t">Fire Danger</div><div class="v">${danger}</div></div>
                    <div class="item"><div class="t">IFPL</div><div class="v">${ifpl}</div></div>
                `);

                break;
            }

            /* on CAL FIRE FHSZ click */
            if (feature.source == 'cdfFHSZ') {
                const level = feature.properties.FHSZ,
                    desc = level == 1 ? 'Moderate' : (level == 2 ? 'High' : 'Very High');

                new Popup('Fire Hazard Severity Zone').create(
                    (clickedCounty != null ? `<div class="item"><div class="t">County</div><div class="v">${clickedCounty}</div></div>` : '') +
                    `<div class="item"><div class="t">FHSZ</div><div class="v">${desc}</div></div>`
                );

                break;
            }

            /* on drought click */
            if (feature.source == 'drought') {
                let level;
                switch (feature.properties.dm) {
                    case 0:
                        level = 'Abnormally Dry';
                        break;
                    case 1:
                        level = 'Moderate Drought';
                        break;
                    case 2:
                        level = 'Severe Drought';
                        break;
                    case 3:
                        level = 'Extreme Drought';
                        break;
                    case 4:
                        level = 'Exceptional Drought';
                        break;
                }

                new Popup('Drought Monitor').create(`
                    <div class="item"><div class="t">Drought Level</div><div class="v">${level}</div></div>
                    <div class="item"><div class="t">Last Updated</div><div class="v">${timeAgo(feature.properties.ddate)}</div></div>
                `);
            }

            /* on weather stations click */
            if (feature.source == 'stns') {
                new Weather().currentConds(feature.properties);
                break;
            }

            /* on oregon evacuations click */
            if (feature.source == 'evac') {
                map.fitBounds(geojsonExtent(feature.geometry), {
                    padding: 60
                });

                selected.evac = feature.id;

                map.setFeatureState({
                    source: 'evac',
                    id: selected.evac
                }, {
                    click: true
                });

                const p = feature.properties,
                    d = p.level == 1 ? 'Be Ready' : p.level == 2 ? 'Be SET' : 'GO NOW',
                    n = p.notes,
                    u = timeAgo(p.updated);

                new Popup('Evacuations').create('<div class="item"><div class="t">Level</div><div class="v"><span class="evac-circ l' + p.level + '"></span>Level ' + p.level + '</div></div>' +
                    '<div class="item"><div class="t">Status</div><div class="v">' + d + '</div></div>' +
                    '<div class="item"><div class="t">' + (p.county ? 'County' : 'State') + '</div><div class="v">' + (p.county ? p.county + ' County, ' + p.state : stateLabels[p.state].name) + '</div></div>' +
                    '<div class="item"><div class="t">Last Updated</div><div class="v">' + u + '</div></div>' +
                    (n ? '<div class="item"><div class="t">Notes</div><div class="v">' + n + '</div></div>' : '')
                );

                break;
            }
        }
    }
}

window.addEventListener('submit', async (e) => {
    /* submit user NEW INCIDENT form */
    if (e.target.id == 'newReport') {
        e.preventDefault();

        const form = document.querySelector('form#newReport');
        let error = false,
            errorMsg = '';

        document.querySelector('#nrerrors')?.remove();

        /* error checking */
        if (form.querySelector('select[name=type]').options[form.querySelector('select[name=type]').selectedIndex].value == '- Choose -') {
            error = true;
            errorMsg += '<li>Please choose an incident type</li>';
        }

        if (form.querySelector('input[name=size]').value == '') {
            error = true;
            errorMsg += '<li>Please estimate the size of the fire (even if it\'s 0)</li>';
        } else if (!form.querySelector('input[name=size]').value.match(/([0-9.]+)/)) {
            error = true;
            errorMsg += '<li>Your incident size cannot contain non-numeric characters</li>'
        }

        if (form.querySelector('textarea[name=notes]').value == '') {
            error = true;
            errorMsg += '<li>Please provide some details about this incident</li>';
        }

        if (error === true) {
            form.insertAdjacentHTML('afterbegin', '<ul id="nrerrors" style="margin: 0 0 1em 1em;font-size:14px;color:var(--red)">' + errorMsg + '</ul>');
        } else {
            if (confirm('Are you sure this is a new incident? If so, click "OK." Otherwise, please click "Cancel."')) {
                const sub = form.querySelector('input[type=submit]'),
                    canc = form.querySelector('.btn-group a'),
                    fd = [],
                    ent = new URLSearchParams(new FormData(form).entries());

                let type, state;

                document.querySelector('li#report').setAttribute('data-active', '0');
                sub.disabled = true;
                sub.value = 'Submitting...';
                canc.style.display = 'none';

                for (const [key, value] of ent) {
                    fd.push([key, value]);
                    if (key == 'type') type = value;
                    if (key == 'state') state = value;
                }

                const send = await api(config.apiURL + 'newReport', fd);

                if (send.success == 1) {
                    gtag('event', 'submit_report', {
                        type: type,
                        state: state.split(' / ')[1],
                        platform: 'web'
                    });

                    setTimeout(async () => {
                        document.querySelector('#data-form').remove();
                        notify('success', 'Your report was sent to us for review before it may be added to the map.');
                    }, 500);
                } else {
                    sub.disabled = false;
                    sub.value = 'Submit Report';
                    canc.style.display = 'block';

                    notify('error', 'There was an error submitting your report. Please try again.');
                }
            }
        }
    }
});

window.addEventListener('input', (e) => {
    // perimeter min size change text
    if (e.target.parentElement.id == 'perimeterSize' && e.target.classList.contains('slider')) {
        document.querySelector('#pSize').innerHTML = e.target.value + ' acres';
    }
});

window.addEventListener('change', (e) => {
    const target = e.target,
        actionElement = target.closest('[data-action]'),
        action = actionElement ? actionElement.dataset.action : null,
        changeListener = new ChangeListener(target),
        actionHandlers = {
            'change-basemap': () => changeListener.changeBasemap(),
            'change-perim-size': () => changeListener.minPerimSize(),
            'toggle-layer': () => changeListener.toggle(),
            'erc_time': () => {
                settings.updateSpecial();
                config.layersHandler.erc(false, true);
            },
            'sfc_smoke_time': () => changeListener.smoke(true),
            'vi_smoke_time': () => changeListener.smoke(false),
            'spc-outlook': () => changeListener.spc(),
            'ndfd': async () => {
                settings.updateSpecial();
                new NWS().ndfd(true, target.id);
            },
            'spcDates': () => changeListener.spcClimo(),
            'sfp-date': () => {
                settings.updateSpecial();
                config.layersHandler.sfp(true);
            },
            'user-setting': () => changeListener.personalize(),
            'archive_years': () => changeListener.archive()
        };

    if (action != null && actionHandlers[action]) {
        actionHandlers[action]();
    }
});

class UTM {
    constructor() {
        this.a = 6378137;         // WGS84 Major Axis
        this.f = 1 / 298.257223563; // Flattening
        this.k0 = 0.9996;        // Scale factor
        this.e2 = 2 * this.f - Math.pow(this.f, 2); // Eccentricity squared (e^2)
        this.e2prime = this.e2 / (1 - this.e2);      // e'2
    }

    toUTM(lat, lon) {
        const letters = 'CDEFGHJKLMNPQRSTUVWXX',
            latRad = conversion.deg2rad(lat),
            lonRad = conversion.deg2rad(lon);

        let zone = Math.floor((lon + 180) / 6) + 1;
        // Handle Svalbard/Norway exceptions
        if (lat >= 56 && lat < 64 && lon >= 3 && lon < 12) zone = 32;
        if (lat >= 72 && lat < 84) {
            if (lon >= 0 && lon < 9) zone = 31;
            else if (lon >= 9 && lon < 21) zone = 33;
            else if (lon >= 21 && lon < 33) zone = 35;
            else if (lon >= 33 && lon < 42) zone = 37;
        }

        const lonOriginRad = conversion.deg2rad((zone - 1) * 6 - 180 + 3);

        const N = this.a / Math.sqrt(1 - this.e2 * Math.pow(Math.sin(latRad), 2)),
            T = Math.pow(Math.tan(latRad), 2),
            C = this.e2prime * Math.pow(Math.cos(latRad), 2),
            A = Math.cos(latRad) * (lonRad - lonOriginRad);

        const M = this.a * (
            (1 - this.e2 / 4 - 3 * Math.pow(this.e2, 2) / 64 - 5 * Math.pow(this.e2, 3) / 256) * latRad -
            (3 * this.e2 / 8 + 3 * Math.pow(this.e2, 2) / 32 + 45 * Math.pow(this.e2, 3) / 1024) * Math.sin(2 * latRad) +
            (15 * Math.pow(this.e2, 2) / 256 + 45 * Math.pow(this.e2, 3) / 1024) * Math.sin(4 * latRad) -
            (35 * Math.pow(this.e2, 3) / 3072) * Math.sin(6 * latRad)
        );

        let easting = this.k0 * N * (A + (1 - T + C) * Math.pow(A, 3) / 6 + (5 - 18 * T + Math.pow(T, 2) + 72 * C - 58 * this.e2prime) * Math.pow(A, 5) / 120) + 500000,
            northing = this.k0 * (M + N * Math.tan(latRad) * (Math.pow(A, 2) / 2 + (5 - T + 9 * C + 4 * Math.pow(C, 2)) * Math.pow(A, 4) / 24 + (61 - 58 * T + Math.pow(T, 2) + 600 * C - 330 * this.e2prime) * Math.pow(A, 6) / 720));

        if (lat < 0) northing += 10000000;

        return `${zone}${letters[Math.floor((lat + 80) / 8)] || 'X'} ${easting.toFixed(1)}E ${northing.toFixed(1)}N`;
    }
}

class Convert {
    coords(a, b) {
        if (!settings.get().coordsDisplay() || settings.get().coordsDisplay() == 'dec') {
            return parseFloat(a).toFixed(4) + ',&nbsp;' + parseFloat(b).toFixed(4);
        } else if (settings.get().coordsDisplay() == 'dms') {
            return this.convertToDms(a, false) + ',&nbsp;' + this.convertToDms(b, true);
        } else if (settings.get().coordsDisplay() == 'utm') {
            return this.utm(a, b);
        }
    }

    async utm(a, b) {
        return new UTM().toUTM(Number(a), Number(b));
    }

    convertToDms(dd, isLng) {
        var dir = dd < 0 ? isLng ? 'W' : 'S' : isLng ? 'E' : 'N';

        var absDd = Math.abs(dd),
            deg = absDd | 0,
            frac = absDd - deg,
            min = (frac * 60) | 0,
            sec = Math.round((frac * 3600 - min * 60) * 100) / 100;

        return deg + "&deg; " + min + "' " + sec + '" ' + dir;
    }

    rad2deg(r) {
        return r / (Math.PI * 180);
    }

    deg2rad(d) {
        return d * (Math.PI / 180);
    }

    speed(spd, u) {
        if (!spd) return;
        const v = parseFloat(spd);

        if (u == 'km/h') {
            return Math.round(v * 1.609);
        } else {
            return (u == 'mph' ? v : Math.round(v / (u == 'm/s' ? 2.237 : (u == 'kts' ? 1.151 : 1))));
        }
    }

    sizeUnit(customUnit = null) {
        return customUnit != null ? customUnit : (settings.get().acres() ? settings.get().acres() : 'acres');
    }

    sizeFormat(size, returnSize = true, returnUnit = true, customUnit = null) {
        let displayUnit = 'acre';
        const unit = this.sizeUnit(customUnit);

        if (size.toString().toLowerCase() === 'unknown' || size.toString() == '') {
            return returnSize ? '0' : (returnUnit ? unit : '');
        } else if (size !== null && size !== '') {
            let v = parseFloat(size);

            switch (unit) {
                case 'hectares':
                    v /= 2.471;
                    displayUnit = 'hectare';
                    break;
                case 'sqmi':
                    v /= 640;
                    displayUnit = 'square mile';
                    break;
                case 'sqkm':
                    v /= 247.1;
                    displayUnit = 'square km.';
                    break;
            }

            if ((unit === 'acre' || unit === 'hectares') && v > 100000) {
                v = Math.floor(v);
            } else if ((unit === 'sqmi' || unit === 'sqkm') && v > 100000) {
                v = Math.floor(v * 10) / 10;
            }

            const formattedSize = v.toLocaleString('en-US', {
                minimumFractionDigits: 0,
                maximumFractionDigits: (unit === 'acre' || unit === 'hectares') && v > 100000 ? 0 : 2,
            });

            // Use the original number 'v' to check for pluralization
            const isOne = (v >= 0.995 && v < 1.005);
            const unitPlural = (isOne || unit === 'sqkm') ? displayUnit : displayUnit + 's';

            return (returnSize ? formattedSize : '') + (returnUnit ? ` ${unitPlural}` : '');
        } else {
            return '';
        }
    }

    heatIndex(t, rh) {
        var hi;

        if (t > 80) {
            hi = -42.379 + (2.04901523 * t) + (10.14333127 * rh) - (0.22475541 * t * rh) - (0.00683783 * Math.pow(t, 2)) -
                (0.05481717 * Math.pow(rh, 2)) + (0.00122874 * Math.pow(t, 2) * rh) + (0.00085282 * t * Math.pow(rh, 2)) -
                (0.00000199 * Math.pow(t, 2) * Math.pow(rh, 2));

            if (rh < 13 && (t > 80 && t < 112)) {
                hi -= ((13 - rh) / 4) * Math.sqrt((17 - Math.abs(t - 95)) / 17);
            } else if (rh > 85 && (t > 80 && t < 87)) {
                hi += ((rh - 85) / 10) * ((87 - t) / 5);
            }
        } else {
            hi = 0.5 * (t + 61 + ((t - 68) * 1.2) + (rh * 0.094));
        }

        return Math.round(hi);
    }

    windChill(t, w) {
        if (t >= 60 || !w) return null;

        return Math.round(35.74 + (0.6215 * t) - (35.75 * Math.pow(w, 0.16)) + (0.4275 * t * Math.pow(w, 0.16)));
    }

    wetBulb(it, hum) {
        if (it == null || hum == null) return null;

        const t = this.FtoC(it),
            rh = Number(hum),
            wetC = t * Math.atan(0.151977 * Math.sqrt(rh + 8.313659)) +
                Math.atan(t + rh) -
                Math.atan(rh - 1.676331) +
                0.00391838 * Math.pow(rh, 1.5) * Math.atan(0.023101 * rh) -
                4.686035;

        return Number(settings.weather()?.temp() == 'f' ? this.CtoF(wetC) : wetC);
    }

    FtoC(t) {
        return Number((t - 32) * 5 / 9);
    }

    CtoF(t) {
        return Number((t * 1.8) + 32);
    }

    distance(lat1, lon1, lat2, lon2, metric = false) {
        var R = 6371,
            dLat = this.deg2rad(lat2 - lat1),
            dLon = this.deg2rad(lon2 - lon1),
            a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2),
            c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)),
            km = R * c,
            dist = metric ? km : km / 1.60934;

        return dist;
    }

    getCompassDirection(bearing) {
        const dir = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
        return dir[Math.round(bearing / 22.5) % 16];
    }

    async getRasterColor(coords, layerId) {
        if (!map.getLayer(layerId)) return null;

        const source = map.getSource(map.getLayer(layerId).source),
            z = Math.floor(map.getZoom()),
            tileX = Math.floor((coords.lng + 180) / 360 * Math.pow(2, z)),
            tileY = Math.floor((1 - Math.log(Math.tan(coords.lat * Math.PI / 180) + 1 / Math.cos(coords.lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, z)),
            getBBox = (tx, ty, z) => {
                const s = 20037508.34 * 2;
                const res = s / Math.pow(2, z);
                const minX = -20037508.34 + tx * res;
                const maxY = 20037508.34 - ty * res;
                return `${minX},${maxY - res},${minX + res},${maxY}`;
            };

        const url = source.tiles[0].replace('{bbox-epsg-3857}', getBBox(tileX, tileY, z)),
            img = new Image();

        img.crossOrigin = "Anonymous";
        await new Promise(res => { img.onload = res; img.src = url; });

        const canvas = new OffscreenCanvas(1, 1),
            ctx = canvas.getContext('2d'),
            px = Math.floor(((coords.lng + 180) / 360 * Math.pow(2, z) % 1) * 256),
            py = Math.floor(((1 - Math.log(Math.tan(coords.lat * Math.PI / 180) + 1 / Math.cos(coords.lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, z) % 1) * 256);

        ctx.drawImage(img, px, py, 1, 1, 0, 0, 1, 1);

        const [r, g, b] = ctx.getImageData(0, 0, 1, 1).data;
        return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
    }
}

class Search {
    constructor(q) {
        this.key = 'mapofire.search_history';
        this.history = localStorage.getItem(this.key);
        this.emptyHistory = this.history == null || this.history == '' || JSON.parse(this.history).length == 0 ? true : false;
        this.query = q != null ? q.toLowerCase().replace('fire', '') : null;
        this.results = searchResults;
        this.standby = this.results.querySelector('li.standby');
    }

    /*clearData() {
        if (!this.emptyHistory) {
            const tmp = [];

            JSON.parse(this.history).forEach((i) => {
                if (new Date().getTime() - i.time < (60 * 60 * 24 * 14 * 1000)) {
                    tmp.push(i);
                }
            });

            localStorage.setItem(this.key, JSON.stringify(tmp));
        }
    }

    storeSearches() {
        this.clearData();

        const srJson = {
            query: this.query,
            time: new Date().getTime()
        };

        if (this.history == null) {
            localStorage.setItem(this.key, JSON.stringify([srJson]));
        } else {
            const searchArray = [];

            JSON.parse(this.history).forEach((i) => {
                searchArray.push(i);
            });

            searchArray.push(srJson);
            localStorage.setItem(this.key, JSON.stringify(searchArray));
        }
    }

    getSearchHistory() {
        if (this.emptyHistory) {
            return null;
        } else {
            const queryCounts = {},
                json = JSON.parse(this.history);

            json.forEach(item => {
                queryCounts[item.query] = (queryCounts[item.query] || 0) + 1;
            });

            const latestEntriesMap = new Map();
            json.forEach(item => {
                const existingEntry = latestEntriesMap.get(item.query);

                if (!existingEntry || item.time > existingEntry.time) {
                    latestEntriesMap.set(item.query, item);
                }
            });

            const results = Array.from(latestEntriesMap.values());

            results.sort((a, b) => {
                const countA = queryCounts[a.query],
                    countB = queryCounts[b.query];

                if (countA !== countB) {
                    return countB - countA;
                }

                return b.time - a.time;
            });

            return results;
        }
    }*/

    async do() {
        Array.from(this.results.querySelectorAll('li:not(.standby)')).forEach(li => li.remove());

        let count = 0,
            apiStarted = false;

        if (this.query.length > 0) {
            const crds = (/([0-9]{2}\.[0-9]+),\s?(-[0-9]{3}.[0-9]+)/gm).exec(this.query);

            // store user searches in local storage
            //this.storeSearches();

            if (crds != null) {
                const lat = crds[1],
                    lon = crds[2];

                if (lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
                    const h = map.getCenter(),
                        dist = numberFormat(conversion.distance(h.lat, h.lng, lat, lon), 1),
                        dms = String(conversion.convertToDms(lat, false) + '&nbsp;' + conversion.convertToDms(lon, true)).replace(/\s/g, '');

                    const li = document.createElement('li');
                    li.setAttribute('data-action', 'sr-onclick');
                    li.setAttribute('data-type', 'coordinates');
                    li.setAttribute('data-lat', lat);
                    li.setAttribute('data-lon', lon);
                    li.innerHTML = `<span class="icon fas fa-map-location"></span><h3>${parseFloat(lat).toFixed(6).replace(/[0]+$/, '')},&nbsp;${parseFloat(lon).toFixed(6).replace(/[0]+$/, '')} <span style="color:#788695">${dms}</span><span>${dist} mile${dist != 1 ? 's' : ''} away</span></h3>`;
                    this.results.appendChild(li);

                    count++;
                }
            } else {
                activeIncidents.forEach(f => {
                    let use = false;
                    const isAustralia = f.isAustralia ?? false,
                        p = f.properties,
                        name = p.name,
                        acresDisp = conversion.sizeFormat(p.acres),
                        fstat = p.status,
                        status = (p.time.year < config.curTime.getFullYear() ? 'out' : config.wildfire.getStatus(fstat, p.notes)),
                        j = name.toLowerCase().split(' ');

                    for (let i = 0; i < j.length; i++) {
                        if (j[i].search(this.query) >= 0) {
                            use = true;
                            break;
                        }
                    }

                    if (name.toLowerCase().search(this.query) >= 0) use = true;

                    if (use) {
                        const li = document.createElement('li');
                        li.setAttribute('data-action', 'sr-onclick');
                        li.setAttribute('data-type', 'incident');
                        li.setAttribute('data-wfid', p.wfid);
                        li.setAttribute('title', name);
                        li.innerHTML = `<span class="icon fire fas fa-fire"></span><h3>${name}<span>${p.type} in ${stateLabels[p.state]?.name}${isAustralia ? ', Australia' : ''} &middot;
                            <b>${acresDisp}</b>${status != '' ? ` &middot; <span class="fstatus ${status}">${ucfirst(status)}` : ''}</span></span></h3>`;
                        this.results.appendChild(li);

                        count++;
                    }
                });
            }
        }

        if (count > 0) {
            this.standby.style.display = 'none';
        }

        if (this.query.length > 3) {
            apiStarted = true;

            this.apiSearch().then(added => {
                const finalCount = count + added;

                if (finalCount > 0) {
                    this.standby.style.display = 'none';
                } else {
                    this.standby.style.display = 'block';
                    this.standby.querySelector('i').style.display = 'none';
                    this.standby.querySelector('span').innerHTML = 'No results found';
                }
            });
        }

        if (this.query.length == 0 || (count === 0 && !apiStarted)) {
            this.standby.style.display = 'block';
            this.standby.querySelector('i').style.display = 'none';
            this.standby.querySelector('span').innerHTML = this.query.length == 0 ? 'Ready to search? Type something...' : 'No results found';
        }
    }

    async apiSearch() {
        let count = 0;
        const search = await api(config.apiURL + 'search', [['q', this.query]], true);

        if (search.results != null && search.results.length > 0) {
            search.results.forEach((p) => {
                const li = document.createElement('li');
                let pname;

                if (p.type == 'county' || p.type == 'state') {
                    const bbox = {
                        x: {
                            min: p.data.xmin,
                            max: p.data.xmax
                        },
                        y: {
                            min: p.data.ymin,
                            max: p.data.ymax
                        }
                    };

                    li.setAttribute('data-bbox', JSON.stringify(bbox));
                }

                if (p.type == 'state') {
                    pname = p.data.name;
                } else if (p.type == 'county') {
                    pname = p.data.name + ' County, ' + p.data.state;
                } else {
                    pname = p.data.city + ', ' + stateLabels[p.data.state].name + (p.isZip ? ' ' + p.data.zip : '');
                    if (p.type == 'gis') {
                        pname = p.data.name + ', ' + stateLabels[p.data.state].name;
                        li.setAttribute('data-geotype', p.data.type);
                    }

                    li.setAttribute('data-lat', p.lat);
                    li.setAttribute('data-lon', p.lon);
                }
                li.setAttribute('data-action', 'sr-onclick');
                li.setAttribute('data-name', pname);
                if (p.data.county) li.setAttribute('data-county', p.data.county);
                li.setAttribute('data-type', p.type.toLowerCase());
                li.innerHTML = `<span class="icon fas fa-location-dot"></span>
                <h3>${pname}
                    <span>${p.type == 'gis' ? p.data.type + ' in ' : ''}${p.data.county ? p.data.county + ' County' : (p.type == 'county' ? 'County' : 'State')}${p.type == 'city' && p.data.population > 0 ? ` &middot; Population: ${numberFormat(p.data.population)}` : ''}</span>
                </h3>`;
                this.results.appendChild(li);

                count++;
            });
        }

        return count;
    }
}

class Settings {
    constructor(u) {
        this.defaultLayers = [];
        this.defaultSettings = {
            center: [43.67, -117.15],
            zoom: 5,
            tile: 'outdoors',
            perimeters: {
                'minSize': 500,
                'color': 'default',
                'zoom': 1
            },
            saveFreq: 300000
        };
        this.user = u;
        this.role = this.user?.role ?? 'GUEST';
        this.settings = u != null && u.settings.allsettings ? u.settings.allsettings : this.defaultSettings;
        this.archive = typeof historical !== 'undefined' && this.hasPermissions(config.PERMISSION_LEVELS.PREMIUM) ? historical : null;

        if (!this.settings.checkboxes) {
            Object.keys(layers.layers).forEach((e) => {
                layers.layers[e].forEach((f) => {
                    if (f.default) {
                        this.defaultLayers.push(f.id);
                    }
                });
            });

            this.settings.checkboxes = this.defaultLayers;
        }
    }

    updateLayers(layers) {
        this.settings.checkboxes = layers;
    }

    updateSpecial() {
        const ot = document.querySelector('#otlkType'),
            od = document.querySelector('#otlkDay'),
            fm = document.querySelector('#forecastModel'),
            ft = document.querySelector('#fcstTime'),
            sf = document.querySelector('#sfpDateSelect'),
            ec = document.querySelector('#erc_time');

        this.settings.special = {
            otlkType: ot.options[ot.selectedIndex].value,
            otlkDay: od.options[od.selectedIndex].value,
            erc: ec.options[ec.selectedIndex].value,
            sfpDate: sf.options[sf.selectedIndex].value,
            forecastModel: fm.options[fm.selectedIndex].value,
            fcstTime: ft.options[ft.selectedIndex].value
        };
    }

    updatePersonal(s) {
        if (s.selectedIndex >= 0) {
            const id = s.id,
                val = s.options[s.selectedIndex].value;

            if (id == 'perimColor') {
                this.settings.perimeters.color = val;

                let c = config.wildfire.perimeterColor(val),
                    pcl = setInterval(() => {
                        if (map.isStyleLoaded()) {
                            clearInterval(pcl);

                            map.setPaintProperty('perimeters_outline', 'line-color', c)
                                .setPaintProperty('perimeters_fill', 'fill-color', c)
                                .setPaintProperty('ca_perimeters_outline', 'line-color', c)
                                .setPaintProperty('ca_perimeters_fill', 'fill-color', c);
                        }
                    }, 500);
            } else if (id == 'perimTtip') {
                this.settings.perimeters.ttip = val;
            } else if (id == 'perimZoom') {
                this.settings.perimeters.zoom = val;
            } else if (id == 'tempUnit') {
                if (!this.settings.weather) {
                    this.settings.weather = {};
                }

                this.settings.weather.temp = val;
                new Weather().updateRAWSUnits();
            } else if (id == 'windSpeedUnit') {
                if (!this.settings.weather) {
                    this.settings.weather = {};
                }

                this.settings.weather.wind = val;
            } else if (id == 'acresUnit') {
                this.settings.acres = val;
            } else {
                this.settings[id] = val;
            }
        }
    }

    updatePSize(v) {
        this.settings.perimeters.minSize = v;
        saveSession(true);
    }

    checkboxes() {
        return this.settings['checkboxes'];
    }

    get() {
        return {
            coordsDisplay: () => {
                return this.settings['coordsDisplay'] ?? 'dec';
            },
            saveFreq: () => {
                return this.settings['saveFreq'] ?? 300000;
            },
            acres: () => {
                return this.settings['acres'] ?? 'acres';
            },
            locallySave: () => {
                return this.settings['locallySave'] ?? 'n';
            }
        };
    }

    isEnabled(id) {
        return this.checkboxes()?.includes(id) ?? false;
    }

    map() {
        return {
            lat: parseFloat(this.settings.center[0]),
            lon: parseFloat(this.settings.center[1]),
            zoom: parseInt(this.settings.zoom),
            tile: this.settings.tile,
            pitch: this.settings.pitch ? this.settings.pitch : 0,
            bearing: this.settings.bearing ? this.settings.bearing : 0
        }
    }

    getBasemap() {
        return this.settings.tile;
    }

    subscriptions() {
        const sub = new Subscription(this.user);

        return {
            valid: () => {
                return sub.valid();
            },
            customerID: () => {
                return sub.cid();
            },
            subID: () => {
                return sub.sid();
            },
            name: () => {
                return sub.name();
            },
            plan: () => {
                return sub.plan();
            },
            isTrial: () => {
                return sub.isTrial();
            },
            expires: () => {
                return sub.expires();
            }
        }
    }

    hasPermissions(levels = null) {
        const currentPlan = this.subscriptions().plan(),
            hasValidSubscription = this.subscriptions().valid(),
            requiredLevels = Array.isArray(levels) ? levels : [levels];

        if (requiredLevels.length == 0 || this.getUser().role() == config.PERMISSION_LEVELS.ADMIN) {
            return true;
        }

        // if there is no (valid) subscription, return false
        if (!hasValidSubscription) {
            return false;
        }

        const userLevel = config.TIERS[currentPlan] || null,
            userRank = userLevel ? config.RANKS[userLevel] : 0;

        return requiredLevels.some(level => {
            const requiredRank = config.RANKS[level] || 0;
            return userRank >= requiredRank;
        });
    }

    getUser() {
        return {
            getName: () => {
                return {
                    first: () => {
                        return this.user?.first_name ?? null;
                    },
                    last: () => {
                        return this.user?.last_name ?? null;
                    }
                };
            },
            role: () => {
                return this.user ? this.role : null;
            },
            token: () => {
                return this.user?.token ?? null;
            },
            uid: () => {
                return this.user?.uid ?? null;
            },
            synced: () => {
                return this.user?.settings.synced ?? null;
            }
        };
    }

    fire() {
        return {
            cache: () => {
                return this.settings.locallySave == 'y' ? true : false;
            }/*,
            display: () => {
                return this.settings.fireDisplay == 'page' ? false : true;
            }*/
        }
    }

    perimeters() {
        return {
            zoom: () => {
                const z = this.settings?.perimeters?.zoom;
                if (z == null) return true;
                return z === 1;
            },
            minSize: () => {
                return Number(this.settings.perimeters?.minSize) ?? 500;
            },
            color: () => {
                return this.settings.perimeters?.color ?? 'default';
            },
            ttip: () => {
                return this.settings.perimeters?.ttip ?? 1;
            }
        };
    }

    weather() {
        return {
            wind: () => {
                return this.settings.weather?.wind ?? 'mph';
            },
            temp: () => {
                return this.settings.weather?.temp ?? 'f';
            }
        };
    }

    special() {
        return {
            erc: () => {
                return this.settings.special?.erc ?? 'obs';
            },
            otlkDay: () => {
                return this.settings.special?.otlkDay ?? 1;
            },
            otlkType: () => {
                return this.settings.special?.otlkType ?? 'severe';
            },
            sfpDate: () => {
                return this.settings.special?.sfpDate ?? '';
            },
            forecastModel: () => {
                return this.settings.special?.forecastModel ?? 'air_temperature';
            },
            fcstTime: () => {
                return this.settings.special?.fcstTime ?? '';
            }
        };
    }

    /*logMovement() {
        const sn = 'mapofire.movements',
            c = map.getCenter(),
            history = JSON.parse(localStorage.getItem(sn) || '[]');

        history.push({
            g: [c.lat, c.lng, map.getBearing(), map.getPitch()],
            w: Date.now()
        });

        localStorage.setItem(sn, JSON.stringify(history));
    }*/
}

class Subscription {
    constructor(u) {
        this.sub = null;
        this.user = u;

        if (this.user && this.user.subscriptions != null) {
            this.sub = this.user.subscriptions[0];
        }
    }

    name() {
        return this.sub?.name ?? null;
    }

    plan() {
        return this.sub?.id ?? null;
    }

    isTrial() {
        return this.sub ? (this.sub.trial == 1 ? true : false) : false;
    }

    valid() {
        return this.sub != null && this.sub.ends * 1000 > new Date().getTime() ? true : false;
    }

    cid() {
        return this.sub?.cid ?? null;
    }

    sid() {
        return this.sub?.subscription ?? null;
    }

    expires() {
        return this.sub ? dateTime(this.sub.ends, false, false, true) : null;
    }
}

class Layers {
    constructor() {
        this.spcClimoDate = Date.parse('1/1/2026');
    }

    init() {
        /* add lightning layers to the map */
        this.lightning();

        /* get air quality */
        this.airQuality();

        /* get evacuations */
        this.evacuations();
    }

    contours(demSource) {
        demSource.setupMaplibre(maplibregl);

        if (!map.getSource('contours')) {
            map.addSource('contours', {
                type: 'vector',
                tiles: [
                    demSource.contourProtocolUrl({
                        multiplier: 3.28084,
                        thresholds: {
                            11: [200, 1000],
                            12: [100, 500],
                            14: [50, 200],
                            15: [20, 100]
                        },
                        contourLayer: 'contours',
                        elevationKey: 'ele',
                        levelKey: 'level',
                        extent: 4096,
                        buffer: 1
                    })
                ],
                maxzoom: 15
            });
        }

        if (!map.getLayer('contour-lines')) {
            map.addLayer({
                id: 'contour-lines',
                type: 'line',
                source: 'contours',
                'source-layer': 'contours',
                paint: {
                    'line-color': '#626250',
                    'line-opacity': 0.37,
                    'line-width': ['match', ['get', 'level'], 1, 1, 0.5],
                }
            });
        }

        if (!map.getLayer('contour-labels')) {
            map.addLayer({
                id: 'contour-labels',
                type: 'symbol',
                source: 'contours',
                'source-layer': 'contours',
                filter: ['>', ['get', 'level'], 0],
                layout: {
                    'symbol-placement': 'line',
                    'text-size': 10,
                    'text-allow-overlap': true,
                    'text-justify': 'center',
                    'text-field': ['concat', ['number-format', ['get', 'ele'], {}], ' ft'],
                    'text-font': config.fonts.source(),
                },
                paint: {
                    'text-color': '#6b6638',
                    'text-halo-color': '#ddddd5',
                    'text-halo-width': 2,
                    'text-halo-blur': 1
                }
            });
        }
    }

    addTerrain() {
        if (settings.hasPermissions(config.PERMISSION_LEVELS.PRO)) {
            const wait = setInterval(() => {
                if (typeof mlcontour !== 'undefined') {
                    clearInterval(wait);

                    const demSource = new mlcontour.DemSource({
                        url: 'https://tiles.mapterhorn.com/{z}/{x}/{y}.webp',
                        encoding: 'terrarium',
                        maxzoom: 13,
                        worker: true,
                        cacheSize: 100,
                        timeoutMs: 10_000
                    });

                    if (!map.getSource('terrain')) {
                        map.addSource('terrain', {
                            type: 'raster-dem',
                            encoding: 'terrarium',
                            maxzoom: 13,
                            url: 'https://tiles.mapterhorn.com/tilejson.json'
                        });
                    }

                    if (!map.getSource('hillshading')) {
                        map.addSource('hillshading', {
                            type: 'raster-dem',
                            encoding: 'terrarium',
                            maxzoom: 13,
                            url: 'https://tiles.mapterhorn.com/tilejson.json'
                        });
                    }

                    // set 3d terrain
                    map.setTerrain({
                        source: 'terrain',
                        exaggeration: 1.1
                    });

                    if (settings.getBasemap() == 'outdoors') {
                        map.addLayer({
                            id: 'hillshading',
                            type: 'hillshade',
                            source: 'hillshading',
                            layout: {},
                            paint: {
                                'hillshade-exaggeration': 0.1,
                                'hillshade-shadow-color': 'rgba(50, 50, 50, 0.7)',
                                'hillshade-accent-color': 'rgb(129, 128, 120)',
                                'hillshade-highlight-color': 'rgba(250, 250, 250, 0.9)'
                            }
                        });
                    } else if (map.getLayer('hillshading')) map.removeLayer('hillshading');

                    if (settings.getBasemap() == 'outdoors') {
                        this.contours(demSource);
                    } else {
                        ['contour-lines', 'contour-labels'].forEach(layer => {
                            if (map.getLayer(layer)) map.removeLayer(layer);
                        });
                    }
                    ////}
                }
            }, 100);
        }
    }

    async airQuality() {
        const data = await api('https://services.arcgis.com/cJ9YHowT8TU7DUyn/arcgis/rest/services/Air_Now_Current_Monitors_PM/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', 'ObjectId,AQSID,SiteName,LocalTimeString,PM25_AQI,PM25'],
            ['returnGeometry', 'true'],
            /*['geometry', getbbox()],*/
            ['geometryPrecision', '6'],
            ['returnExceededLimitFeatures', 'true'],
            ['f', 'geojson']
        ]);

        airQualityStns = data;

        if (!data.error) {
            if (!map.getSource('airq')) {
                map.addSource('airq', {
                    type: 'geojson',
                    data: data,
                    cluster: true,
                    clusterMaxZoom: 7,
                    clusterMinPoints: 5,
                    clusterRadius: 40
                });
            }

            if (!map.getLayer('airQuality')) {
                map.addLayer({
                    id: 'airQuality',
                    type: 'circle',
                    source: 'airq',
                    filter: [
                        'all',
                        ['has', 'PM25_AQI'],
                        ['==', ['typeof', ['get', 'PM25_AQI']], 'number']
                    ],
                    layout: {
                        visibility: settings.isEnabled('airq') ? 'visible' : 'none'
                    },
                    paint: {
                        'circle-radius': 12,
                        'circle-color': [
                            'step',
                            ['coalesce', ['get', 'PM25_AQI'], -1], // Fallback to -1 if null
                            '#d9d9d9', // Default for anything below 0
                            0, '#00e400', // 0-50 (Good)
                            51, '#ffff00', // 51-100 (Moderate)
                            101, '#ff7e00', // 101-150 (Unhealthy SG)
                            151, '#ff0000', // 151-200 (Unhealthy)
                            201, '#8f3f97', // 201-300 (Very Unhealthy)
                            301, '#7e0023'  // 301+ (Hazardous)
                        ],
                        'circle-stroke-color': 'black',
                        'circle-stroke-width': 1
                    }
                });

                map.on('mouseenter', 'airQuality', () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', 'airQuality', () => {
                    map.getCanvas().style.cursor = 'auto';
                });
            }

            if (!map.getLayer('airQuality_text')) {
                map.addLayer({
                    id: 'airQuality_text',
                    type: 'symbol',
                    source: 'airq',
                    filter: [
                        'all',
                        ['has', 'PM25_AQI'],
                        ['==', ['typeof', ['get', 'PM25_AQI']], 'number']
                    ],
                    paint: {
                        'text-color': [
                            'case',
                            ['>=', ['number', ['get', 'PM25_AQI'], 0], 150],
                            '#fff',
                            '#000'
                        ]
                    },
                    layout: {
                        'text-ignore-placement': true,
                        'text-allow-overlap': true,
                        'text-font': config.fonts.din(),
                        'text-field': ['to-string', ['number', ['get', 'PM25_AQI'], 0]],
                        'text-size': 11,
                        'text-justify': 'center',
                        visibility: settings.isEnabled('airq') ? 'visible' : 'none'
                    }
                });
            }
        }
    }

    async lightning() {
        const ltime = () => {
            const now = new Date(),
                mins = now.getUTCMinutes(),
                roundedMins = mins < 30 ? 0 : 30;

            now.setUTCMinutes(roundedMins, 0, 0);

            return now.toISOString();
        };

        /*map.addSource('lightning1', {
            type: 'raster',
            maxzoom: 15,
            tiles: [
                //config.host + 'api/v1/lightning?key=' + config.apiKey() + '&x={x}&y={y}&z={z}&t=5'
                //'https://tiles.lightningmaps.org/?x={x}&y={y}&z={z}&s=256&t=5'
                'https://www.firewxavy.org/apis/lightning/5/{z}/{x}/{y}'
                //'https://nowcoast.noaa.gov/geoserver/observations/lightning_detection/ows?request=GetMap&service=WMS&layers=ldn_lightning_strike_density&request=GetMap&styles=&format=image/png&transparent=true&version=1.3.0&width=256&height=256&time=' + ltime() + '&crs=EPSG%3A3857&bbox={bbox-epsg-3857}'
            ],
            tileSize: 256
        });
        
        map.addLayer({
            id: 'lightning1',
            type: 'raster',
            source: 'lightning1',
            layout: {
                visibility: settings.isEnabled('lightning1') || !settings.checkboxes() ? 'visible' : 'none'
            }
        });
        
        map.addSource('lightning24', {
            type: 'raster',
            maxzoom: 15,
            tiles: [
                //config.host + 'api/v1/lightning?key=' + config.apiKey() + '&x={x}&y={y}&z={z}&t=6'
                //'https://tiles.lightningmaps.org/?x={x}&y={y}&z={z}&s=256&t=6'
                'https://www.firewxavy.org/apis/lightning/6/{z}/{x}/{y}'
            ],
            tileSize: 256
        });
        
        map.addLayer({
            id: 'lightning24',
            type: 'raster',
            source: 'lightning24',
            layout: {
                visibility: settings.isEnabled('lightning24') || !settings.checkboxes() ? 'visible' : 'none'
            }
        });*/
    }

    async radarInit() {
        await fetch('https://api.rainviewer.com/public/weather-maps.json').then(async (resp) => {
            const imgs = await resp.json();

            imgs.radar.past.forEach((e) => {
                radarImgs.push(e.time);
            });

            let time = (n) => {
                const d = new Date(radarImgs[n] * 1000),
                    h = d.getHours(),
                    m = d.getMinutes();

                return (h > 12 ? h - 12 : (h == 12 ? 12 : h)) + ':' + (m < 10 ? '0' : '') + m + (h >= 12 ? 'p' : 'a') + 'm';
            };

            const rl = `<div class="radar"><div><span class="radarControl fas fa-pause" title="Pause radar" data-action="radar-control"></span><div class="time">
                <input type="range" steps="12" min="0" max="12" value="0">
                <div class="tr"><span>${time(0)}</span><span>${time(6)}</span><span>${time(12)}</span></div></div></div></div>`;

            document.body.insertAdjacentHTML('beforeend', rl);

            this.radar();
        });
    }

    radar() {
        let counter = 0;

        radarImgs.forEach((e, n) => {
            map.addSource('radar-' + n, {
                type: 'raster',
                tiles: ['https://tilecache.rainviewer.com/v2/radar/' + e + '/256/{z}/{x}/{y}/4/0_1.png'],
                tileSize: 256,
                attribution: this.defaultAttr + '&copy; <a href="https://www.rainviewer.com">RainViewer</a>'
            });

            map.addLayer({
                id: 'radar-layer-' + n,
                type: 'raster',
                source: 'radar-' + n,
                layout: {
                    visibility: 'none'
                },
                paint: {
                    'raster-fade-duration': 0,
                    'raster-opacity': 0.7
                }
            });
        });

        let ra = () => {
            radarImgs.forEach((e, n) => {
                map.setLayoutProperty('radar-layer-' + n, 'visibility', (n == counter ? 'visible' : 'none'));
                document.querySelector('.radar input[type=range]').value = counter;
            });

            if (counter == radarImgs.length - 1) {
                counter = 0;
                clearInterval(radarAnim);

                setTimeout(() => {
                    radarAnim = setInterval(ra, RADAR_INT);
                }, RADAR_INT);
            } else {
                counter++;
            }
        };

        radarAnim = setInterval(ra, RADAR_INT);
    }

    async modis(w, update = false) {
        const url = 'https://services9.arcgis.com/RHVPKKiFTONKtxq3/ArcGIS/rest/services/Satellite_VIIRS_Thermal_Hotspots_and_Fire_Activity/FeatureServer/0/query',
            n = (w == 1 ? '24' : (w == 2 ? '48' : '72')),
            ts = (d) => {
                const dt = new Date(Date.now() - d * 86400000),
                    pad = (n) => n.toString().padStart(2, '0');
                return `${dt.getMonth() + 1}/${dt.getDate()}/${dt.getFullYear()} ${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
            },
            start = ts(w),
            end = w > 1 ? ts(w - 1) : null;

        if (map.getZoom() >= config.modisZoomLevel) {
            const data = await api(url, [
                ['where', `acq_time >= DATE '${start}:00'${end ? ` AND acq_time < DATE '${end}:00'` : ''}`],
                ['outFields', '*'],
                ['geometry', getbbox()],
                ['geometryPrecision', 6],
                ['geometryType', 'esriGeometryEnvelope'],
                ['spatialRel', 'esriSpatialRelIntersects'],
                ['returnGeometry', true],
                ['f', 'geojson']
            ]);

            if (update && data) {
                map.getSource('modis' + n).setData(data);
            } else {
                if (!map.getSource('modis' + n)) {
                    map.addSource('modis' + n, {
                        type: 'geojson',
                        data: data,
                        cluster: true,
                        clusterMaxZoom: window.innerWidth < 600 || window.outerWidth < 600 ? 8 : 9,
                        clusterMinPoints: 4,
                        clusterRadius: 20
                    });
                }

                if (!map.getLayer('modis' + n)) {
                    map.addLayer({
                        id: 'modis' + n,
                        type: 'symbol',
                        source: 'modis' + n,
                        layout: {
                            'icon-image': 'modis' + w,
                            'icon-size': 0.5,
                            'icon-allow-overlap': true
                        },
                        paint: {
                            'icon-opacity': [
                                'interpolate',
                                ['linear'],
                                ['zoom'],
                                0,
                                0.5,
                                10,
                                0.5,
                                13.5,
                                1
                            ]
                        }
                    });

                    map.on('mouseenter', 'modis' + n, () => {
                        map.getCanvas().style.cursor = 'pointer';
                    });

                    map.on('mouseleave', 'modis' + n, () => {
                        map.getCanvas().style.cursor = 'auto';
                    });
                }
            }
        } else {
            notify('info', 'You must be zoomed in more to see hotspots.');
        }
    }

    async pnwVulnerability() {
        const data = await api('https://services1.arcgis.com/gGHDlz6USftL5Pau/ArcGIS/rest/services/PNW_community_vulnerability_ranks_only/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', 'FID,City,State,Overall_Vu'],
            ['returnGeometry', true],
            ['resultType', 'tile'],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['f', 'geojson']
        ]);

        if (data && data.features.length > 0) {
            if (!map.getSource('ev')) {
                map.addSource('ev', {
                    type: 'geojson',
                    data: data
                });
            }

            if (!map.getLayer('ev')) {
                map.addLayer({
                    id: 'ev',
                    type: 'circle',
                    source: 'ev',
                    minzoom: 6.5,
                    paint: {
                        'circle-radius': [
                            'interpolate',
                            ['linear'],
                            ['zoom'],
                            6,
                            8,
                            15,
                            15
                        ],
                        'circle-color': [
                            'case',
                            ['<=', ['to-number', ['get', 'Overall_Vu']], 174],
                            '#690207',
                            [
                                'all',
                                ['>', ['to-number', ['get', 'Overall_Vu']], 174],
                                ['<=', ['to-number', ['get', 'Overall_Vu']], 348],
                            ],
                            '#f6800b',
                            [
                                'all',
                                ['>', ['to-number', ['get', 'Overall_Vu']], 348],
                                ['<=', ['to-number', ['get', 'Overall_Vu']], 522],
                            ],
                            '#fef36d',
                            '#a7dc83'
                        ],
                        'circle-opacity': 0.9,
                        'circle-stroke-color': '#555',
                        'circle-stroke-width': 1,
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });

                map.on('mouseenter', 'ev', () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', 'ev', () => {
                    map.getCanvas().style.cursor = 'auto';
                });
            }
        }
    }

    async erc(update = false, toggle = false) {
        const sel = document.querySelector('#erc_time'),
            dy = sel ? sel.options[sel.selectedIndex].value : settings.special().erc(),
            obs = [
                'case',
                ['<', ['to-number', ['get', 'avg_erc_percentile']], 60],
                'rgb(56, 168, 0)',
                [
                    'all',
                    ['>=', ['to-number', ['get', 'avg_erc_percentile']], 60],
                    ['<', ['to-number', ['get', 'avg_erc_percentile']], 80]
                ],
                'rgb(209, 255, 115)',
                [
                    'all',
                    ['>=', ['to-number', ['get', 'avg_erc_percentile']], 80],
                    ['<', ['to-number', ['get', 'avg_erc_percentile']], 90]
                ],
                'rgb(255, 255, 190)',
                [
                    'all',
                    ['>=', ['to-number', ['get', 'avg_erc_percentile']], 90],
                    ['<', ['to-number', ['get', 'avg_erc_percentile']], 97]
                ],
                'rgb(255, 170, 0)',
                [
                    'all',
                    ['>=', ['to-number', ['get', 'avg_erc_percentile']], 97],
                    ['<', ['to-number', ['get', 'avg_erc_percentile']], 100]
                ],
                'rgb(255, 0, 0)',
                ['>=', ['to-number', ['get', 'avg_erc_percentile']], 100],
                'rgb(168, 0, 0)',
                '#e1e1e1'
            ],
            fcst = [
                'case',
                ['<', ['to-number', ['get', 'avg_erc_fcast_percentile']], 60],
                'rgb(56, 168, 0)',
                [
                    'all',
                    ['>=', ['to-number', ['get', 'avg_erc_fcast_percentile']], 60],
                    ['<', ['to-number', ['get', 'avg_erc_fcast_percentile']], 80]
                ],
                'rgb(209, 255, 115)',
                [
                    'all',
                    ['>=', ['to-number', ['get', 'avg_erc_fcast_percentile']], 80],
                    ['<', ['to-number', ['get', 'avg_erc_fcast_percentile']], 90]
                ],
                'rgb(255, 255, 190)',
                [
                    'all',
                    ['>=', ['to-number', ['get', 'avg_erc_fcast_percentile']], 90],
                    ['<', ['to-number', ['get', 'avg_erc_fcast_percentile']], 97]
                ],
                'rgb(255, 170, 0)',
                [
                    'all',
                    ['>=', ['to-number', ['get', 'avg_erc_fcast_percentile']], 97],
                    ['<', ['to-number', ['get', 'avg_erc_fcast_percentile']], 100]
                ],
                'rgb(255, 0, 0)',
                ['>=', ['to-number', ['get', 'avg_erc_fcast_percentile']], 100],
                'rgb(168, 0, 0)',
                '#e1e1e1'
            ];

        if (toggle) {
            map.setPaintProperty('erc_fill', 'fill-color', dy == 'obs' ? obs : fcst);
        } else {
            ////https://services3.arcgis.com/T4QMspbfLg3qTGWY/ArcGIS/rest/services/DRAFT_NFDRS_v3_view/FeatureServer/1/query
            const data = await api('https://services3.arcgis.com/T4QMspbfLg3qTGWY/ArcGIS/rest/services/PSA_ERC_and_BI_Percentiles_and_Trends/FeatureServer/0/query', [
                ['where', '1=1'],
                ['outFields', 'OBJECTID,PSANAME,PSANationalCode,avg_erc,avg_erc_fcast_percentile,avg_erc_fcast_trend,avg_erc_percentile,avg_erc_trend,update_date,update_time,ERC_Chart_URL'],
                //['outFields', 'PSANationalCode'],
                ['returnGeometry', true],
                ['inSR', 4326],
                ['outSR', 4326],
                ['resultType', 'tile'],
                ['geometryPrecision', 6],
                ['geometryType', 'esriGeometryEnvelope'],
                ['spatialRel', 'esriSpatialRelIntersects'],
                ['geometry', getbbox()],
                ['f', 'geojson']
            ]);

            /* add ID to features for mapbox */
            data.features.forEach((f, n) => {
                data.features[n].id = f.properties.OBJECTID;
            });

            if (update) {
                map.getSource('erc').setData(data);
                map.setPaintProperty('erc_fill', 'fill-color', dy == 'obs' ? obs : fcst)
            } else {
                if (data && data.features.length > 0) {
                    if (!map.getSource('erc')) {
                        map.addSource('erc', {
                            type: 'geojson',
                            data: data
                        });
                    }

                    if (!map.getLayer('erc_fill')) {
                        map.addLayer({
                            id: 'erc_fill',
                            type: 'fill',
                            source: 'erc',
                            paint: {
                                'fill-color': dy == 'obs' ? obs : fcst,
                                'fill-opacity': 0.5
                            },
                            layout: {
                                visibility: 'visible'
                            }
                        });
                    }

                    if (!map.getLayer('erc_outline')) {
                        map.addLayer({
                            id: 'erc_outline',
                            type: 'line',
                            source: 'erc',
                            paint: {
                                'line-color': [
                                    'case',
                                    ['boolean', ['feature-state', 'click'], false],
                                    '#111',
                                    '#555'
                                ],
                                'line-width': [
                                    'case',
                                    ['boolean', ['feature-state', 'click'], false],
                                    3,
                                    1
                                ]
                            },
                            layout: {
                                visibility: 'visible'
                            }
                        });
                    }
                }
            }
        }
    }

    /*nfdrs() {
        if (!map.getSource('nfdrs')) {
            map.addSource('nfdrs', {
                'type': 'raster',
                'tiles': [
                    'https://fsapps.nwcg.gov/psp/arcgis/rest/services/npsg/Fire_Danger/MapServer/export?service=WMS&request=GetMap&layers=show:0&styles=&format=png32&transparent=true&version=1.1.1&id=National Fire Danger Rating System (NFDRS)&dpi=96&bboxSR=102100&imageSR=102100&size=256,256&f=image&width=1477&height=482&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                'tileSize': 256
            });
        }
 
        if (!map.getLayer('nfdrs')) {
            map.addLayer({
                id: 'nfdrs',
                type: 'raster',
                source: 'nfdrs',
                paint: {
                    'raster-opacity': 0.7
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }*/

    sfp(update = false) {
        const ss = document.querySelector('#sfpDateSelect'),
            bkTime = ss ? ss.options[ss.selectedIndex].value : sfpTimes()[0].key,
            time = settings.special().sfpDate() && new Date(settings.special().sfpDate()) >= new Date() ? settings.special().sfpDate() : bkTime,
            url = 'https://fsapps.nwcg.gov/psp/arcgis/services/npsg/current_forecast/MapServer/WMSServer?service=WMS&request=GetMap&layers=0&styles=&format=image%2Fpng&transparent=true&version=1.1.1&Index=1&height=512&width=512&TIME=' + time + '&srs=EPSG%3A3857&bbox={bbox-epsg-3857}';

        if (update) {
            map.getSource('sfp').setTiles([
                url
            ]);
        } else {
            if (!map.getSource('sfp')) {
                map.addSource('sfp', {
                    type: 'raster',
                    tiles: [
                        url
                    ],
                    tileSize: 256
                });
            }

            if (!map.getLayer('sfp')) {
                map.addLayer({
                    id: 'sfp',
                    type: 'raster',
                    source: 'sfp',
                    paint: {
                        'raster-opacity': 0.5
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }
        }
    }

    async spcClimo(day = 0, update = false, absolute = false) {
        let dateObj = new Date(this.spcClimoDate);
        const monthLengths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

        if (absolute) {
            let dayCounter = 0;
            for (let m = 0; m < 12; m++) {
                if (day < dayCounter + monthLengths[m]) {
                    dateObj.setMonth(m);
                    dateObj.setDate(day - dayCounter + 1);
                    break;
                }
                dayCounter += monthLengths[m];
            }
            this.spcClimoDate = dateObj.getTime();
        } else if (day !== 0) {
            this.spcClimoDate += day * 86400 * 1000;
            dateObj = new Date(this.spcClimoDate);
        }

        const dayOfYear = (d) => {
            let doy = 0;
            for (let i = 0; i < d.getMonth(); i++) doy += monthLengths[i];
            return doy + d.getDate() - 1;
        };

        const doy = dayOfYear(dateObj),
            control = document.querySelector('.spcTimeline');

        if (!control) {
            const options = () => {
                let ops = '';
                const start = new Date('1/1/2026').getTime();
                for (let i = 0; i < 365; i++) {
                    const date = new Date(start + (86400 * 1000 * i));
                    ops += `<option value="${i}">${config.longMonths[date.getMonth()]} ${date.getDate()}</option>`;
                }
                return ops;
            }

            const el = document.createElement('div');
            el.classList.add('spcTimeline');
            el.style.maxWidth = '225px';
            el.innerHTML = `
                <div style="justify-content:space-evenly">
                    <span id="tlb" data-action="spc-climo" data-dir="back" class="fas fa-backward-step tlcontrol disabled"></span>
                    <select id="spcDates" data-action="spcDates">${options()}</select>
                    <span id="tlf" data-action="spc-climo" data-dir="next" class="fas fa-forward-step tlcontrol"></span>
                </div>`;
            document.querySelector('.app-wrapper').appendChild(el);
        } else {
            const select = control.querySelector('#spcDates');
            select.selectedIndex = day;

            control.querySelector('#tlb').setAttribute('data-date', doy - 1);
            control.querySelector('#tlf').setAttribute('data-date', doy + 1);

            control.querySelector('#tlb').classList.toggle('disabled', doy === 0);
            control.querySelector('#tlf').classList.toggle('disabled', doy === 364);
        }

        // Fetch geojson using day of year
        const name = 'spc_climo',
            geojson = await api(config.host + 'api/v1/climo', [['day', doy]]);

        if (update) {
            map.getSource(name).setData(geojson);
        } else {
            if (!map.getSource(name)) {
                map.addSource(name, {
                    type: 'geojson',
                    data: geojson
                });
            }

            if (!map.getLayer(name + '_outline')) {
                map.addLayer({
                    id: name + '_outline',
                    type: 'line',
                    source: name,
                    paint: {
                        'line-color': ['get', 'fill'],
                        'line-width': 1,
                        'line-opacity': 0.75
                    },
                    layout: { visibility: 'visible' }
                });
            }

            if (!map.getLayer(name + '_fill')) {
                map.addLayer({
                    id: name + '_fill',
                    type: 'fill',
                    source: name,
                    paint: {
                        'fill-color': ['get', 'fill'],
                        'fill-opacity': 0.7
                    },
                    layout: { visibility: 'visible' }
                });
            }

            if (!map.getSource(name + '_prob')) {
                map.addLayer({
                    id: name + '_prob',
                    type: 'symbol',
                    source: name,
                    minzoom: 6.75,
                    paint: {
                        'text-color': '#333',
                        'text-halo-color': '#f9f9f9',
                        'text-halo-blur': 1,
                        'text-halo-width': 1
                    },
                    layout: {
                        'symbol-placement': 'line',
                        'symbol-spacing': 400,
                        'text-font': config.fonts.din(),
                        'text-field': ['concat', '>=100 acre probability: ', ['to-string', ['to-number', ['get', 'title']]], '%'],
                        'text-size': 13,
                        'text-max-angle': 30,
                        'text-padding': 5,
                        'text-pitch-alignment': 'viewport',
                        'text-rotation-alignment': 'map',
                        'text-offset': [0, 1]
                    }
                });
            }
        }
    }

    async nri(update = false) {
        const data = await api('https://services.arcgis.com/XG15cJAlne2vxtgt/ArcGIS/rest/services/National_Risk_Index_Counties/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', 'OBJECTID,NRI_ID,COUNTY,STATE,STATEABBRV,WFIR_RISKS,WFIR_RISKR,EAL_SPCTL,POPULATION,BUILDVALUE,AGRIVALUE,AREA'],
            ['geometry', getbbox()],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['returnGeometry', true],
            ['f', 'geojson']]);

        if (update) {
            map.getSource('nri').setData(data);
        } else {
            if (!map.getSource('nri')) {
                map.addSource('nri', {
                    type: 'geojson',
                    data: data
                });
            }

            if (!map.getLayer('nri_fill')) {
                map.addLayer({
                    id: 'nri_fill',
                    type: 'fill',
                    source: 'nri',
                    paint: {
                        'fill-color': [
                            'case',
                            ['==', ['get', 'WFIR_RISKR'], 'No Rating'], '#fff',
                            ['==', ['get', 'WFIR_RISKR'], 'Very Low'], '#4d6dbd',
                            ['==', ['get', 'WFIR_RISKR'], 'Relatively Low'], '#509bc7',
                            ['==', ['get', 'WFIR_RISKR'], 'Relatively Moderate'], '#f0d55d',
                            ['==', ['get', 'WFIR_RISKR'], 'Relatively High'], '#e07069',
                            ['==', ['get', 'WFIR_RISKR'], 'Very High'], '#c7445d',
                            '#9e9e9e'
                        ],
                        'fill-opacity': 0.5
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }

            if (!map.getLayer('nri_outline')) {
                map.addLayer({
                    id: 'nri_outline',
                    type: 'line',
                    source: 'nri',
                    paint: {
                        'line-color': [
                            'case',
                            ['boolean', ['feature-state', 'click'], false],
                            '#111',
                            '#555'
                        ],
                        'line-width': [
                            'case',
                            ['boolean', ['feature-state', 'click'], false],
                            3,
                            1
                        ]
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }
        }
    }

    async power(update = false) {
        const data = await api('https://services3.arcgis.com/T4QMspbfLg3qTGWY/ArcGIS/rest/services/powerlines/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', '*'],
            ['geometry', getbbox()],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['returnGeometry', true],
            ['f', 'geojson']]);

        if (update) {
            map.getSource('power').setData(data);
        } else {
            if (!map.getSource('power')) {
                map.addSource('power', {
                    type: 'geojson',
                    data: data
                });
            }

            if (!map.getLayer('power')) {
                map.addLayer({
                    id: 'power',
                    type: 'line',
                    source: 'power',
                    minzoom: 6,
                    paint: {
                        'line-color': '#9c27b0',
                        'line-width': [
                            'interpolate',
                            ['linear'],
                            ['zoom'],
                            6,
                            2,
                            16,
                            6
                        ]
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }
        }
    }

    rth() {
        if (!map.getSource('rth')) {
            map.addSource('rth', {
                type: 'raster',
                tiles: [
                    'https://imagery.geoplatform.gov/iipp/rest/services/Fire_Aviation/USFS_EDW_RMRS_WRC_RiskToPotentialStructures/ImageServer/exportImage?service=WMS&request=GetMap&layers=show%3A0&styles=&format=png32&transparent=true&version=1.1.1&id=Wildfire%20Risk%20to%20Homes&dpi=96&bboxSR=102100&imageSR=102100&size=256%2C256&f=image&width=256&height=256&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('rth')) {
            map.addLayer({
                id: 'rth',
                type: 'raster',
                source: 'rth',
                paint: {
                    'raster-opacity': 0.6
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    wet() {
        if (!map.getSource('wet')) {
            map.addSource('wet', {
                type: 'raster',
                tiles: [
                    'https://imagery.geoplatform.gov/iipp/rest/services/Fire_Aviation/USFS_EDW_RMRS_WRC_ExposureType/ImageServer/exportImage?service=WMS&request=GetMap&layers=show%3A0&styles=&format=png32&transparent=true&version=1.1.1&id=Wildfire%20Risk%20to%20Homes&dpi=96&bboxSR=102100&imageSR=102100&size=256%2C256&f=image&width=256&height=256&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('wet')) {
            map.addLayer({
                id: 'wet',
                type: 'raster',
                source: 'wet',
                paint: {
                    'raster-opacity': 0.6
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    bp() {
        if (!map.getSource('bp')) {
            map.addSource('bp', {
                type: 'raster',
                tiles: [
                    'https://imagery.geoplatform.gov/iipp/rest/services/Fire_Aviation/USFS_EDW_RMRS_WRC_BurnProbability/ImageServer/exportImage?service=WMS&request=GetMap&layers=show%3A0&styles=&format=png32&transparent=true&version=1.1.1&id=Wildfire%20Risk%20to%20Homes&dpi=96&bboxSR=102100&imageSR=102100&size=256%2C256&f=image&width=256&height=256&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('bp')) {
            map.addLayer({
                id: 'bp',
                type: 'raster',
                source: 'bp',
                paint: {
                    'raster-opacity': 0.6
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    whp() {
        if (!map.getSource('whp')) {
            map.addSource('whp', {
                type: 'raster',
                tiles: [
                    'https://imagery.geoplatform.gov/iipp/rest/services/Fire_Aviation/USFS_EDW_RMRS_WRC_WildfireHazardPotential/ImageServer/exportImage?service=WMS&request=GetMap&layers=show%3A0&styles=&format=png32&transparent=true&version=1.1.1&id=Wildfire%20Hazard%20Potential%20(2018)&dpi=96&bboxSR=102100&imageSR=102100&size=256%2C256&f=image&width=256&height=256&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('whp')) {
            map.addLayer({
                id: 'whp',
                type: 'raster',
                source: 'whp',
                paint: {
                    'raster-opacity': 0.6
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    async drought() {
        const ArcGISFeatureSource = window[""]["arcgis-featureserver"],
            color = [
                'case',
                ['==', ['to-number', ['get', 'dm']], 0], '#ffff00',
                ['==', ['to-number', ['get', 'dm']], 1], '#ffcc99',
                ['==', ['to-number', ['get', 'dm']], 2], '#ff6600',
                ['==', ['to-number', ['get', 'dm']], 3], '#ff0000',
                ['==', ['to-number', ['get', 'dm']], 4], '#660000',
                'rgba(255, 255, 255, 0)'
            ];

        if (!map.getSource('drought')) {
            new ArcGISFeatureSource('drought', map, {
                url: 'https://services9.arcgis.com/RHVPKKiFTONKtxq3/ArcGIS/rest/services/US_Drought_Intensity_v1/FeatureServer/3',
                precision: 6,
                where: '1=1',
                outFields: 'ddate,dm'
            });
        }

        if (!map.getLayer('drought')) {
            map.addLayer({
                id: 'drought',
                type: 'fill',
                source: 'drought',
                paint: {
                    'fill-color': color,
                    'fill-opacity': 0.5
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }

        if (!map.getLayer('drought_outline')) {
            map.addLayer({
                id: 'drought_outline',
                type: 'line',
                source: 'drought',
                paint: {
                    'line-color': color,
                    'line-width': 2,
                    'line-opacity': 0.75
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }

        if (!map.getLayer('drought_title')) {
            map.addLayer({
                id: 'drought_title',
                type: 'symbol',
                source: 'drought',
                minzoom: 7.8,
                paint: {
                    'text-color': '#000',
                    'text-halo-color': '#fff',
                    'text-halo-blur': 1,
                    'text-halo-width': 1
                },
                layout: {
                    'symbol-placement': 'line',
                    'symbol-spacing': 400,
                    'text-font': config.fonts.din(),
                    'text-field': [
                        'case',
                        ['==', ['to-number', ['get', 'dm']], 0], 'Abnormally Dry',
                        ['==', ['to-number', ['get', 'dm']], 1], 'Moderate Drought',
                        ['==', ['to-number', ['get', 'dm']], 2], 'Severe Drought',
                        ['==', ['to-number', ['get', 'dm']], 3], 'Extreme Drought',
                        ['==', ['to-number', ['get', 'dm']], 4], 'Exceptional Drought',
                        ''
                    ],
                    'text-justify': 'auto',
                    'text-size': 13,
                    'text-transform': 'uppercase',
                    'text-max-width': 12,
                    'text-max-angle': 30,
                    'text-anchor': 'center',
                    'text-offset': [0, 1],
                    'text-letter-spacing': 0.05
                }
            });
        }
        /*if (!map.getSource('drought')) {
            map.addSource('drought', {
                type: 'raster',
                tiles: [
                    'https://ndmcgeodata.unl.edu/cgi-bin/mapserv.exe?map=/ms4w/apps/usdm/map/usdm_current_wms.map&SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&LAYERS=usdm_current&WIDTH=256&HEIGHT=256&crs=EPSG:3857&styles=default&format=image/png&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('drought')) {
            map.addLayer({
                id: 'drought',
                type: 'raster',
                source: 'drought',
                paint: {
                    'raster-opacity': 0.6
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }*/
    }

    async fuels() {
        if (config.fuelsData == null) {
            const data = await api('https://lfps.usgs.gov/arcgis/rest/services/Landfire_LF250/US_250EVT/ImageServer/rasterAttributeTable', [['f', 'json'], ['renderingRule', '{"rasterFunction":"US_250EVT"}']]);

            config.fuelsData = data.features;
        }

        if (!map.getSource('fuels')) {
            map.addSource('fuels', {
                type: 'raster',
                tiles: [
                    'https://dmsdata.cr.usgs.gov/geoserver/gwc/service/wms?REQUEST=GetMap&SERVICE=WMS&VERSION=1.3.0&FORMAT=image%2Fpng&STYLES=&TRANSPARENT=true&LAYERS=landfire%3ALC24_EVT_250&TILED=true&SRS=EPSG%3A3857&jsonLayerId=us_240%20Fuel%20Vegetation%20Type&WIDTH=256&HEIGHT=256&CRS=EPSG%3A3857&BBOX={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }
        if (!map.getSource('fuelsAK')) {
            map.addSource('fuelsAK', {
                type: 'raster',
                tiles: [
                    'https://dmsdata.cr.usgs.gov/geoserver/gwc/service/wms?REQUEST=GetMap&SERVICE=WMS&VERSION=1.3.0&FORMAT=image%2Fpng&STYLES=&TRANSPARENT=true&LAYERS=landfire%3ALA24_EVT_250&TILED=true&SRS=EPSG%3A3857&jsonLayerId=ak_240%20Existing%20Vegetation%20Type&WIDTH=256&HEIGHT=256&CRS=EPSG%3A3857&BBOX={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('fuels')) {
            map.addLayer({
                id: 'fuels',
                type: 'raster',
                source: 'fuels',
                paint: {
                    'raster-opacity': 0.6
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }

        if (!map.getLayer('fuelsAK')) {
            map.addLayer({
                id: 'fuelsAK',
                type: 'raster',
                source: 'fuelsAK',
                paint: {
                    'raster-opacity': 0.6
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    countyBounds() {
        if (!map.getSource('countyBounds')) {
            map.addSource('countyBounds', {
                type: 'raster',
                tiles: [
                    'https://mapservices.weather.noaa.gov/static/rest/services/nws_reference_maps/nws_reference_map/MapServer/export?service=WMS&request=GetMap&layers=show%3A2&styles=&format=png32&transparent=true&version=1.1.1&id=Counties&size=256,256&bboxSR=102100&imageSR=102100&f=image&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('countyBounds')) {
            map.addLayer({
                id: 'countyBounds',
                type: 'raster',
                source: 'countyBounds',
                paint: {
                    'raster-opacity': 1
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    nwsCWAs() {
        if (!map.getSource('nwsCWAs')) {
            map.addSource('nwsCWAs', {
                type: 'raster',
                tiles: [
                    'https://mapservices.weather.noaa.gov/static/rest/services/nws_reference_maps/nws_reference_map/MapServer/export?service=WMS&request=GetMap&layers=show%3A1&styles=&format=png32&transparent=true&version=1.1.1&id=NWS%20CWAs&size=256,256&bboxSR=3857&imageSR=3857&f=image&dpi=90&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('nwsCWAs')) {
            map.addLayer({
                id: 'nwsCWAs',
                type: 'raster',
                source: 'nwsCWAs',
                paint: {
                    'raster-opacity': 1
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    /*usfs() {
        if (!map.getSource('usfs')) {
            map.addSource('usfs', {
                type: 'raster',
                tiles: [
                    'https://apps.fs.usda.gov/fsgisx05/rest/services/wo_nfs_gtac/EGIS_RecreationBasemap_01/MapServer/tile/{z}/{y}/{x}'
                ],
                tileSize: 256
            });
        }
 
        if (!map.getLayer('usfs')) {
            map.addLayer({
                id: 'usfs',
                type: 'raster',
                source: 'usfs',
                minzoom: 0,
                maxzoom: 19,        
                paint: {
                    'raster-opacity': 1
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }*/

    roads() {
        if (!map.getSource('roads')) {
            map.addSource('roads', {
                type: 'raster',
                tiles: [
                    'https://apps.fs.usda.gov/arcx/rest/services/EDW/EDW_RoadBasic_01/MapServer/export?service=WMS&request=GetMap&layers=show%3A0&styles=&format=png32&transparent=true&version=1.1.1&id=USFS%20Road%20Network&bboxSR=102100&imageSR=102100&size=256,256&f=image&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('roads')) {
            if (map.getZoom() > 11) {
                map.addLayer({
                    id: 'roads',
                    type: 'raster',
                    source: 'roads',
                    paint: {
                        'raster-opacity': 1
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            } else {
                notify('info', 'You must be zoomed in more to see USFS roads.');
            }
        }
    }

    lands() {
        if (!map.getSource('lands')) {
            map.addSource('lands', {
                type: 'raster',
                tiles: [
                    /*'https://gis.blm.gov/arcgis/rest/services/lands/BLM_Natl_SMA_Cached_without_PriUnk/MapServer/export?service=WMS&request=GetMap&layers=show%3A17&styles=&format=png32&transparent=true&version=1.1.1&id=Federal%20Lands&dpi=96&bboxSR=102100&imageSR=102100&size=256,256&f=image&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'*/
                    'https://gis.blm.gov/arcgis/rest/services/lands/BLM_Natl_SMA_Cached_without_PriUnk/MapServer/tile/{z}/{y}/{x}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('lands')) {
            map.addLayer({
                id: 'lands',
                type: 'raster',
                source: 'lands',
                paint: {
                    'raster-opacity': 0.6
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    plss() {
        if (!map.getSource('plss')) {
            map.addSource('plss', {
                type: 'raster',
                tiles: [
                    'https://gis.blm.gov/arcgis/rest/services/Cadastral/BLM_Natl_PLSS_CadNSDI/MapServer/export?service=WMS&request=GetMap&layers=show%3A1%2C2%2C3&styles=&format=png32&transparent=true&version=1.1.1&id=PLSS&dpi=96&bboxSR=102100&imageSR=102100&size=256,256&f=image&srs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                tileSize: 256
            });
        }

        if (!map.getLayer('plss')) {
            map.addLayer({
                id: 'plss',
                type: 'raster',
                source: 'plss',
                paint: {
                    'raster-opacity': 1
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    async dispatch(update = false) {
        const data = await api('https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/DMP_National_Dispatch_Boundaries_Public/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', 'OBJECTID,DispName,DispUnitID,DispLocation,ContactPhone'],
            ['returnGeometry', true],
            ['resultType', 'tile'],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['geometry', getbbox()],
            ['f', 'geojson']
        ]);

        if (update) {
            map.getSource('dispatch').setData(data);
        } else {
            if (data && data.features.length > 0) {
                if (!map.getSource('dispatch')) {
                    map.addSource('dispatch', {
                        type: 'geojson',
                        data: data
                    });
                }

                if (!map.getLayer('dispatch_outline')) {
                    map.addLayer({
                        id: 'dispatch_outline',
                        type: 'line',
                        source: 'dispatch',
                        paint: {
                            'line-color': '#000',
                            'line-width': 2
                        },
                        layout: {
                            visibility: 'visible'
                        }
                    });
                }

                if (!map.getLayer('dispatch_title')) {
                    map.addLayer({
                        id: 'dispatch_title',
                        type: 'symbol',
                        source: 'dispatch',
                        minzoom: 5.7,
                        paint: {
                            'text-color': '#000',
                            'text-halo-color': '#fff',
                            'text-halo-blur': 1,
                            'text-halo-width': 1
                        },
                        layout: {
                            'symbol-placement': 'point',
                            'symbol-spacing': 450,
                            'text-font': config.fonts.din(),
                            'text-field': ['get', 'DispName'],
                            'text-justify': 'auto',
                            'text-size': 14,
                            'text-max-width': 12,
                            'text-anchor': 'bottom',
                            'text-offset': [0, 1.3],
                            'text-letter-spacing': 0.05
                        }
                    });
                }
            }
        }
    }

    async gaccBounds(update = false) {
        const data = await api('https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/DMP_NationalGACCBoundaries_Public/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', 'OBJECTID,GACCUnitID,GACCName,GACCLocation'],
            ['returnGeometry', true],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['resultType', 'tile'],
            ['geometry', getbbox()],
            ['f', 'geojson']
        ]);

        if (update) {
            map.getSource('gaccBounds').setData(data);
        } else {
            if (data && data.features.length > 0) {
                if (!map.getSource('gaccBounds')) {
                    map.addSource('gaccBounds', {
                        type: 'geojson',
                        data: data
                    });
                }

                if (!map.getLayer('gaccBounds')) {
                    map.addLayer({
                        id: 'gaccBounds',
                        type: 'line',
                        source: 'gaccBounds',
                        paint: {
                            'line-color': '#000',
                            'line-width': 2
                        },
                        layout: {
                            visibility: 'visible'
                        }
                    });
                }

                if (!map.getLayer('gaccBounds_title')) {
                    map.addLayer({
                        id: 'gaccBounds_title',
                        type: 'symbol',
                        source: 'gaccBounds',
                        minzoom: 5.7,
                        paint: {
                            'text-color': '#000',
                            'text-halo-color': '#fff',
                            'text-halo-blur': 1,
                            'text-halo-width': 1
                        },
                        layout: {
                            'symbol-placement': 'point',
                            'symbol-spacing': 450,
                            'text-font': config.fonts.din(),
                            'text-field': ['get', 'GACCName'],
                            'text-justify': 'auto',
                            'text-size': 14,
                            'text-max-width': 12,
                            'text-anchor': 'bottom',
                            'text-offset': [0, 1.3],
                            'text-letter-spacing': 0.05
                        }
                    });
                }
            }
        }
    }

    async hms(update = false) {
        const data = await api('https://services2.arcgis.com/C8EMgrsFcRFL6LrL/arcgis/rest/services/NOAA_Satellite_Smoke_Detection_(v1)/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', '*'],
            ['resultType', 'tile'],
            ['geometry', getbbox()],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['returnGeometry', true],
            ['f', 'geojson']
        ]);

        if (update && map.getSource('hms')) {
            map.getSource('hms').setData(data);
        } else {
            if (!map.getSource('hms')) {
                map.addSource('hms', {
                    type: 'geojson',
                    data: data
                });
            }

            if (!map.getLayer('hms')) {
                map.addLayer({
                    id: 'hms',
                    type: 'fill',
                    source: 'hms',
                    paint: {
                        'fill-color': [
                            'case',
                            ['==', ['get', 'Density'], 'Light'], '#aaa',
                            ['==', ['get', 'Density'], 'Light'], '#757575',
                            '#666'
                        ],
                        'fill-opacity': 0.5
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }

            if (!map.getSource('hms_title')) {
                map.addLayer({
                    id: 'hms_title',
                    type: 'symbol',
                    source: 'hms',
                    minzoom: 5.8,
                    paint: {
                        'text-color': '#333',
                        'text-halo-color': '#f9f9f9',
                        'text-halo-blur': 1,
                        'text-halo-width': 1
                    },
                    layout: {
                        'symbol-placement': 'line',
                        'symbol-spacing': 200,
                        'text-font': config.fonts.din(),
                        'text-field': ['concat', ['get', 'Density'], ' Smoke'],
                        'text-size': 13,
                        'text-max-angle': 30,
                        'text-padding': 5,
                        'text-pitch-alignment': 'viewport',
                        'text-rotation-alignment': 'map',
                        'text-offset': [0, 1]
                    }
                });
            }
        }
    }

    async smokeFcst(update = false) {
        const start = gmtime(+3600).replace('T', ' '),
            end = gmtime(+7200).replace('T', ' '),
            rounds = ['0 - 3', '3 - 25', '25 - 63', '63 - 158', '158 - 1000'],
            data = await api('https://services9.arcgis.com/RHVPKKiFTONKtxq3/arcgis/rest/services/NDGD_SmokeForecast_v1/FeatureServer/0/query', [
                ['where', '1=1 AND todate > DATE \'' + start + '\' AND todate < DATE \'' + end + '\''],
                ['outFields', '*'],
                ['resultType', 'tile'],
                ['geometry', getbbox()],
                ['geometryPrecision', 6],
                ['geometryType', 'esriGeometryEnvelope'],
                ['spatialRel', 'esriSpatialRelIntersects'],
                ['returnGeometry', true],
                ['f', 'geojson']
            ]);

        // update the geojson so maplibre can parse the colors correctly
        if (data.features && data.features.length > 0) {
            for (let i = 0; i < data.features.length; i++) {
                const txt = data.features[i].properties.smoke_classdesc.toString();

                data.features[i].properties.class = txt;

                for (let x = 0; x < rounds.length; x++) {
                    if (txt.search(rounds[x]) >= 0) {
                        data.features[i].properties.smoke_classdesc = x;
                    }
                }
            }
        }

        if (update && map.getSource('smokeFcst')) {
            map.getSource('smokeFcst').setData(data);
        } else {
            if (!map.getSource('smokeFcst')) {
                map.addSource('smokeFcst', {
                    type: 'geojson',
                    data: data
                });
            }

            if (!map.getLayer('smokeFcst')) {
                map.addLayer({
                    id: 'smokeFcst',
                    type: 'fill',
                    source: 'smokeFcst',
                    paint: {
                        'fill-color': [
                            'case',
                            ['==', ['to-string', ['get', 'smoke_classdesc']], '0'], '#ffffc0',
                            ['==', ['to-string', ['get', 'smoke_classdesc']], '1'], '#fcdf8b',
                            ['==', ['to-string', ['get', 'smoke_classdesc']], '2'], '#f6c26d',
                            ['==', ['to-string', ['get', 'smoke_classdesc']], '3'], '#c5885c',
                            ['==', ['to-string', ['get', 'smoke_classdesc']], '4'], '#974f4f',
                            '#f8fde0'
                        ],
                        'fill-opacity': 0.6
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }
        }
    }

    sfcSmoke(fcstHour = null) {
        if (fcstHour == null) {
            fcstHour = hrrrSmokeTime.fcst;

            if (!map.getSource('sfcSmoke')) {
                map.addSource('sfcSmoke', {
                    type: 'raster',
                    tiles: [
                        'https://apps.gsl.noaa.gov/smoke/wmts/image/hrrr_smoke?var=sfc_smoke&x={x}&y={y}&z={z}&time=' + fcstHour + '&modelrun=' + hrrrSmokeTime.init + '&level=0'
                    ],
                    tileSize: 256
                });
            }

            if (!map.getLayer('sfcSmoke')) {
                map.addLayer({
                    id: 'sfcSmoke',
                    type: 'raster',
                    source: 'sfcSmoke',
                    paint: {
                        'raster-opacity': 0.75
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }
        } else {
            map.getSource('sfcSmoke').setTiles([
                'https://apps.gsl.noaa.gov/smoke/wmts/image/hrrr_smoke?var=sfc_smoke&x={x}&y={y}&z={z}&time=' + fcstHour + '&modelrun=' + hrrrSmokeTime.init + '&level=0'
            ]);
        }
    }

    viSmoke(fcstHour = null) {
        if (fcstHour == null) {
            fcstHour = hrrrSmokeTime.fcst;

            if (!map.getSource('viSmoke')) {
                map.addSource('viSmoke', {
                    type: 'raster',
                    tiles: [
                        'https://apps.gsl.noaa.gov/smoke/wmts/image/hrrr_smoke?var=vi_smoke&x={x}&y={y}&z={z}&time=' + fcstHour + '&modelrun=' + hrrrSmokeTime.init + '&level=0'
                    ],
                    tileSize: 256
                });
            }

            if (!map.getLayer('viSmoke')) {
                map.addLayer({
                    id: 'viSmoke',
                    type: 'raster',
                    source: 'viSmoke',
                    paint: {
                        'raster-opacity': 0.75
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }
        } else {
            map.getSource('viSmoke').setTiles([
                'https://apps.gsl.noaa.gov/smoke/wmts/image/hrrr_smoke?var=vi_smoke&x={x}&y={y}&z={z}&time=' + fcstHour + '&modelrun=' + hrrrSmokeTime.init + '&level=0'
            ]);
        }
    }

    async odfFDR(update = false) {
        const color = [
            'case',
            ['==', ['to-number', ['get', 'firedanger']], 1], '#8bc53f',
            ['==', ['to-number', ['get', 'firedanger']], 2], '#fef100',
            ['==', ['to-number', ['get', 'firedanger']], 3], '#ffa939',
            ['==', ['to-number', ['get', 'firedanger']], 4], '#ec1c24',
            '#fff'
        ],
            data = await api('https://gis.odf.oregon.gov/odfags/rest/services/Hosted/Fire_Danger_Level_View/FeatureServer/0/query', [
                ['where', '1=1'],
                ['outFields', '*'],
                ['returnGeometry', true],
                ['geometryPrecision', 12],
                ['f', 'geojson']
            ]);

        if (update) {
            map.getSource('odfFDR').setData(data);
        } else {
            if (data && data.features.length > 0) {
                if (!map.getSource('odfFDR')) {
                    map.addSource('odfFDR', {
                        type: 'geojson',
                        data: data
                    });
                }

                if (!map.getLayer('odfFDR')) {
                    map.addLayer({
                        id: 'odfFDR',
                        type: 'fill',
                        source: 'odfFDR',
                        paint: {
                            'fill-color': color,
                            'fill-opacity': 0.3
                        },
                        layout: {
                            visibility: 'visible'
                        }
                    });

                    map.on('mouseenter', 'odfFDR', () => {
                        map.getCanvas().style.cursor = 'pointer';
                    });

                    map.on('mouseleave', 'odfFDR', () => {
                        map.getCanvas().style.cursor = 'auto';
                    });
                }

                if (!map.getLayer('odfFDR_outline')) {
                    map.addLayer({
                        id: 'odfFDR_outline',
                        type: 'line',
                        source: 'odfFDR',
                        paint: {
                            'line-color': color,
                            'line-width': 2
                        },
                        layout: {
                            visibility: 'visible'
                        }
                    });
                }

                if (!map.getLayer('odfFDR_title')) {
                    map.addLayer({
                        id: 'odfFDR_title',
                        type: 'symbol',
                        source: 'odfFDR',
                        minzoom: 4,
                        paint: {
                            'text-color': '#000',
                            'text-halo-color': '#ddd',
                            'text-halo-blur': 1,
                            'text-halo-width': 1
                        },
                        layout: {
                            'symbol-placement': 'line',
                            'symbol-spacing': 400,
                            'text-font': config.fonts.din(),
                            'text-field': [
                                'concat',
                                'ODF Fire Danger: ',
                                [
                                    'case',
                                    ['==', ['to-number', ['get', 'firedanger']], 4],
                                    'Extreme',
                                    ['==', ['to-number', ['get', 'firedanger']], 3],
                                    'High',
                                    ['==', ['to-number', ['get', 'firedanger']], 2],
                                    'Moderate',
                                    ['==', ['to-number', ['get', 'firedanger']], 1],
                                    'Low',
                                    'N/A'
                                ],
                                ' (',
                                ['get', 'regusearea'],
                                ')'
                            ],
                            'text-justify': 'auto',
                            'text-size': 16,
                            'text-max-width': 12,
                            'text-max-angle': 30,
                            'text-transform': 'uppercase',
                            'text-anchor': 'bottom',
                            'text-offset': [0, 1.6],
                            'text-letter-spacing': 0.05
                        }
                    });
                }
            }
        }
    }

    async calfireUnits(update = false) {
        const data = await api('https://services1.arcgis.com/jUJYIo9tSA7EHvfZ/arcgis/rest/services/cdfadmin19_1/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', 'UNIT,UNITCODE,REGION'],
            ['returnGeometry', true],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['geometry', getbbox()],
            ['resultType', 'tile'],
            ['f', 'geojson']
        ]);

        if (update) {
            map.getSource('calfireUnits').setData(data);
        } else {
            if (data && data.features.length > 0) {
                if (!map.getSource('calfireUnits')) {
                    map.addSource('calfireUnits', {
                        type: 'geojson',
                        data: data
                    });
                }

                if (!map.getLayer('calfireUnits')) {
                    map.addLayer({
                        id: 'calfireUnits',
                        type: 'line',
                        source: 'calfireUnits',
                        paint: {
                            'line-color': '#177ca3',
                            'line-width': 2
                        },
                        layout: {
                            visibility: 'visible'
                        }
                    });
                }

                if (!map.getLayer('calfireUnits_title')) {
                    map.addLayer({
                        id: 'calfireUnits_title',
                        type: 'symbol',
                        source: 'calfireUnits',
                        minzoom: 5.7,
                        paint: {
                            'text-color': '#177ca3',
                            'text-halo-color': '#fff',
                            'text-halo-blur': 1,
                            'text-halo-width': 1
                        },
                        layout: {
                            'symbol-placement': 'point',
                            'symbol-spacing': 450,
                            'text-font': config.fonts.din(),
                            'text-field': ['get', 'UNIT'],
                            'text-justify': 'auto',
                            'text-size': 14,
                            'text-max-width': 12,
                            'text-anchor': 'bottom',
                            'text-offset': [0, 1.3],
                            'text-letter-spacing': 0.05
                        }
                    });
                }
            }
        }
    }

    async cdfFHSZ(update = false) {
        const data = await api('https://services1.arcgis.com/jUJYIo9tSA7EHvfZ/ArcGIS/rest/services/FHSZ_SRA_LRA_Combined/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', 'FHSZ'],
            ['returnGeometry', true],
            ['resultType', 'tile'],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['geometry', getbbox()],
            ['f', 'geojson']
        ]);

        if (update) {
            map.getSource('cdfFHSZ').setData(data);
        } else {
            if (data && data.features.length > 0) {
                if (!map.getSource('cdfFHSZ')) {
                    map.addSource('cdfFHSZ', {
                        type: 'geojson',
                        data: data
                    });
                }

                if (!map.getLayer('cdfFHSZ')) {
                    map.addLayer({
                        id: 'cdfFHSZ',
                        type: 'fill',
                        source: 'cdfFHSZ',
                        paint: {
                            'fill-color': [
                                'case',
                                ['==', ['to-number', ['get', 'FHSZ']], 1], '#ffff00',
                                ['==', ['to-number', ['get', 'FHSZ']], 2], '#ffaa00',
                                '#ff0000'
                            ],
                            'fill-opacity': 0.75
                        },
                        layout: {
                            visibility: 'visible'
                        }
                    });
                }
            }
        }
    }

    async calfireAircraft(update = false) {
        const data = await api('https://services1.arcgis.com/jUJYIo9tSA7EHvfZ/ArcGIS/rest/services/CAL_FIRE_Aircraft_Tracking_public_view/FeatureServer/0/query', [
            ['where', '1=1'],
            ['outFields', '*'],
            ['geometryPrecision', 6],
            ['returnGeometry', true],
            ['f', 'geojson']
        ]);

        if (update) {
            map.getSource('calfireAircraft').setData(data);
        } else {
            if (data && data.features.length > 0) {
                if (!map.getSource('calfireAircraft')) {
                    map.addSource('calfireAircraft', {
                        type: 'geojson',
                        data: data
                    });
                }

                if (!map.getLayer('calfireAircraft')) {
                    map.addLayer({
                        id: 'calfireAircraft',
                        type: 'symbol',
                        minzoom: 5,
                        source: 'calfireAircraft',
                        layout: {
                            'icon-image': [
                                'case',
                                ['==', ['get', 'organizationGroup'], 'Helicopter'], 'helicopter',
                                ['==', ['get', 'organizationGroup'], 'Tactical'], 'plane_tactical',
                                ['==', ['get', 'organizationGroup'], 'Tanker'], 'plane_large', 'plane_small'],
                            'icon-size': 0.8,
                            'icon-rotate': ['to-number', ['get', 'cog']],
                            'icon-allow-overlap': true,
                            visibility: 'visible'
                        }
                    });
                }

                if (!map.getLayer('calfireAircraft_title')) {
                    map.addLayer({
                        id: 'calfireAircraft_title',
                        type: 'symbol',
                        minzoom: 5.7,
                        source: 'calfireAircraft',
                        paint: {
                            'text-color': '#444',
                            'text-halo-color': '#fff',
                            'text-halo-blur': 1,
                            'text-halo-width': 2
                        },
                        layout: {
                            'symbol-placement': 'point',
                            'text-font': config.fonts.source(),
                            'text-field': ['concat', ['get', 'unitId'], ' ', [
                                'case',
                                ['!=', ['to-string', ['get', 'tailNumber']], 'null'],
                                ['concat', '(', ['get', 'tailNumber'], ')'],
                                ''
                            ], ['get', 'category']],
                            'text-justify': 'center',
                            'text-size': 12,
                            'text-max-width': 8,
                            'text-anchor': 'bottom',
                            'text-offset': [0, 4.5],
                            'text-letter-spacing': 0.05,
                            visibility: 'visible'
                        }
                    });
                }
            }
        }
    }

    async evacuations() {
        if (!evacsLoaded) {
            const data = await api(config.apiURL + 'evacuations'),
                color = [
                    'case',
                    ['==', ['to-number', ['get', 'level']], 2], '#edd601',
                    ['==', ['to-number', ['get', 'level']], 3], '#e60000',
                    '#02823a'
                ];

            /* store active evacuations for use elsewhere within the map */
            evacsLoaded = true;
            if (data.features && data.features.length > 0) {
                activeEvacuations = data.features;
            }

            if (!map.getSource('evac')) {
                map.addSource('evac', {
                    type: 'geojson',
                    data: data
                });
            }

            if (!map.getLayer('evac')) {
                map.addLayer({
                    id: 'evac',
                    type: 'fill',
                    source: 'evac',
                    paint: {
                        'fill-color': color,
                        'fill-opacity': [
                            'interpolate',
                            ['linear'],
                            ['zoom'],
                            4,
                            0.6,
                            8,
                            0.3,
                            11,
                            0.25
                        ]
                    },
                    layout: {
                        visibility: settings.isEnabled('evac') ? 'visible' : 'none'
                    }
                });

                map.on('mouseenter', 'evac', () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', 'evac', () => {
                    map.getCanvas().style.cursor = 'auto';
                });
            }

            if (!map.getLayer('evac_outline')) {
                map.addLayer({
                    id: 'evac_outline',
                    type: 'line',
                    source: 'evac',
                    paint: {
                        'line-color': '#333'/*[
                                'case',
                                ['boolean', ['feature-state', 'click'], false],
                                '#00a6ed',
                                '#222'
                            ]*/,
                        'line-width': [
                            'case',
                            ['boolean', ['feature-state', 'click'], false],
                            3,
                            1
                        ]/*2,
                            'line-dasharray': [0, 2, 3]*/
                    },
                    layout: {
                        visibility: settings.isEnabled('evac') ? 'visible' : 'none'
                    }
                });
            }

            if (!map.getLayer('evac_title')) {
                map.addLayer({
                    id: 'evac_title',
                    type: 'symbol',
                    source: 'evac',
                    minzoom: 9,
                    paint: {
                        'text-color': '#333',
                        'text-halo-color': '#fff',
                        'text-halo-blur': 1,
                        'text-halo-width': 1
                    },
                    layout: {
                        'symbol-placement': 'point',
                        'symbol-spacing': 200,
                        'text-font': config.fonts.roboto(),
                        'text-field': [
                            'case',
                            ['==', ['to-number', ['get', 'level']], 2], 'Level 2: BE SET',
                            ['==', ['to-number', ['get', 'level']], 3], 'Level 3: GO NOW',
                            'Level 1: Be Ready'
                        ],
                        'text-justify': 'center',
                        'text-size': [
                            'interpolate',
                            ['linear'],
                            ['zoom'],
                            10,
                            10,
                            12,
                            15
                        ],
                        'text-max-width': 8,
                        'text-anchor': 'center',
                        'text-offset': [0, 1],
                        'text-letter-spacing': 0.05,
                        visibility: settings.isEnabled('evac') ? 'visible' : 'none'
                    }
                });
            }
        }
    }

    async firemed(update = false) {
        const types = ['hosp', 'ems', 'fire'],
            baseURL = 'https://services2.arcgis.com/FiaPA4ga0iQKduv3/ArcGIS/rest/services/Structures_Medical_Emergency_Response_v1/FeatureServer/',
            fields = [
                ['where', '1=1'],
                ['outFields', 'OBJECTID,NAME,ADDRESS,CITY,STATE,ZIPCODE'],
                ['resultType', 'tile'],
                ['geometry', getbbox()],
                ['geometryPrecision', 6],
                ['geometryType', 'esriGeometryEnvelope'],
                ['spatialRel', 'esriSpatialRelIntersects'],
                ['returnGeometry', true],
                ['f', 'geojson']
            ];

        types.forEach(async (type) => {
            const icon = type == 'fire' ? 'fire_dept' : type;
            if (!map.hasImage(type)) {
                const image = await map.loadImage(config.domain + 'assets/images/icons/fire/' + icon + '_icon.png');
                map.addImage(type, image.data);
            }
        });

        const results = await Promise.allSettled(types.map((_, i) => api(`${baseURL}${i}/query`, fields)));
        const mergedFeatures = results.flatMap((res, i) => {
            if (res.status !== 'fulfilled' || !res.value?.features) return [];

            return res.value.features.map(f => {
                f.properties.type = types[i];
                return f;
            });
        });
        const data = { type: 'FeatureCollection', features: mergedFeatures };

        if (update && map.getSource('firemed')) {
            map.getSource('firemed').setData(data);
        } else {
            if (!map.getSource('firemed')) {
                map.addSource('firemed', {
                    type: 'geojson',
                    data: data,
                    cluster: true,
                    clusterMaxZoom: 11,
                    clusterMinPoints: 3,
                    clusterRadius: 20
                });
            }

            if (!map.getLayer('firemed')) {
                map.addLayer({
                    id: 'firemed',
                    type: 'symbol',
                    source: 'firemed',
                    minzoom: config.firemedZoomLevel,
                    layout: {
                        'icon-image': ['get', 'type'],
                        'icon-size': 0.22,
                        visibility: 'visible'
                    }
                });

                map.on('mouseenter', 'firemed', () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', 'firemed', () => {
                    map.getCanvas().style.cursor = 'auto';
                });
            }
        }
    }
}

class Wildfires {
    constructor() {
        this.store = localStorage.getItem('mapofire.clicks');
        this.ArcGISFeatureSource = window[""]["arcgis-featureserver"];
        this.agencies = {
            'US Forest Service': 'USFS',
            'Bureau of Land Management': 'BLM',
            'Bureau of Indian Affairs': 'BIA',
            'National Park Service': 'NPS',
            'Bureau of Reclamation': 'BOR',
            'US Fish & Wildlife Service': 'USFWS',
            'Oregon Department of Forestry': 'ODF',
            'Department of Natural Resources': 'DNR',
            'Idaho Department of Lands': 'IDL',
            'California Department of Forestry & Fire Protection': 'CAL FIRE',
            'California Department of Forestry and Fire Protection': 'CAL FIRE'
        };
        this.REGION_BBOX = {
            ca: [-141.0, 41.7, -52.6, 83.1],        // Canada approx
            aus: [112.0, -44.0, 154.0, -10.0]       // Australia approx
        }
    }

    fireTextSize(t, which) {
        const thresh = t === 'new' ? 100 : 1000;
        const isBig = [
            'all',
            ['>=', ['to-number', ['coalesce', ['get', 'acres'], 0]], thresh],
            ['!', ['has', 'Out']],
            ['!', ['has', 'Control']],
            ['!', ['has', 'Contain']]
        ];

        const config = {
            size: {
                z7: [isBig, 13, 11],
                z14: [isBig, 15, 12]
            },
            offset: {
                z7: [isBig, ['literal', [0, 1.2]], ['literal', [0, 1.0]]],
                z14: [isBig, ['literal', [0, 1.3]], ['literal', [0, 1.0]]]
            }
        }[which];

        return [
            'interpolate', ['linear'], ['zoom'],
            7, ['case', ...config.z7],
            14, ['case', ...config.z14]
        ];
    }

    fireIcon(t) {
        const now = Date.now() / 1000,
            acres = ['to-number', ['coalesce', ['get', 'acres'], 0]],
            discovered = ['to-number', ['coalesce', ['get', 'discovered', ['get', 'time']], now]],
            baseCase = ['==', ['get', 'type'], 'Complex'],
            statusChecks = [
                ['has', 'Out'], 'fire-icon-out',
                ['has', 'Contain'], 'fire-icon-contained',
                ['has', 'Control'], 'fire-icon-controlled'
            ],
            complexIcon = 'fire-icon-complex';

        if (t === 'rx') return 'fire-icon-rx';
        if (t === 'smk') return 'fire-icon-smoke';
        if (t === 'new') {
            return [
                'case',
                baseCase, complexIcon,
                ...statusChecks,
                [
                    'all',
                    ['<', ['-', now, discovered], 43200],
                    ['>=', acres, 100]
                ],
                'fire-icon-new-big',
                'fire-icon-new'
            ];
        }

        return [
            'case',
            baseCase, complexIcon,
            [
                'all',
                ['has', 'time'],
                ['<', ['to-number', ['coalesce', ['get', 'year', ['get', 'time']], 9999]], config.curTime.getFullYear()]
            ],
            'fire-icon-out',
            ...statusChecks,
            ['>=', acres, 1000], 'fire-icon-large',
            ['>=', acres, 100], 'fire-icon-big',
            'fire-icon'
        ];
    }

    async commitLog() {
        if (this.store != null && this.store != '') {
            const send = await api(config.apiURL + 'logFire', [['data', this.store]]);

            if (send.success) {
                clicks = [];
                localStorage.removeItem('mapofire.clicks');
            }
        }

        return this;
    }

    logFire(id, json) {
        const item = clicks.find(e => e.wfid == id);

        if (item) {
            item.count++;
            item.data = json;
        } else {
            clicks.push({ wfid: id, count: 1, data: json });
        }

        localStorage.setItem('mapofire.clicks', JSON.stringify(clicks));
        return this;
    }

    getStatus(s, n, t = 'Wildfire', ac = '0') {
        let a = ac.toString().toLowerCase();
        if (!s && !n) return 'active';

        if (s) {
            if (s.Out) return 'out';
            if (s.Control) return 'controlled';
            if (s.Contain) return 'contained';
            if (Object.keys(s).length > 0) return '';
        }

        const notes = n?.toLowerCase() || '';
        if (notes.includes('contain')) return 'contained';
        if (notes.includes('control')) return 'controlled';

        if (t == 'Smoke Check' && (a == '0' || a == 'unknown' || a == '')) {
            return 'unknown';
        }

        return 'active';
    }

    getDispatchCenter(c) {
        var r = null;

        dispatchCenters.forEach(function (d) {
            if (c == d.agency || c == d.agency.replace('-', '')) {
                r = d;
            }
        });

        return r;
    }

    largestGrowthTime(it) {
        const date = new Date(it * 1000);
        const now = new Date();

        const getMidnight = (d) => {
            d.setHours(0, 0, 0, 0);
            return d;
        };

        const today = getMidnight(new Date(now));
        const yesterday = getMidnight(new Date(now));
        yesterday.setDate(yesterday.getDate() - 1);

        const startOfWeek = getMidnight(new Date(now));
        const day = startOfWeek.getDay();
        const diff = startOfWeek.getDate() - day + (day === 0 ? -6 : 1);
        startOfWeek.setDate(diff);

        if (date >= today) {
            return "today";
        } else if (date >= yesterday) {
            return "yesterday";
        } else if (date >= startOfWeek) {
            const weekdayFormatter = new Intl.DateTimeFormat('en-US', { weekday: 'long' });
            return `on ${weekdayFormatter.format(date)}`;
        } else {
            const dateFormatter = new Intl.DateTimeFormat('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
            return `on ${dateFormatter.format(date)}`;
        }
    }

    fireStats(history, incID = null) {
        if (history.length < 2) return null;

        const year = Number(incID?.split('-')[0] ?? config.curTime.getFullYear()),
            last = history[0],
            first = history[history.length - 1],
            curAcres = parseFloat(first.acres),
            firstAcres = parseFloat(last.acres),
            totalMinutes = Math.round(Math.abs((first.updated - last.updated) / 60))/*,
            days = totalMinutes / 60 / 24*/;

        let changes = [];
        let totalAcres = 0, totalTimeDiff = 0;

        // Compute consecutive changes
        for (let i = 0; i < history.length - 1; i++) {
            const change = parseFloat(history[i + 1].acres) - parseFloat(history[i].acres);
            changes.push(change);
            totalAcres += change;
            totalTimeDiff += history[i + 1].updated - history[i].updated;
        }

        const diff = curAcres - firstAcres,
            overall = conversion.sizeFormat(diff);

        // Average growth per day/hour
        let avgValue, growthUnit, growthSum = 0, growthTime = 0;

        for (let i = 0; i < history.length - 1; i++) {
            const change = parseFloat(history[i + 1].acres) - parseFloat(history[i].acres);
            if (change > 0) {
                growthSum += change;
                growthTime += (history[i + 1].updated - history[i].updated); // in seconds
            }
        }

        if (growthTime === 0) {
            avgValue = 0;
            growthUnit = "day"; // default
        } else {
            const growthHours = growthTime / 3600;
            const growthDays = growthHours / 24;

            if (growthDays > 2) {
                avgValue = growthSum / growthDays;
                growthUnit = "day";
            } else {
                avgValue = growthSum / growthHours;
                growthUnit = "hour";
            }
        }

        // Duration string
        let duration;
        if (totalMinutes >= 40320) {
            const w = Math.floor(totalMinutes / 10080);
            duration = `${w} week${w !== 1 ? 's' : ''}`;
        } else if (totalMinutes >= 1440) {
            const d = Math.floor(totalMinutes / 1440);
            duration = `${d} day${d !== 1 ? 's' : ''}`;
        } else if (totalMinutes >= 60) {
            const h = Math.floor(totalMinutes / 60);
            duration = `${h} hour${h !== 1 ? 's' : ''}`;
        } else {
            duration = `${totalMinutes} minute${totalMinutes !== 1 ? 's' : ''}`;
        }

        // Largest positive growth only
        const positiveChanges = changes.filter(c => c > 0);
        const maxGrowth = positiveChanges.length ? Math.max(...positiveChanges) : 0;
        const whenGrew = maxGrowth ? this.largestGrowthTime(history[changes.indexOf(maxGrowth) + 1].updated) : '';

        let statSentence;
        if (diff > 0) {
            const isCurrentYear = year === config.curTime.getFullYear();
            statSentence = `Over ${duration}${!isCurrentYear ? ` in ${year}` : ''}, this fire grew ${isCurrentYear ? 'by' : 'to'} ${overall}, averaging ${conversion.sizeFormat(avgValue)} of growth per ${growthUnit} (when active).`;
        } else {
            statSentence = `Incident reporting has decreased this fire in size by ${Math.abs(diff).toFixed(2).replace(/\.?0+$/, '')} acres.`;
        }

        return `${statSentence} The largest single growth was ${conversion.sizeFormat(maxGrowth)} ${whenGrew}.`;
    }

    createChart(fireName, incID, hist) {
        if (hist.length <= 1) {
            document.querySelector('#acres_history').parentElement.parentElement.remove();
        } else {
            let lastTs = null;

            // reverse data to show oldest to newest
            hist.sort((a, b) => a.updated - b.updated);

            const data = hist.map((h) => {
                let ts = h.updated * 1000;

                if (ts === lastTs) ts += 1;

                lastTs = ts;
                return [ts, h.acres];
            });

            const fireStats = this.fireStats(hist, incID),
                gridColor = '#212d42',
                fmt = { year: 'numeric', month: 'long', day: 'numeric' },
                date1 = Intl.DateTimeFormat('en-US', fmt).format(data[0][0]),
                date2 = Intl.DateTimeFormat('en-US', fmt).format(data[data.length - 1][0]),
                dates = date1 == date2 ? ' on ' + date1 : ' from ' + date1 + ' to ' + date2;

            Highcharts.setOptions({
                time: {
                    timezone: 'America/Los_Angeles'
                }
            });

            chart = Highcharts.chart('acres_history', {
                chart: {
                    type: 'line',
                    style: {
                        fontFamily: 'Roboto'
                    },
                    marginTop: 50,
                    backgroundColor: 'transparent'
                },
                accessibility: {
                    enabled: false
                },
                title: {
                    text: null
                },
                legend: {
                    itemStyle: {
                        color: '#f1f1f1'
                    }
                },
                /*events: {
                    render() {
                        document.querySelector('#acres_history').style.backgroundColor = 'transparent';
                    }
                },*/
                subtitle: {
                    text: '<b>' + fireName + ' (' + incID + ') growth history ' + dates + '.</b>',
                    useHTML: true,
                    verticalAlign: 'bottom',
                    align: 'left',
                    style: {
                        color: '#f1f1f1'
                    }
                },
                navigation: {
                    buttonOptions: {
                        enabled: true
                    }
                },
                tooltip: {
                    xDateFormat: '%a, %b %e, %Y %l:%M %p',
                    shared: true
                },
                xAxis: {
                    type: 'datetime',
                    lineColor: gridColor,
                    tickColor: gridColor,
                    gridLineColor: gridColor,
                    gridLineWidth: 1,
                    labels: {
                        style: {
                            color: '#f1f1f1'
                        },
                        format: '{value:%b %e}'
                    }
                },
                yAxis: [{
                    lineWidth: 1,
                    lineColor: gridColor,
                    gridLineColor: gridColor,
                    gridLineWidth: 1,
                    title: {
                        text: 'Total Acres',
                        style: {
                            color: '#f1f1f1'
                        }
                    },
                    labels: {
                        style: {
                            color: '#fff'
                        }
                    },
                    min: 0
                }],
                series: [{
                    name: 'Total Acres',
                    type: 'line',
                    data: data
                }],
                panning: true,
                panKey: 'ctrl',
                zooming: {
                    type: 'xy'
                },
                exporting: {
                    buttons: {
                        contextButton: {
                            symbolStroke: '#eee',
                            theme: {
                                fill: 'transparent',
                                states: {
                                    hover: {
                                        fill: '#223260'
                                    },
                                    select: {
                                        fill: '#223260'
                                    }
                                }
                            }
                        }
                    }
                },
                plotOptions: {
                    series: {
                        marker: {
                            symbol: 'circle',
                            fillColor: '#fff',
                            enabled: true,
                            radius: 3,
                            lineWidth: 1,
                            lineColor: null
                        }
                    }
                },
                responsive: {
                    rules: [{
                        condition: {
                            maxWidth: 600
                        },
                        chartOptions: {
                            yAxis: {
                                title: {
                                    text: ''
                                }
                            }
                        }
                    }]
                },
                colors: ['#e41616', '#ffd54f']
            });

            if (fireStats != null) {
                const p = document.createElement('p');
                p.classList.add('fireStats');
                p.innerHTML = `<i class="far fa-chart-line-up"></i><span>${fireStats}</span>`;
                document.querySelector('#acres_history').parentElement.appendChild(p);
            }
        }

        return this;
    }

    findFire(id) {
        return activeIncidents.get(parseInt(id)) ?? null;
    }

    async getTrackedFires() {
        if (settings.user) {
            const g = await api(config.host + 'api/v1/trackFires/list', [['token', settings.getUser().token()]]);

            trackedDone = true;

            if (g.fires != null) {
                g.fires.forEach(function (f) {
                    tracked.push(f.wfid);
                });
            }
        } else {
            const tr = localStorage.getItem('mapofire.tracked');
            trackedDone = true;

            if (tr != null) {
                tracked = JSON.parse(tr);
            }
        }

        /* if modal is already open with wildfire data, change the follow button now */
        if (document.querySelector('#modal').classList.contains('opened', 'fire')) {
            const tf = document.querySelector('#trackFire');

            if (tf && tracked.includes(tf.dataset.id)) {
                tf.setAttribute('data-following', '1');
                tf.setAttribute('title', 'You\'re following this fire');
                tf.classList.add('fas', 'follow');
                tf.classList.remove('far');
            }
        }

        return this;
    }

    async getBushfireNames() {
        const data = await api('https://services-ap1.arcgis.com/ypkPEy1AmwPKGNNv/arcgis/rest/services/Near_Real_Time_Bushfire_Boundaries_view/FeatureServer/3/query', [
            ['where', '1=1 AND fire_name IS NOT NULL'],
            ['outFields', 'fire_id,fire_name,state,area_ha,ignition_date'],
            ['returnGeometry', false],
            ['returnCentroid', true],
            ['f', 'json']
        ]);

        if (!data || !data?.features?.length) return null;

        data.features.forEach(fire => {
            const discover = Math.round(fire.attributes.ignition_date / 1000),
                json = {
                    isAustralia: true,
                    geometry: { type: 'Point', coordinates: [fire.centroid.x, fire.centroid.y] },
                    properties: {
                        wfid: fire.attributes.fire_id,
                        name: fire.attributes.fire_name,
                        state: fire.attributes.state == 'WA' ? 'WAA' : (fire.attributes.state == 'NT' ? 'NTT' : fire.attributes.state),
                        type: 'Bushfire',
                        status: 'active',
                        acres: fire.attributes.area_ha * 2.471,
                        time: { year: new Date(discover * 1000).getFullYear(), discovered: discover }
                    }
                };
            activeIncidents.set(parseInt(fire.attributes.fire_id, 10), json);
        });
    }

    async canada() {
        const statuses = ['Out of control', 'Being held', 'Under Control', 'Out'],
            now = new Date().getTime() / 1000,
            fires = await api(config.apiURL + 'wildfires/canada');

        if (fires != null && fires.features != null) {
            fires.features.forEach((f, n) => {
                statuses.forEach((stats) => {
                    if (f.properties.status && f.properties.status.search(stats) >= 0) {
                        fires['features'][n]['properties'][stats] = true;
                    }
                });

                activeIncidents.set(parseInt(f.properties.wfid, 10), f);
            });
        }

        if (!map.getSource('ca_fires')) {
            map.addSource('ca_fires', {
                type: 'geojson',
                data: fires,
                cluster: CLUSTER_FIRES,
                clusterMaxZoom: window.innerWidth < 600 || window.outerWidth < 600 ? 6 : 7,
                clusterMinPoints: 20,
                clusterRadius: 50
            });
        }

        const chk = setInterval(() => {
            if (map.isSourceLoaded('ca_fires')) {
                const vis = settings.isEnabled('allFires') ? 'visible' : 'none';

                clearInterval(chk);

                if (!map.getLayer('ca_fires')) {
                    map.addLayer({
                        id: 'ca_fires',
                        type: 'symbol',
                        source: 'ca_fires',
                        layout: {
                            'icon-image': [
                                'case',
                                [
                                    '<',
                                    ['-', now, ['to-number', ['get', 'discovered', ['get', 'time']]]],
                                    ['to-number', (12 * 60 * 60)]
                                ],
                                [
                                    'case',
                                    [
                                        '>=',
                                        ['to-number', ['get', 'acres']],
                                        100
                                    ],
                                    'fire-icon-new-big',
                                    'fire-icon-new'
                                ],
                                ['has', 'Out of control'],
                                'fire-icon',
                                ['has', 'Under Control'],
                                'fire-icon-controlled',
                                ['has', 'Begin held'],
                                'fire-icon-contained',
                                ['has', 'Out'],
                                'fire-icon-out',
                                [
                                    '>=',
                                    ['to-number', ['get', 'acres']],
                                    1000
                                ],
                                'fire-icon-large',
                                [
                                    '>=',
                                    ['to-number', ['get', 'acres']],
                                    100
                                ],
                                'fire-icon-big',
                                'fire-icon'
                            ],
                            'icon-size': [
                                'case',
                                ['has', 'Out'],
                                0.3,
                                0.4
                            ],
                            'icon-allow-overlap': true,
                            visibility: vis
                        }
                    });

                    map.on('mouseenter', 'ca_fires', () => {
                        map.getCanvas().style.cursor = 'pointer';
                    });

                    map.on('mouseleave', 'ca_fires', () => {
                        map.getCanvas().style.cursor = 'auto';
                    });
                }

                if (!map.getLayer('ca_fire_title')) {
                    map.addLayer({
                        id: 'ca_fire_title',
                        type: 'symbol',
                        source: 'ca_fires',
                        minzoom: window.innerWidth < 600 || window.outerWidth < 600 ? 5 : 6,
                        paint: {
                            'text-color': '#000',
                            'text-halo-color': '#fff',
                            'text-halo-blur': 1,
                            'text-halo-width': 2,
                            'text-opacity': [
                                'step',
                                ['zoom'],
                                [
                                    'case',
                                    ['>', ['to-number', ['get', 'acres']], 1000],
                                    1.0,
                                    0.0
                                ],
                                9,
                                1.0
                            ]
                        },
                        layout: {
                            'symbol-placement': 'point',
                            'symbol-spacing': 150,
                            'text-font': config.fonts.source(),
                            'text-field': [
                                'case',
                                [
                                    '==',
                                    ['get', 'type'],
                                    'Wildfire'
                                ],
                                ['concat', ['get', 'name'], ' Fire'],
                                ['get', 'name']
                            ],
                            'text-justify': 'center',
                            'text-size': [
                                'interpolate',
                                ['linear'],
                                ['zoom'],
                                7,
                                [
                                    'case',
                                    ['>', ['to-number', ['get', 'acres']], 1000],
                                    12,
                                    10
                                ],
                                14,
                                [
                                    'case',
                                    ['>', ['to-number', ['get', 'acres']], 1000],
                                    15,
                                    13
                                ]
                            ],
                            'text-max-width': 10,
                            'text-anchor': 'top',
                            'text-offset': [
                                'case',
                                ['>', ['to-number', ['get', 'acres']], 1000],
                                [0, 1.3],
                                [0, 1]
                            ],
                            'text-allow-overlap': false,
                            'text-letter-spacing': 0.05,
                            visibility: vis
                        }
                    });

                    map.on('mouseenter', 'ca_fire_title', () => {
                        map.getCanvas().style.cursor = 'pointer';
                    });

                    map.on('mouseleave', 'ca_fire_title', () => {
                        map.getCanvas().style.cursor = 'auto';
                    });
                }
            }
        }, 500);

        return this;
    }

    /* get wildfires from API */
    async getWildfires(update = false) {
        const types = ['all', 'new', 'smk', 'rx'],
            qInput = document.querySelector('#q');

        const processFires = (fires, type) => {
            if (!fires?.features) return;

            fires.features.forEach(f => {
                const p = f.properties;

                ['Out', 'Contain', 'Control'].forEach(status => {
                    if (p.status[status]) p[status] = true;
                });

                p.name = config.wildfire.fireName(p.name, p.type, p.incidentId);
                activeIncidents.set(parseInt(p.wfid, 10), f);

                if (type === 'new' && p.acres >= 100) newFires.push(f);
            });

            const sourceId = `${type}_fires`,
                source = map.getSource(sourceId);

            if (update) {
                source.setData(fires);
            } else {
                if (!source) {
                    map.addSource(sourceId, {
                        type: 'geojson',
                        data: fires,
                        cluster: CLUSTER_FIRES,
                        clusterMaxZoom: type === 'all' ? (window.innerWidth < 600 ? 6 : 7) : 8,
                        clusterMinPoints: type === 'all' ? 20 : 5,
                        clusterRadius: type === 'all' ? 50 : 20
                    });
                }
            }
        };

        if (settings.archive) {
            const fires = await api(`${config.apiURL}wildfires/all`, [['archive', settings.archive], ['bbox', getbbox()]]);

            processFires(fires, 'all');
            this.displayFires('all', 0);
        } else {
            this.canada();

            await Promise.all(types.map(async (type, i) => {
                const fires = await api(`${config.apiURL}wildfires/${type}`);
                processFires(fires, type);

                if (type === 'new' && newFires.length > 0) {
                    this.renderNewFiresUI(newFires.length);
                }

                // Wait for source load before displaying
                const poll = setInterval(() => {
                    if (map.isSourceLoaded(`${type}_fires`)) {
                        this.displayFires(type, i);
                        clearInterval(poll);
                    }
                }, 500);
            }));
        }

        if (qInput) qInput.disabled = false;
        return this;
    }

    renderNewFiresUI(count) {
        const nf = document.querySelector('nav #new_fires');

        nf.dataset.action = 'new_fires';
        nf.title = 'New Fires';
        nf.style.display = 'inline-flex';

        const nfCount = document.createElement('div');
        nfCount.className = `notify${count > 9 ? ' m10' : ''}`;
        nfCount.innerHTML = count;
        nf.appendChild(nfCount);
    }

    // display wildfires on the map
    async displayFires(type, n) {
        const lay = ['allFires', 'newFires', 'smokeChecks', 'rxBurns'],
            fireLayerName = type + '_fires',
            vis = settings.isEnabled(lay[n]) || !settings.checkboxes() && type != 'rx' ? 'visible' : 'none';

        /* add fires to map */
        if (map.getSource(fireLayerName)) {
            if (!map.getLayer(fireLayerName)) {
                map.addLayer({
                    id: fireLayerName,
                    type: 'symbol',
                    source: fireLayerName,
                    layout: {
                        'icon-image': this.fireIcon(type),
                        'icon-size': [
                            'case',
                            ['has', 'Out'],
                            0.3,
                            0.4
                        ],
                        'icon-allow-overlap': true,
                        visibility: vis
                    }
                });

                map.on('mouseenter', fireLayerName, () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', fireLayerName, () => {
                    map.getCanvas().style.cursor = 'auto';
                });
            }

            if (!map.getLayer(fireLayerName + '_title')) {
                map.addLayer({
                    id: fireLayerName + '_title',
                    type: 'symbol',
                    source: fireLayerName,
                    minzoom: window.innerWidth < 600 || window.outerWidth < 600 ? 4 : 5,
                    paint: {
                        'text-color': '#000',
                        'text-halo-color': '#fff',
                        'text-halo-blur': 1,
                        'text-halo-width': 2,
                        'text-opacity': [
                            'step',
                            ['zoom'],
                            [
                                'case',
                                ['>', ['to-number', ['get', 'acres']], 1000],
                                1.0,
                                0.0
                            ],
                            9,
                            1.0
                        ]
                    },
                    layout: {
                        'symbol-placement': 'point',
                        'symbol-spacing': 150,
                        'text-font': config.fonts.source(),
                        'text-field': ['get', 'name'],
                        'text-justify': 'center',
                        'text-size': this.fireTextSize(type, 'size'),
                        'text-max-width': 10,
                        'text-anchor': 'top',
                        'text-offset': this.fireTextSize(type, 'offset'),
                        'text-allow-overlap': true,
                        'text-letter-spacing': 0.05,
                        visibility: vis
                    }
                });

                map.on('mouseenter', fireLayerName + '_fire', () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', fireLayerName + '_fire', () => {
                    map.getCanvas().style.cursor = 'auto';
                });
            }
        }

        if (type == 'rx' && map.getSource('perimeters')) {
            map.moveLayer('perimeters_fill', 'all_fires');
            map.moveLayer('perimeters_outline', 'all_fires');
            map.moveLayer('perimeters_title', 'all_fires');
        }

        return this;
    }

    getAssociatedPerim(fireName) {
        if (!settings.isEnabled('perimeters')) return;

        const src = map.getSource('perimeters')._data.geojson.features,
            wait = setInterval(() => {
                if (src) {
                    const name = fireName.replace(/\s/gm, '').toLowerCase();
                    clearInterval(wait);

                    const results = src.filter(feat => {
                        const p = feat.properties;

                        return p.attr_IncidentName.replace(/\s/gm, '').toLowerCase() == name ||
                            p.poly_IncidentName.replace(/\s/gm, '').toLowerCase() == name;
                    });

                    console.log(results);
                }
            }, 200);
    }

    doWeather(geo) {
        let wx = new Weather(geo[1], geo[0]);

        wx.incidentWX();
        wx.incidentForecast();
        /*wx.nearbyAQ();*/
    }

    fireName(n, t, i) {
        let o = '';

        if (t == 'Prescribed Fire') {
            o = (n.toLowerCase().includes('rx') ? n : n + ' RX');
        } else if (t == 'Smoke Check') {
            o = 'Smoke Check' + (i !== undefined ? ' #' + i.split('-')[1] + '-' + parseInt(i.split('-')[2]) : '');
        } else {
            if (n === undefined || n == '') {
                o = 'Incident #' + parseInt(i.split('-')[2]);
            } else {
                const cleanedName = n.replace(/^\d+(?=\D)\s?/, '');
                o = ucwords(cleanedName.toLowerCase()) + ' Fire';
            }
        }
        return o;
    }

    async cacheIncident(wfid) {
        const cache = await caches.open('mapofire-v' + version);

        try {
            // if user has in-app caching enabled
            if (settings.fire().cache()) {
                const cachedResponse = await cache.match(wfid);

                if (cachedResponse) {
                    const cachedData = await cachedResponse.json();

                    if (Date.now() - cachedData.timestamp < (10 * 60 * 1000)) {
                        return cachedData.data;
                    } else {
                        cache.delete(wfid);
                    }
                }
            }

            const data = await api(config.apiURL + 'wildfires/incident', [['wfid', wfid], ['history', 1]]);

            // if user has in-app caching enabled
            if (settings.fire().cache()) {
                await cache.put(wfid, new Response(JSON.stringify({ data: data, timestamp: Date.now() })));
            }

            return data;
        } catch (error) {
            console.error(error);
            return null;
        }
    }

    geoLocate(agency, type, fire) {
        let land = '';
        if (agency.logo == 'usfs') land = ` (${agency.area})`;

        return `<b>${type.toUpperCase()}</b> in ${fire.geometry.geo.county} County, ${fire.geometry.state}${land}`;
    }

    async incident(wfid, zoomIn = true) {
        const TWO_MONTHS = 60 * 60 * 24 * (config.daysInYear() / 6);

        //modal.addEventListener('modalOpened', () => {
        if (zoomIn) {
            const coords = this.findFire(wfid);
            if (coords) {
                map.easeTo({
                    zoom: 10,
                    center: coords.geometry.coordinates,
                    duration: 1500,
                    easing: t => t * (2 - t),
                    essential: true
                });
            }
        }
        //});

        new ClickListener().openModal('fire');

        // get incident json from cache or API
        const incident = await this.cacheIncident(wfid),
            fire = incident.fire,
            fireLat = fire.geometry.lat,
            fireLon = fire.geometry.lon,
            prop = fire.properties,
            nearbyEvacs = await new NearbyEvacuations(fireLat, fireLon).get(),
            fname = this.fireName(prop.fireName, prop.type, prop.incidentId),
            near = fire.geometry.near,
            acresHistory = prop.acres_history/*,
            nearbyPerims = this.getAssociatedPerim(prop.fireName)*/;

        // change the URL in the browser
        setHeaders(fname + ' near ' + near.split(' of ')[1] + ' - Current Incident Information and Wildfire Map', prop.url,
            'See current information on the ' + fname + ' near ' + near.split(' of ')[1] + '.');

        if (fire.inciweb && fire.inciweb.photo) {
            document.querySelector('meta[property="og:image"]').setAttribute('content', `https://www.mapofire.com/src/images/incident?path=${fire.inciweb.photo.url}`);
            document.querySelector('meta[name="twitter:image"]').setAttribute('content', `https://www.mapofire.com/src/images/incident?path=${fire.inciweb.photo.url}`);
        }

        if (fire.inciweb && fire.inciweb.photo) {
            document.querySelector('meta[property="og:image:alt"]').setAttribute('content', fire.inciweb.photo.caption);
        }

        // send data to service worker
        config.workers.incident.postMessage({
            fire: {
                json: incident,
                fireName: fname,
                geoLocate: this.geoLocate(fire.protection, prop.type, fire),
                status: this.getStatus(prop.status, prop.notes, prop.type, prop.acres)
            },
            role: settings.getUser().role(),
            hasPermissions: settings.hasPermissions(),
            vars: {
                domain: config.domain,
                center: this.getDispatchCenter(fire.protection.dispatch),
                agencies: this.agencies,
                tracked: tracked,
                acres: conversion.sizeFormat(prop.acres, true, false),
                sizeUnit: conversion.sizeUnit(),
                reported: {
                    ago: timeAgo(fire.time.discovered),
                    useAgo: (Date.now() / 1000) - fire.time.discovered < 60 * 60 * 6
                },
                updated: config.curTime.getTime() - fire.time.updated * 1000 > TWO_MONTHS ? dateTime(fire.time.updated, true) : timeAgo(fire.time.updated)
            }
        });

        /* add content to modal after service worker finishes */
        config.workers.incident.onmessage = (event) => {
            modal.querySelector('.content').innerHTML = event.data;

            const acHis = modal.querySelector('#acres_history'),
                scrd = modal.querySelector('span.coords');

            /* if nearby evacuations exist, show them on the modal */
            if (nearbyEvacs) {
                let theEvacs = '';
                const formatArray = (arr) => {
                    if (arr.length === 2) {
                        return arr.join(' & ');
                    } else if (arr.length >= 3) {
                        const lastTwo = arr.slice(-2).join(' & '),
                            firstPart = arr.slice(0, -2);
                        return firstPart.join(', ') + ', ' + lastTwo;
                    } else if (arr.length === 1) {
                        return arr[0];
                    } else {
                        return '';
                    }
                };

                if (nearbyEvacs.length > 0) {
                    nearbyEvacs.reverse().forEach((z) => {
                        const nomen = (z.level == 1 ? 'Be Ready' : (z.level == 2 ? 'Be Set' : 'Leave Immediately'));

                        theEvacs += '<div class="evac level' + z.level + '"><h3><span class="evac-circ l' + z.level + '"></span>Level ' + z.level + ': ' + nomen + '</h3><details><summary>' +
                            formatArray(z.counties) + ' Count' + (z.counties.length == 1 ? 'y' : 'ies') +
                            '</summary><span style="font-size:15px">' + z.notes.join(', ') + '</span></details></div>';
                    });

                    document.querySelector('.incident #incWX').insertAdjacentHTML('beforebegin', '<div class="evacs">' + theEvacs + '</div>');
                }
            }

            /* get incident weather */
            this.doWeather([fireLon, fireLat]);

            /* remove any features that require a user to be subscribed */
            if (!settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM)) {
                acHis.style.height = 'unset';
                acHis.innerHTML = '<a href="#" data-action="marketing-cta" data-utm="acres_history" class="btn btn-orange btn-lg" onclick="return false"><i class="fas fa-lock"></i>Upgrade to see growth history</a>';
                /*document.querySelector('#acres_history').parentElement.parentElement.remove();*/

                /* blur coordinates */
                scrd.innerHTML = '0.0000 -0.0000';
                scrd.style.cursor = 'default';
                scrd.classList.add('blur');
            } else {
                scrd.style.cursor = 'pointer';

                /* load the script for the chart, then create the acreage chart */
                if (acresHistory != null) {
                    const c = this;

                    if (!highchartsLoad) {
                        loadScript('https://code.highcharts.com/highcharts.js')
                            .then(() => {
                                highchartsLoad = true;

                                loadScript('https://code.highcharts.com/modules/exporting.js').then(() => {
                                    c.createChart(fname, prop.incidentId, acresHistory);
                                });
                            });
                    } else {
                        c.createChart(fname, prop.incidentId, acresHistory);
                    }
                } else {
                    modal.querySelector('#acres_history_wrapper').remove();
                }
            }
        };

        return this;
    }

    perimeterColor(c) {
        let pc;

        switch (c) {
            case 'default':
            case 'red':
                pc = '#f35a5a';
                break;
            case 'blue':
                pc = '#3289d5';
                break;
            case 'orange':
                pc = '#fb8c00';
                break;
            case 'green':
                pc = '#388e3c';
                break;
            case 'purple':
                pc = '#9c27b0';
                break;
            case 'brown':
                pc = '#795548';
                break;
            case 'black':
                pc = '#333';
                break;
        }

        return settings.archive == null ? ['case', ['!=', ['to-string', ['to-number', ['get', 'attr_ContainmentDateTime']]], '0'], '#777', pc] : '#777';
    }

    async intlPerimeters(update = false) {
        const vis = !settings.user || !settings.checkboxes() || settings.isEnabled('perimeters') ? 'visible' : 'none',
            min = settings.perimeters().minSize() / 2.471,    // convert to hectres for the metric countries
            pc = this.perimeterColor(settings.perimeters().color()),
            b = map.getBounds(),
            viewBBox = [b.getWest(), b.getSouth(), b.getEast(), b.getNorth()],
            intersects = (view, region) => {
                return !(view[2] < region[0] || view[0] > region[2] || view[3] < region[1] || view[1] > region[3]);
            },
            loadPerimeter = async ({ id, url, where }) => {
                const src = `${id}_perimeters`,
                    outline = `${id}_perimeters_outline`,
                    fill = `${id}_perimeters_fill`;

                // the map isn't over Canada or Australia so there's no need to fetch perimeters for those areas
                if (!intersects(viewBBox, this.REGION_BBOX[id])) return null;

                if (!map.getSource(src)) {
                    new this.ArcGISFeatureSource(src, map, {
                        url: url,
                        precision: 6,
                        where: where,
                        outFields: '*'
                    });
                }
                /*const data = await api(url, [
                    ['where', where],
                    ['outFields', '*'],
                    ['resultType', 'tile'],
                    ['geometry', getbbox()],
                    ['geometryPrecision', 6],
                    ['geometryType', 'esriGeometryEnvelope'],
                    ['spatialRel', 'esriSpatialRelIntersects'],
                    ['returnGeometry', true],
                    ['f', 'geojson']
                ]);

                if (update && map.getSource(src)) {
                    map.getSource(src).setData(data);
                    return;
                }

                if (!map.getSource(src)) {
                    map.addSource(src, { type: 'geojson', data });
                }*/

                if (!map.getLayer(outline)) {
                    map.addLayer({
                        id: outline,
                        type: 'line',
                        source: src,
                        paint: {
                            'line-width': [
                                'case',
                                ['boolean', ['feature-state', 'click'], false],
                                3,
                                1
                            ],
                            'line-color': pc
                        },
                        layout: { visibility: vis }
                    });
                }

                if (!map.getLayer(fill)) {
                    map.addLayer({
                        id: fill,
                        type: 'fill',
                        source: src,
                        paint: {
                            'fill-opacity': 0.3,
                            'fill-color': pc
                        },
                        layout: { visibility: vis }
                    });

                    map.on('mouseenter', fill, () => {
                        map.getCanvas().style.cursor = 'pointer';
                    });

                    map.on('mouseleave', fill, () => {
                        map.getCanvas().style.cursor = 'auto';
                    });
                }
            };

        await Promise.all([
            loadPerimeter({
                id: 'ca',
                url: 'https://services.arcgis.com/wjcPoefzjpzCgffS/ArcGIS/rest/services/Active_Wildfire_Perimeters_in_Canada_View/FeatureServer/0',
                where: '1=1 AND LASTDATE >= TIMESTAMP \'' + new Date().getFullYear() + '-01-01 00:00:00\' AND AREA >= ' + min
            }),
            loadPerimeter({
                id: 'aus',
                url: 'https://services-ap1.arcgis.com/ypkPEy1AmwPKGNNv/arcgis/rest/services/Near_Real_Time_Bushfire_Boundaries_view/FeatureServer/3',
                where: '1=1 AND fire_name IS NOT NULL AND area_ha >= ' + min
            })
        ]);

        return this;
    }

    async perimeters(update = false) {
        let vis = !settings.user || !settings.checkboxes() || settings.isEnabled('perimeters') ? 'visible' : 'none',
            y = (settings.archive ? settings.archive : config.curTime.getFullYear()),
            min = settings.perimeters().minSize(),
            pc = this.perimeterColor(settings.perimeters().color()),
            o = 'OBJECTID,attr_UniqueFireIdentifier,poly_IncidentName,attr_IncidentName,poly_DateCurrent,poly_GISAcres,poly_Acres_AutoCalc,poly_MapMethod,attr_POOState,attr_ContainmentDateTime,attr_FireOutDateTime',
            perimName = 'attr_IncidentName',
            w = `attr_FireDiscoveryDateTime>=TIMESTAMP '${y}-01-01 00:00:00'`;

        if (!settings.archive) {
            w += ' AND (poly_GISAcres > ' + min + ' OR poly_Acres_AutoCalc > ' + min + ') AND attr_FireOutDateTime IS NULL';
        }

        /* get Canada wildfire perimeters if not in archive mode */
        if (!settings.archive) {
            this.intlPerimeters(update);
        }

        if (!map.getSource('perimeters')) {
            new this.ArcGISFeatureSource('perimeters', map, {
                url: 'https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/WFIGS_Interagency_Perimeters/FeatureServer/0',
                precision: 6,
                where: w,
                outFields: o
            });
        }

        /*const data = await api('https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/WFIGS_Interagency_Perimeters/FeatureServer/0/query', [
            ['where', w],
            ['outFields', o],
            ['resultType', 'tile'],
            ['geometry', getbbox()],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['returnGeometry', true],
            ['f', 'geojson']
        ]);

        // when the map moves, update the source data
        if (update && map.getSource('perimeters')) {
            //map.getSource('perimeters').setData(data);
        } else {
            /*if (!map.getSource('perimeters')) {
                map.addSource('perimeters', {
                    type: 'geojson',
                    data: data
                });
            }*/

        if (!map.getLayer('perimeters_outline')) {
            map.addLayer({
                id: 'perimeters_outline',
                type: 'line',
                source: 'perimeters',
                paint: {
                    'line-width': [
                        'case',
                        ['boolean', ['feature-state', 'click'], false],
                        3,
                        1
                    ],
                    'line-color': pc
                },
                layout: {
                    visibility: vis
                }
            });
        }

        if (!map.getLayer('perimeters_fill')) {
            map.addLayer({
                id: 'perimeters_fill',
                type: 'fill',
                source: 'perimeters',
                paint: {
                    'fill-opacity': 0.3,
                    'fill-color': pc
                },
                layout: {
                    visibility: vis
                }
            });
        }

        if (!map.getLayer('perimeters_title')) {
            map.addLayer({
                id: 'perimeters_title',
                type: 'symbol',
                source: 'perimeters',
                minzoom: 5.8,
                paint: {
                    'text-color': settings.archive ? '#fff' : ['case', ['!=', ['to-string', ['to-number', ['get', 'attr_ContainmentDateTime']]], '0'], '#333', '#fff'],
                    'text-halo-color': settings.archive ? '#333' : ['case', ['!=', ['to-string', ['to-number', ['get', 'attr_ContainmentDateTime']]], '0'], '#fff', '#ff0000'],
                    'text-halo-blur': 1,
                    'text-halo-width': 1
                },
                layout: {
                    'symbol-placement': 'line',
                    'symbol-spacing': 200,
                    'text-font': config.fonts.din(),
                    'text-field': ['upcase', ['concat', ['get', perimName], ' Fire']],
                    'text-size': 13,
                    'text-max-angle': 30,
                    'text-padding': 5,
                    'text-pitch-alignment': 'viewport',
                    'text-rotation-alignment': 'map',
                    'text-offset': [0, 1],
                    visibility: vis
                }
            });

            map.on('mouseenter', 'perimeters_fill', () => {
                map.getCanvas().style.cursor = 'pointer';
            });

            map.on('mouseleave', 'perimeters_fill', () => {
                map.getCanvas().style.cursor = 'auto';
            });
        }
        //}

        return this;
    }
}

class NWS {
    async get(update = false) {
        const wwa = await api('https://services9.arcgis.com/RHVPKKiFTONKtxq3/ArcGIS/rest/services/NWS_Watches_Warnings_v1/FeatureServer/6/query', [
            ['where', '1=1'],
            ['outFields', 'OBJECTID,Event,Affected,End_'],
            ['returnGeometry', true],
            ['geometryPrecision', 6],
            ['geometryType', 'esriGeometryEnvelope'],
            ['spatialRel', 'esriSpatialRelIntersects'],
            ['geometry', getbbox()],
            ['f', 'geojson']
        ]);

        if (wwa && wwa.features.length > 0) {
            if (update) {
                map.getSource('wwas').setData(wwa);
            } else {
                if (wwa && wwa.features.length > 0) {
                    if (!map.getSource('wwas')) {
                        map.addSource('wwas', {
                            type: 'geojson',
                            data: wwa
                        });
                    }

                    if (!map.getLayer('wwas_outline')) {
                        map.addLayer({
                            id: 'wwas_outline',
                            type: 'line',
                            source: 'wwas',
                            paint: {
                                'line-color': wwaColors,
                                'line-width': 2
                            },
                            layout: {
                                visibility: 'visible'
                            }
                        });
                    }

                    if (!map.getLayer('wwas_fill')) {
                        map.addLayer({
                            id: 'wwas_fill',
                            type: 'fill',
                            source: 'wwas',
                            paint: {
                                'fill-color': wwaColors,
                                'fill-opacity': 0.35
                            },
                            layout: {
                                visibility: 'visible'
                            }
                        });

                        map.on('mouseenter', 'wwas_fill', () => {
                            map.getCanvas().style.cursor = 'pointer';
                        });

                        map.on('mouseleave', 'wwas_fill', () => {
                            map.getCanvas().style.cursor = 'auto';
                        });
                    }

                    if (!map.getLayer('wwas_title')) {
                        map.addLayer({
                            id: 'wwas_title',
                            type: 'symbol',
                            source: 'wwas',
                            minzoom: 8.9,
                            paint: {
                                'text-color': '#000',
                                'text-halo-color': '#fff',
                                'text-halo-blur': 1,
                                'text-halo-width': 1
                            },
                            layout: {
                                'symbol-placement': 'line',
                                'symbol-spacing': 450,
                                'text-font': config.fonts.din(),
                                'text-field': ['get', 'Event'],
                                'text-justify': 'auto',
                                'text-size': 14,
                                'text-max-width': 12,
                                'text-max-angle': 30,
                                'text-anchor': 'bottom',
                                'text-offset': [0, 1.3],
                                'text-letter-spacing': 0.05
                            }
                        });
                    }
                }
            }
        }
    }

    /* get current weather alerts at the lat/lon of the users' click point */
    async find(lat, lon) {
        let out = '<p>There are no valid weather alerts at this location</p>',
            popup = new Popup('').create('<div id="spinner" class="sm" style="display:block;text-align:center;margin:0 auto"></div>' +
                '<p style="text-align:center;margin-top:0.5em;font-size:14px">Getting weather alerts...</p>');

        /*new maplibregl.Popup()
            .setLngLat([lon, lat])
            .setHTML('<div id="spinner" class="sm" style="display:block;text-align:center;margin:0 auto"></div><p style="text-align:center;margin-top:0.5em">Getting weather alerts...</p>')
            .addTo(map);*/

        const data = await api(config.apiURL + 'nws', [['lat', lat], ['lon', lon]]);

        if (data.alerts && data.alerts.length > 0) {
            let c = '';

            data.alerts.forEach((a) => {
                c += '<li style="line-height:1.3"><a href="#" data-action="readWWA" onclick="return false" data-id="' + a.id + '">' + a.event + '</a> until ' + a.expires + '</li>';
            });

            /* update the popup with valid alerts */
            out = '<ul style="padding-inline-start:1em;display:inline-flex;flex-direction:column;gap:.5em">' + c + '</ul>';
        }

        popup.update(out, 'Current Alerts');
    }

    /* get SPC convective and fire weather outlooks */
    async spc(update = false) {
        let od = document.querySelector('#otlkDay'),
            ot = document.querySelector('#otlkType'),
            dy,
            ty;

        if (od) {
            dy = od.options[od.selectedIndex].value;
            ty = ot.options[ot.selectedIndex].value;
        } else {
            dy = settings.special().otlkDay();
            ty = settings.special().otlkType();
        }

        const out = await api(config.apiURL + 'outlooks/' + ty, [['day', (dy ? dy : 1)]]);

        if (update) {
            map.getSource('outlook').setData(out);
        } else {
            if (!map.getSource('outlook')) {
                map.addSource('outlook', {
                    type: 'geojson',
                    data: out
                });
            }

            if (!map.getLayer('outlook_fill')) {
                map.addLayer({
                    id: 'outlook_fill',
                    type: 'fill',
                    source: 'outlook',
                    paint: {
                        'fill-color': ['get', 'fill'],
                        'fill-opacity': 0.4
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });

                map.on('mouseenter', 'outlook_fill', () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', 'outlook_fill', () => {
                    map.getCanvas().style.cursor = 'auto';
                });
            }

            if (!map.getLayer('outlook_outline')) {
                map.addLayer({
                    id: 'outlook_outline',
                    type: 'line',
                    source: 'outlook',
                    paint: {
                        'line-color': ['get', 'stroke']
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }

            if (!map.getLayer('outlook_title')) {
                map.addLayer({
                    id: 'outlook_title',
                    type: 'symbol',
                    source: 'outlook',
                    minzoom: 5.7,
                    paint: {
                        'text-color': '#000',
                        'text-halo-color': '#fff',
                        'text-halo-blur': 1,
                        'text-halo-width': 1
                    },
                    layout: {
                        'symbol-placement': 'line',
                        'symbol-spacing': 450,
                        'text-font': config.fonts.din(),
                        'text-field': ['get', 'name'],
                        'text-justify': 'auto',
                        'text-size': 14,
                        'text-max-width': 12,
                        'text-max-angle': 30,
                        'text-anchor': 'bottom',
                        'text-offset': [0, 1.3],
                        'text-letter-spacing': 0.05
                    }
                });
            }
        }
    }

    fcstHour() {
        var h = config.curTime.getUTCHours(),
            m = config.curTime.getUTCMonth() + 1,
            m = (m < 10 ? '0' : '') + m,
            d = config.curTime.getUTCDate(),
            d = (d < 10 ? '0' : '') + d,
            t;

        if (h >= 19 && h <= 23 || h == 0) {
            t = '18';
        } else if (h >= 1 && h <= 6) {
            t = '00';
        } else if (h >= 7 && h <= 12) {
            t = '06';
        } else {
            t = '12';
        }

        return config.curTime.getUTCFullYear() + '-' + m + '-' + d + 'T' + t + ':00:00.000Z';
    }

    ndfd(update = false, tid) {
        let ur, leg, legend = document.querySelector('.ndfdLegend');
        const fcstMod = document.querySelector('#forecastModel'),
            fcstTime = document.querySelector('#fcstTime');

        let ft = settings.special().fcstTime(),
            fm = settings.special().forecastModel();

        if (Date.parse(ft) < new Date().getTime()) {
            ft = new Date(ndfdTime()).toISOString().replace(/:\d{2}\.\d{3}Z$/, ':00.000Z');
            if (fcstTime) [...fcstTime.options].forEach(o => o.selected = o.value === ft);
            settings.settings.special.fcstTime = ft;
        }

        /*if (fcstMod) {
            fm = fcstMod.options[fcstMod.selectedIndex].value;
            ft = fcstTime.options[fcstTime.selectedIndex].value;
        } else {
            fm = settings.special().forecastModel();
            ft = settings.special().fcstTime();
        }

        if (!ft) {
            ft = config.curTime.getUTCFullYear() + '-' + ((config.curTime.getUTCMonth() + 1) < 10 ? '0' : '') + (config.curTime.getUTCMonth() + 1) + '-' + (config.curTime.getUTCDate() < 10 ? '0' : '') + config.curTime.getUTCDate() + 'T' + ((config.curTime.getUTCHours() + 1) < 10 ? '0' : '') + (config.curTime.getUTCHours() + 1) + ':00:00.000Z';
        }*/

        const ops = {
            '12hr_precipitation_probability': ['ndfd_precipitation', 'forecasts/ndfd_precipitation/ows?layer=conus_12hr_precipitation_probability'],
            'relative_humidity': ['ndfd_moisture', 'forecasts/ndfd_moisture/ows?layer=conus_relative_humidity'],
            'wind_speed': ['ndfd_wind', 'forecasts/ndfd_wind/ows?layer=conus_wind_speed'],
            'total_sky_cover': ['ndfd_sky', 'forecasts/ndfd_sky/ows?layer=conus_total_sky_cover'],
            'air_temperature': ['ndfd_temperature', 'ndfd_temperature/ows?layer=conus_air_temperature']
        };

        if (ops[fm]) [ur, leg] = ops[fm];

        if (!legend) {
            const container = document.createElement('div');
            container.className = 'ndfdLegend';
            document.body.append(container);
        }

        if (tid != 'fcstTime') {
            document.querySelector('.ndfdLegend').innerHTML = `<img src="https://nowcoast.noaa.gov/geoserver/${leg}&service=WMS&version=1.3.0&request=GetLegendGraphic&format=image%2Fpng&width=283&height=33" alt="Legend">`;
        }

        if (update) {
            map.getSource('ndfd').setTiles([
                'https://nowcoast.noaa.gov/geoserver/' + ur + '/wms?service=WMS&layers=' + fm + '&request=GetMap&styles=&format=image/png&transparent=true&version=1.3.0&width=1920&height=626&time=' + ft + '&dim_time_reference=' + this.fcstHour() + '&crs=EPSG%3A3857&bbox={bbox-epsg-3857}'
            ]);
        } else {
            if (!map.getSource('ndfd')) {
                map.addSource('ndfd', {
                    'type': 'raster',
                    'tiles': [
                        'https://nowcoast.noaa.gov/geoserver/' + ur + '/wms?service=WMS&layers=' + fm + '&request=GetMap&styles=&format=image/png&transparent=true&version=1.3.0&width=1920&height=626&time=' + ft + '&dim_time_reference=' + this.fcstHour() + '&crs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                    ],
                    'tileSize': 256
                });
            }

            if (!map.getLayer('ndfd')) {
                map.addLayer({
                    id: 'ndfd',
                    type: 'raster',
                    source: 'ndfd',
                    paint: {
                        'raster-opacity': 0.75
                    },
                    layout: {
                        visibility: 'visible'
                    }
                });
            }
        }
    }

    satellite(w) {
        let layer;

        switch (w) {
            case 1: layer = 'global_visible_imagery_mosaic'; break;
            case 2: layer = 'global_longwave_imagery_mosaic'; break;
            case 3: layer = 'global_water_vapor_imagery_mosaic'; break;
        }

        if (!map.getSource('satellite' + w)) {
            map.addSource('satellite' + w, {
                'type': 'raster',
                'tiles': [
                    'https://nowcoast.noaa.gov/geoserver/satellite/wms?service=WMS&layers=' + layer + '&request=GetMap&styles=&format=image/png&transparent=true&version=1.3.0&width=256&height=256&crs=EPSG%3A3857&bbox={bbox-epsg-3857}'
                ],
                'tileSize': 256
            });
        }

        if (!map.getLayer('satellite' + w)) {
            map.addLayer({
                id: 'satellite' + w,
                type: 'raster',
                source: 'satellite' + w,
                paint: {
                    'raster-opacity': 0.7
                },
                layout: {
                    visibility: 'visible'
                }
            });
        }
    }

    async getOutlookText(otlkType, day, click = true) {
        if (!settings.hasPermissions(config.PERMISSION_LEVELS.PRO)) {
            unsetHeaders();
            return;
        }

        new ClickListener().openModal('wwa');
        const type = otlkType == 'severe' ? 'Convective Outlook' : 'Fire Weather Outlook';

        setHeaders('Day ' + day + ' ' + type, 'weather/outlook/' + otlkType + '/' + day,
            'Read the Day ' + day + ' ' + type + ' from the NWS Storm Prediction Center.');

        let graphics = '',
            request = await api(config.apiURL + 'outlooks/' + otlkType + '/text', [['day', day]]);

        if (!request) {
            new ClickListener().closeModal();
            notify('error', 'There was an error getting outlook text');
        }

        const valid1 = dateTime(request.outlook.valid, true, true),
            valid2 = dateTime(request.outlook.expires, true, true);

        setHeaders('Day ' + day + ' ' + type, 'weather/outlook/' + otlkType + '/' + day,
            'Read the Day ' + day + ' ' + type + ' from the NWS Storm Prediction Center for ' + valid1 + ' until ' + valid2 + '.');

        request.outlook.graphics.forEach((g) => {
            graphics += `<div class="g"><a target="blank" href="https://www.spc.noaa.gov/products/${g}"><img alt="Day ${day} ${type}" title="Day ${day} ${type}" src="https://www.spc.noaa.gov/products/${g}"></a></div>`;
        });

        /*let content = `<div class="container">
            <h1 class="title">
                Day ${day} ${type}
            </h1>
            <div class="bar">
                <p class="times">
                    <span>Issued <b>${timeAgo(request.outlook.issued)}</b></span>
                    <span>Valid from <b>${valid1}</b> until <b>${valid2}</b></span>
                    <span>Issued by <a target="blank" href="https://www.spc.noaa.gov/" title="NOAA/NWS Storm Prediction Center">NOAA/NWS Storm Prediction Center</a></span>
                </p>
            </div>
            <div class="wwa-details">
                ${request.outlook.text}
                <p style="color:#561717"><b>Forecaster:</b> ${request.outlook.forecaster}</p>
            </div>
            <div class="graphics">
                ${graphics}
            </div>
        </div>`;*/

        let content = `<div class="container">
                <div class="wwa">
                    <header>
                        <div class="title">
                            <div class="tray">
                                <h1>Day ${day} ${type}</h1>
                            </div>

                            <p class="timestamps">
                                Issued <b>${timeAgo(request.outlook.issued)}</b> &middot; Valid from <b>${valid1}</b> until <b>${valid2}</b> &middot; Issued by <a target="blank" href="https://www.spc.noaa.gov/" title="NOAA/NWS Storm Prediction Center">NOAA/NWS Storm Prediction Center</a>
                            </p>
                        </div>
                    </header>

                    <div class="block">
                        <div class="card row">
                            <div class="col wwa-details" data-width="100">
                                ${request.outlook.text}

                                <b>Forecaster:</b> ${request.outlook.forecaster}
                            </div>
                        </div>

                        <div class="graphics">
                            ${graphics}
                        </div>
                    </div>
                </div>
            </div>`;

        modal.querySelector('.content').innerHTML = content;
    }

    async readWWA(id, click = true) {
        new ClickListener().openModal('wwa');

        const request = await api(config.apiURL + 'getWWA', [['id', id]]),
            a = request.wwa;

        if (config.workers.wwas == null) {
            config.workers.wwas = new Worker(config.specificURL + (debugMode ? 'v' + version + '/wwas.js' : 'src/js/wwas-' + version + '.js'));
        }

        setHeaders(a.title + ' issued by the National Weather Service in ' + a.office, 'weather/alert/' + id,
            'The National Weather Service in ' + a.office + ' has issued a ' + a.title + ' for ' + a.area + ' until ' + a.expires + '.');

        config.workers.wwas.postMessage(a);

        /* add content to modal after service worker finishes */
        config.workers.wwas.onmessage = (event) => {
            modal.querySelector('.content').innerHTML = event.data;

            if (a.title == 'Tornado Warning' || a.title == 'Severe Thunderstorm Warning') {
                modal.querySelector('h1.title').style.color = a.color;
            }
        };
    }
}

function purchaseLink(utm, next = null) {
    if (settings.subscriptions().valid() && config.TIERS[settings.subscriptions().plan()] == config.PERMISSION_LEVELS.PREMIUM) {
        return config.domain + 'account/billing#upgrade=true&sid=' + settings.subscriptions().subID()
    } else {
        return config.domain + 'purchase/mapofire' + (utm ? '?utm_campaign=Locked%20Features&utm_source=mapofire&utm_medium=' + utm : '') + (next ? '&next=' + next : '');
    }
};

class Tooltips {
    constructor(options = {}) {
        this.nav = document.querySelector('nav');
        this.tooltipEl = document.createElement("div");
        this.tooltipEl.className = "tooltip";
        document.body.appendChild(this.tooltipEl);

        this.activeTitle = null;
        this.activeTarget = null;
        this.offset = options.offset || 8;
        this.followMouse = options.followMouse || false;
    }

    show(targetEl, content, event) {
        if (!targetEl || (targetEl.closest('li') && !this.nav.classList.contains('hide'))) return;

        this.tooltipEl.textContent = content;

        this.tooltipEl.style.top = "0px";
        this.tooltipEl.style.left = "-9999px";
        this.tooltipEl.classList.add("show");

        const rect = targetEl.getBoundingClientRect(),
            scrollY = window.scrollY || window.pageYOffset,
            scrollX = window.scrollX || window.pageXOffset,
            tooltipWidth = this.tooltipEl.offsetWidth,
            tooltipHeight = this.tooltipEl.offsetHeight,
            space = {
                top: rect.top,
                bottom: window.innerHeight - rect.bottom,
                left: rect.left,
                right: window.innerWidth - rect.right
            };

        let top, left;
        let arrowClass = '';

        if (this.followMouse && event) {
            top = event.pageY + this.offset;
            left = event.pageX - tooltipWidth / 2;
            arrowClass = '';
        } else {
            const sideThreshold = 150; // px from left/right edges to force horizontal placement

            // LEFT/RIGHT only if element is near viewport edges
            if (rect.left < sideThreshold && space.right >= tooltipWidth + this.offset) {
                // place to right
                top = rect.top + scrollY + rect.height / 2 - tooltipHeight / 2;
                left = rect.right + scrollX + this.offset;
                arrowClass = 'left';
            } else if (rect.right > window.innerWidth - sideThreshold && space.left >= tooltipWidth + this.offset) {
                // place to left
                top = rect.top + scrollY + rect.height / 2 - tooltipHeight / 2;
                left = rect.left + scrollX - tooltipWidth - this.offset;
                arrowClass = 'right';
            } else if (space.top >= tooltipHeight + this.offset) {
                // place above
                top = rect.top + scrollY - tooltipHeight - this.offset;
                left = rect.left + scrollX + rect.width / 2 - tooltipWidth / 2;
                arrowClass = 'down';
            } else if (space.bottom >= tooltipHeight + this.offset) {
                // place below
                top = rect.bottom + scrollY + this.offset;
                left = rect.left + scrollX + rect.width / 2 - tooltipWidth / 2;
                arrowClass = 'up';
            } else {
                // fallback above
                top = rect.top + scrollY - tooltipHeight - this.offset;
                left = rect.left + scrollX + rect.width / 2 - tooltipWidth / 2;
                arrowClass = 'down';
            }

            // Clamp horizontal/vertical
            if (left < 0) left = 0;
            if (left + tooltipWidth > window.innerWidth)
                left = window.innerWidth - tooltipWidth;
            if (top < 0) top = 0;
            if (top + tooltipHeight > window.innerHeight)
                top = window.innerHeight - tooltipHeight;
        }

        this.activeTarget.removeAttribute('title');
        this.tooltipEl.style.top = `${top}px`;
        this.tooltipEl.style.left = `${left}px`;
        this.tooltipEl.className = `tooltip show ${arrowClass}${targetEl.classList.contains('light') ? ' light' : ''}`;
    }

    hide() {
        this.tooltipEl.classList.remove('show');
    }

    attach(selector, getContent) {
        document.querySelectorAll(selector).forEach(el => {
            document.addEventListener('mouseover', (e) => {
                const target = e.target.closest(selector);
                if (!target || this.activeTarget === target) return;
                this.activeTarget = target;
                this.activeTitle = target.title;
                this.show(target, getContent(target), e);
            });

            document.addEventListener('mousemove', (e) => {
                if (!this.followMouse || !this.activeTarget) return;
                this.show(this.activeTarget, getContent(this.activeTarget), e);
            });

            document.addEventListener('mouseout', (e) => {
                const target = e.target.closest(selector);
                if (!target || target !== this.activeTarget) return;
                this.hide();
                this.activeTarget.title = this.activeTitle;
                this.activeTitle = null;
                this.activeTarget = null;
            });
        });
    }
}

function notify(t, m, time = null) {
    const timing = (time == null ? (((m.split(' ').length / 5) + 0.5) * 1000) + 500 : time * 1000),
        el = document.createElement('div'),
        icon = t == 'success' ? 'fa-check' : (t == 'info' ? 'fa-circle-info' : 'fa-circle-exclamation');

    document.querySelector('div.alert')?.remove();

    el.classList.add('alert', t);

    if (modal.classList.contains('open')) el.classList.add('mo');

    el.style.display = 'flex';
    el.innerHTML = '<i class="fas ' + icon + '"></i><p>' + m + '</p>';
    document.body.append(el);

    setTimeout(() => { el.remove(); }, timing);
}

function marketing(override = false, utm = null) {
    const now = Date.now(),
        lastShown = parseInt(localStorage.getItem('mapofire.marketing.last_shown') || '0', 10),
        variants = {
            A: {
                title: 'Stay Safe. Stay Ahead.',
                text: 'Wildfires don\'t wait and neither should you. Upgrade to gain access to satellite hotspots, smoke models, and wildfire risk overlays.',
                primary: 'Start 7-Day Free Trial',
                secondary: settings.user != null ? 'Continue for Free' : 'Continue with Free Plan'
            },
            B: {
                title: 'Unlock Pro Insights.',
                text: 'Make faster, smarter wildfire decisions with advanced fire mapping, premium layers, extra basemaps, and offline access on Android.',
                primary: 'Upgrade Now',
                secondary: 'Keep Free Plan'
            },
            C: {
                title: 'Access Premium Wildfire Tools',
                text: 'Gain access to historical wildfires, fire weather forecasts, premium layers, and additional basemaps. Upgrade now or start a free 7-day trial.',
                primary: 'Start 7-Day Free Trial',
                secondary: settings.user != null ? 'Continue for Free' : 'Continue with Free Plan'
            }
        },
        pick = override ? 'C' : (Math.random() < 0.5 ? 'A' : 'B'),
        option = variants[pick],
        maxDismissals = 4;

    let shouldShow = true,
        dismissedCount = parseInt(localStorage.getItem('mapofire.marketing.dismiss_count') || '0', 10),
        cooldownDays = parseInt(localStorage.getItem('mapofire.marketing.cooldown_days')) || 3;

    // if already shown this session, don't show again
    if (sessionStorage.getItem('modal_shown_this_session')) shouldShow = false;

    // don't show if dismissed too many times
    if (dismissedCount >= maxDismissals) shouldShow = false;

    // don't show if dismissed too many times
    /*if (!localStorage.getItem('mapofire.refresh')) {
        shouldShow = false;
    }*/

    // don't show if cooldown not expired
    if (now - lastShown < cooldownDays * 24 * 60 * 60 * 1000) shouldShow = false;

    if (override) {
        shouldShow = true;
        sessionStorage.removeItem('modal_shown_this_session');
    }

    // don't show to admin users
    if (settings.getUser().role() == config.PERMISSION_LEVELS.ADMIN) shouldShow = false;

    if (shouldShow) {
        const content = `<p style="text-align:center;margin:1.5em 0;font-size:18px;font-weight:400">${option.text}</p>
            <div class="btn-group no-margin" style="width:100%;justify-content:space-between">
                <input type="button" id="donate_cta" class="btn btn-red dn" value="${option.primary}" data-variant="${pick}" data-action="start-modal-checkout">
                <input type="button" id="donate_dismiss" class="btn btn-gray dn" value="${option.secondary}" data-dismissedCount="${dismissedCount}" data-variant="${pick}" data-action="close-modal-checkout">
            </div>`;

        const el = document.createElement('div');
        el.classList.add('shadow');
        document.body.appendChild(el);

        createDataForm(option.title, content);
        document.querySelector('#data-form').classList.add('bg');
        document.querySelector('#data-form h1').style.textAlign = 'center';
        document.querySelector('#data-form h1').insertAdjacentHTML('beforebegin', '<i class="fad fa-user-unlock" style="display:block;text-align:center;font-size:50px;color:#ffcd82;margin-bottom:0.5em"></i>');

        // mark as shown
        sessionStorage.setItem('modal_shown_this_session', '1');
        localStorage.setItem('mapofire.marketing.last_shown', now.toString());

        // postive CTA
        document.querySelector('#donate_cta').addEventListener('click', () => {
            gtag('event', 'subscription_cta_click', {
                'event_category': 'Subscription',
                'event_label': `Variant_${pick}`,
                'source': override ? 'embed' : 'modal',
                'variant': pick
            });

            window.location.href = config.purchaseLink(utm ? utm : 'popup');
            new ClickListener().closeDataForm();
        });

        // dismiss CTA
        document.querySelector('#donate_dismiss').addEventListener('click', () => {
            dismissedCount++;
            localStorage.setItem('mapofire.marketing.dismiss_count', dismissedCount);

            if (dismissedCount >= maxDismissals) {
                cooldownDays = cooldownDays * 2; // double cooldown
                dismissedCount = 0; // reset dismissals
                localStorage.setItem('mapofire.marketing.cooldown_days', cooldownDays);
                localStorage.setItem('mapofire.marketing.dismiss_count', dismissedCount);
            }

            gtag('event', 'subscription_dismiss_click', {
                'event_category': 'Subscription',
                'event_label': `Variant_${pick}`,
                'source': override ? 'embed' : 'modal',
                'variant': pick
            });

            new ClickListener().closeDataForm();
        });
    }
}

async function loadDispatchCenters() {
    if (localStorage.getItem('mapofire.dispatch') == null || Date.now() - localStorage.getItem('mapofire.dispatch_time') > 60 * 60 * 24 * 1000) {
        const dc = await api(config.apiURL + 'dispatch/all');
        localStorage.setItem('mapofire.dispatch', JSON.stringify(dc.dispatch));
        localStorage.setItem('mapofire.dispatch_time', Date.now());
        dispatchCenters = dc.dispatch;
    } else {
        dispatchCenters = JSON.parse(localStorage.getItem('mapofire.dispatch'));
    }
}

function loadScript(src) {
    return new Promise(function (resolve, reject) {
        var s;
        s = document.createElement('script');
        s.src = src;
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
    });
}

function addTrending() {
    const fragment = document.createDocumentFragment();
    let count = 0;

    trending = true;

    searchResults.style.display = 'flex';
    searchResults.querySelector('li.standby').innerHTML = '<h6 style="color:var(--box-border);font-size:18px;cursor:auto;user-select:none">Trending incidents...</h6>';

    if (searchResults.querySelector('li.standby').style.display == 'none') {
        searchResults.querySelector('li.standby').style.display = 'inline-flex';
    }

    if (topFires != null && topFires.length > 0) {
        for (let i = 0; i < topFires.length; i++) {
            const p = topFires[i].data,
                fire = config.wildfire.findFire(p.wfid);

            if (fire) {
                const fireName = fire.properties.name,
                    acres = conversion.sizeFormat(fire.properties.acres),
                    who = numberFormat(topFires[i].count, 0) + ' ' + (topFires[i].count == 1 ? 'person is' : 'people are') + ' looking at the ' + fireName,
                    li = document.createElement('li');

                li.classList.add('trending');
                li.setAttribute('data-action', 'sr-onclick');
                li.setAttribute('data-type', 'incident');
                li.setAttribute('data-wfid', p.wfid);
                li.setAttribute('title', who);

                li.innerHTML = '<div><span class="icon fire fas fa-fire"></span><h3>' + fireName +
                    '<span>' + fire.properties.type + ' in ' + stateLabels[fire.properties.state]?.name + ' &middot; <b>' + acres + '</b></span></h3></div>' +
                    (topFires[i].trending ? '<span class="trend fas fa-arrow-trend-up" style="color:var(--green)"></span>' : '');

                fragment.appendChild(li);

                count++;
                /*if (count >= 5) {
                    break;
                }*/
            }
        }
    }

    if (count === 0) {
        const li = document.createElement('li');
        li.classList.add('standby');
        li.innerHTML = '<span>No currently trending fires</span>';
        fragment.appendChild(li);
    }

    searchResults.appendChild(fragment);
}

async function startReportProcess(e) {
    let data = null;

    // query the map for the county and state first before requesting from the API
    map.queryRenderedFeatures(e.point)?.forEach(feat => {
        if (feat.layer.id == 'us_counties') {
            data = { geocode: { county: { county: feat.properties.NAME.replace(' County', '') }, state: feat.properties.STATE } };
        }
    });

    const geocode = await api(config.apiURL + 'geocode/incident' + (data != null ? '/near' : ''), [['lat', e.lngLat.lat], ['lon', e.lngLat.lng]], true);

    if (data == null) {
        data = geocode;
    } else {
        data.geocode['near'] = geocode?.geocode?.near ?? null;
    }

    createDataForm('Report an incident', `<form id="newReport" method="post">
        <input type="hidden" name="platform" value="web">
        <input type="hidden" name="authUser" value="0">
        <input type="hidden" name="lat">
        <input type="hidden" name="lon">
        <input type="hidden" name="state">
        <input type="hidden" name="version" value="${version}">
        <input type="hidden" name="geolocation">
        
        <label>County</label>
        <input type="text" id="gc" value="Loading..." disabled>
        
        <label>State</label>
        <input type="text" id="gs" value="Loading..." disabled>
        
        <label>General Location</label>
        <input type="text" id="gl" value="Loading..." disabled>
        
        <label>What type of incident is this?</label>
        <select name="type" required>
            <option>- Choose -</option>
            <option value="Wildfire">Wildfire</option>
            <option value="Smoke Check">Smoke Check</option>
        </select>

        <label>How big is it?</label>
        <input type="text" name="size" placeholder="eg: 10" style="display:inline-block;max-width:100px" required>
        <div id="alab" style="display:inline-block;padding-left:5px">acres</div>
        
        <label>Brief description of incident:</label>
        <textarea name="notes" placeholder="Anything else you can add..." style="min-height:100px;resize:none" required></textarea>
        
        <div class="btn-group centered">
            <input type="submit" class="btn btn-green" value="Submit Report">
            <a class="btn btn-gray" href="#" data-action="close-data-form" onclick="return false">Cancel</a>
        </div>
        <div class="disclaimer">Submitting this report only sends information to the ${config.productName} team&mdash;it does not send
        any information to emergency or governmental authorities. Please call 911 to report a new wildfire. By submitting a report,
        you agree to our <a target="blank" href="//mapotechnology.com/about/legal/terms">Terms of Service</a>.</div>
    </form>`);

    createCSReport(data, e.lngLat.lat, e.lngLat.lng);
}

function contextMenu(e, isTouch = false) {
    const click = new ClickListener(),
        menu = document.querySelector('.context-menu');

    if (menu) menu.remove();

    let point, coords;

    if (isTouch) {
        const rect = map.getContainer().getBoundingClientRect();
        point = { x: e.touches[0].clientX - rect.left, y: e.touches[0].clientY - rect.top };
        coords = map.unproject([point.x, point.y]);
    } else {
        point = e.point;
        coords = e.lngLat;
    }

    const ele = map.queryTerrainElevation([coords.lng, coords.lat]) ?? null,
        elevation = ele != null ? ele * 3.28084 : null;

    const div = document.createElement('div'),
        ul = document.createElement('ul'),
        options = [
            { text: coords.lat.toFixed(4) + ', ' + coords.lng.toFixed(4), hasPerms: true },
            { text: 'Copy coordinates', task: () => { click.copy(coords.lat + ', ' + coords.lng) }, hasPerms: true },
            {
                text: 'Copy elevation',
                task: async () => {
                    if (elevation == null) {
                        notify('info', 'Unable to get elevation here')
                    } else {
                        click.copy(numberFormat(elevation, 1) + ' ft.', 'Elevation copied to clipboard');
                    }
                },
                hasPerms: settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM)
            },
            {
                text: 'Zoom here',
                task: () => {
                    map.easeTo({
                        center: [coords.lng, coords.lat],
                        zoom: 12,
                        duration: 1400
                    });
                },
                hasPerms: true
            },
            {
                text: 'Get fire weather',
                task: () => new Weather(coords.lat, coords.lng).fireWxFcst(),
                hasPerms: settings.hasPermissions(config.PERMISSION_LEVELS.PREMIUM)
            },
            { text: 'Report new fire', task: async () => startReportProcess(e), hasPerms: true }
        ];

    div.className = 'context-menu';
    document.body.appendChild(div);
    div.appendChild(ul);

    options.forEach((i, n) => {
        const li = document.createElement('li');
        if (n == 0) li.style = 'padding:1em 1em 0.5em 1em;font-weight:600;cursor:default;user-select:none';
        if (!i.hasPerms) li.classList.add('disabled');
        li.textContent = i.text;
        li.addEventListener('click', () => {
            if (!i.hasPerms) return;    // maybe suggest they subscribe?

            if (i.task) {
                i.task();
                div.remove();
            }
        });

        ul.appendChild(li);
    });

    const menuWidth = div.offsetWidth,
        menuHeight = div.offsetHeight,
        mapRect = map.getContainer().getBoundingClientRect();

    let top = point.y;
    let left = point.x;

    if (left + menuWidth > mapRect.width) left = mapRect.width - menuWidth;
    if (top + menuHeight > mapRect.height) top = mapRect.height - menuHeight;
    if (left < 0) left = 0;
    if (top < 0) top = 0;

    div.style.top = `${top}px`;
    div.style.left = `${left}px`;

    div.innerHTML = '';
    div.appendChild(ul);
}

const mapClick = async (e) => {
    /* open new incident report form */
    if (document.querySelector('li#report').dataset.active == 1) {
        config.disableClicks = true;

        map.getCanvas().style.cursor = 'auto';
        map.panTo([e.lngLat.lng, e.lngLat.lat]);

        startReportProcess(e);
    }

    /* get fire weather forecast */
    if (document.querySelector('li#fwf')) {
        if (document.querySelector('li#fwf').dataset.active == 1) {
            config.disableClicks = true;
            document.querySelector('li#fwf').setAttribute('data-active', '0');

            map.getCanvas().style.cursor = 'auto';

            new Weather(e.lngLat.lat, e.lngLat.lng).fireWxFcst();
        }
    }

    /* click listener for when the user isn't submitting a report or getting a fwf */
    if (!config.disableClicks) {
        onMapClick(e);
    }
};

const moveEnd = debounce(() => {
    map.getCanvas().style.cursor = 'auto';

    //settings.logMovement();

    if (!settings.user || !settings.checkboxes() || settings.isEnabled('perimeters')) {
        //config.wildfire.perimeters(true);
    }

    if ((!settings.checkboxes() || settings.isEnabled('allFires')) && settings.archive != null) {
        config.wildfire.getWildfires(true);
    }

    if (settings.isEnabled('firemed') && map.getZoom() >= config.firemedZoomLevel) {
        config.layersHandler.firemed(true);
    }

    if (settings.isEnabled('modis24') && map.getZoom() >= config.modisZoomLevel) {
        config.layersHandler.modis(1, true);
    }

    if (settings.isEnabled('modis48') && map.getZoom() >= config.modisZoomLevel) {
        config.layersHandler.modis(2, true);
    }

    if (settings.isEnabled('modis72') && map.getZoom() >= config.modisZoomLevel) {
        config.layersHandler.modis(3, true);
    }

    if (settings.isEnabled('wwas')) {
        new NWS().get(true);
    }

    if (settings.isEnabled('stns')) {
        const int = setInterval(() => {
            if (Weather !== undefined) {
                new Weather().raws(true);
                clearInterval(int);
            }
        }, 500);
    }

    if (settings.isEnabled('erc')) {
        config.layersHandler.erc(true);
    }

    if (settings.isEnabled('hms')) {
        config.layersHandler.hms(true);
    }

    if (settings.isEnabled('smokeFcst')) {
        config.layersHandler.smokeFcst(true);
    }

    if (settings.isEnabled('nri')) {
        config.layersHandler.nri(true);
    }

    if (settings.isEnabled('power')) {
        config.layersHandler.power(true);
    }

    if (settings.isEnabled('dispatch')) {
        config.layersHandler.dispatch(true);
    }

    if (settings.isEnabled('gaccBounds')) {
        config.layersHandler.gaccBounds(true);
    }

    if (settings.isEnabled('calfireUnits')) {
        config.layersHandler.calfireUnits(true);
    }

    if (settings.isEnabled('cdfFHSZ')) {
        config.layersHandler.cdfFHSZ(true);
    }
}, 500);

class MFAttribControl extends maplibregl.AttributionControl {
    constructor(options) {
        super(options);

        this._collapseBelow = options.collapseBelow ?? 500;
    }

    onAdd(map) {
        const container = super.onAdd(map);
        map.on('resize', this._applyViewportRule);
        this._applyViewportRule();
        return container;
    }

    onRemove() {
        if (this._map) this._map.off('resize', this._applyViewportRule);
        super.onRemove();
    }

    _applyViewportRule = () => {
        if (!this._map || !this._container) return;

        const width = this._map.getCanvasContainer().offsetWidth;
        const shouldShow = width > this._collapseBelow;

        // Explicitly NOT compact → always open
        if (this.options?.compact === false) {
            this._container.classList.remove('maplibregl-compact', 'maplibregl-compact-show');
            this._container.setAttribute('open', '');
            return;
        }

        // Compact mode is ON (default MapLibre behavior)
        this._container.classList.add('maplibregl-compact');

        if (shouldShow) {
            // Expanded compact attribution
            this._container.classList.add('maplibregl-compact-show');
            this._container.setAttribute('open', '');
        } else {
            // Collapsed compact attribution
            this._container.classList.remove('maplibregl-compact-show');
            this._container.removeAttribute('open');
        }
    };

    _updateAttributions() {
        ////super._updateAttributions();
        this._innerContainer.innerHTML = '<a target="blank" href="https://maplibre.org/">MapLibre</a> | ' +
            '© <a target="blank" href="https://www.esri.com">Esri</a>, ' +
            '© <a target="blank" href="https://carto.com/about-carto/" rel="noopener">CARTO</a>, ' +
            '© <a target="blank" href="http://www.openstreetmap.org/about/">OpenStreetMap</a> contributors';
    }
}